extends Control
## v2 新版 K 线图：同花顺式布局（顶部均线文案 → 蜡烛+均线 → 最高/最低标注 → 日期轴 → 成交量 → 指标）
## 纯 _draw 绘制，无位图；触摸由 chart_input.gd 驱动；红涨绿跌

signal period_changed(p: int)

## Market 里 K 线的 t 是"游戏内累计分钟数"（t=0 对应开局）。
## 日期换算统一走 Const.game_unix()，与顶栏日期、新闻时间线同一套日历。
const UP   := Color(0.89, 0.17, 0.21)     # 红涨（白底）
const DOWN := Color(0.04, 0.60, 0.34)     # 绿跌（白底）
const MA_COLORS := [Color(0.86,0.58,0.05), Color(0.12,0.42,0.88), Color(0.60,0.28,0.82), Color(0.92,0.42,0.12)]
const MA_LABELS := ["M5", "M10", "M20", "M30"]
const PERIODS := [1, 5, 15, 60, 0, -1, -2]   # 1/5/15/60分, 日, 周, 月
const PERIOD_NAMES := ["1分", "5分", "15分", "60分", "日K", "周K", "月K"]

var bars: Array = []          # {o,h,l,c,v,t}
var period: int = 0           # 用 Const.Period 枚举值 0..6
var ma_periods: Array = [5, 10, 20, 30]
var show_ma := true
var _code: String = ""        # 当前标的，refresh() 据此重新取行情

# ---- 视图状态（由 chart_input.gd 修改）----
var view_count := 40
var view_offset := 0
var cursor_idx := -1
var cross_pos := Vector2.ZERO

var _pan_carry := 0.0
var _cw := 1.0
var _price_top := 0.0; var _price_h := 0.0
var _axis_y := 0.0
var _vol_top := 0.0;  var _vol_h := 0.0
var _lo := 0.0; var _hi := 0.0; var _vmax := 0.0
var _vis_bars: Array = []     # 本帧可视K线，_draw 开头算一次，各处复用

func _ready() -> void:
	custom_minimum_size = Vector2(320, 420)

## 主界面调用：切换标的 / 周期，并立刻取一次行情
func set_symbol(code: String, p: int) -> void:
	_code = code
	period = p
	view_offset = 0
	cursor_idx = -1
	refresh()

## 重新从 Market 取当前周期 K 线（行情每推进一次由 main.gd 转调）
func refresh() -> void:
	if _code == "":
		return
	bars = Market.get_bars(_code, period)
	queue_redraw()

func set_period(p: int) -> void:
	period = p
	view_offset = 0
	period_changed.emit(p)
	refresh()

## 游戏分钟 -> Unix 秒（仅用于显示日期，不参与行情计算）
func _unix(t: int) -> int:
	return Const.game_unix(t)

func bar_count() -> int: return bars.size()
func get_cw() -> float: return _cw
func max_offset() -> int: return maxi(0, bars.size() - view_count)

func zoom(center_ratio: float, factor: float) -> void:
	var old_n: int = view_count
	var n: int = clampi(roundi(float(old_n) * factor), 12, 200)
	if n == old_n:
		return
	# 以鼠标下那根 K 线为锚点：缩放前后它在可见窗口里的相对位置不变。
	# 旧公式把偏移算反了（还丢了当前 view_offset），一缩放就跳回最新一根。
	var anchor: float = float(bars.size() - old_n - view_offset) + center_ratio * float(old_n)
	var new_start: float = anchor - center_ratio * float(n)
	view_count = n
	view_offset = clampi(roundi(float(bars.size()) - float(n) - new_start), 0, max_offset())
	queue_redraw()

func pan_by_bars(d: float) -> bool:
	_pan_carry += d
	var steps := roundi(_pan_carry)     # 慢速微拖时也能累计到 1 根
	_pan_carry -= steps
	var before := view_offset
	view_offset = clampi(view_offset + steps, 0, max_offset())
	if before != view_offset: queue_redraw()
	return view_offset != 0 and view_offset != max_offset()

func _idx_at_ratio(r: float) -> int:
	if bars.is_empty(): return 0
	return clampi(bars.size() - view_count + roundi(r * view_count), 0, bars.size() - 1)

# ---------------- 绘制 ----------------
func _draw() -> void:
	if bars.is_empty():
		draw_string(ThemeDB.fallback_font, Vector2(size.x/2 - 40, size.y/2), "暂无行情数据",
					HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Const.TEXT_SUB); return
	# 原先 _compute_range/_draw_candles/_draw_ma/_draw_axis/_draw_volume... 各调一次 _vis()，
	# 一帧要 slice 七八次。现在只切一次存起来，下面全部复用。
	var start := clampi(bars.size() - view_count - view_offset, 0, maxi(0, bars.size() - 1))
	_vis_bars = bars.slice(start, start + view_count)
	_layout()
	_compute_range()
	_draw_grid()
	_draw_candles()
	if show_ma: _draw_ma()
	_draw_highlow_marks()
	_draw_axis()        # ★ 日期在 K 线图下方
	_draw_volume()
	if cursor_idx >= 0: _draw_crosshair()
	_draw_period_hint()

## 右上角小字：当前周期 / 总根数 / 可用手势，避免"不知道自己看的是哪档"
func _draw_period_hint() -> void:
	if ThemeDB.fallback_font == null:
		return
	# 竖屏（手机上，或电脑上把窗口拉竖预览手机版）写触摸手势，横屏才写滚轮。
	var touch_ui: bool = size.y > size.x * 1.15 or OS.has_feature("mobile")
	var how: String = "双指捏合缩放 · 单指拖动 · 长按读数" if touch_ui else "滚轮缩放 / 拖动平移"
	var info: String = "%s · %d 根 · %s" % [str(Const.PERIOD_LABEL[period]), bars.size(), how]
	draw_string(ThemeDB.fallback_font, Vector2(8, 18), info,
			HORIZONTAL_ALIGNMENT_RIGHT, size.x - 16.0, 11, Const.TEXT_SUB)

func _layout() -> void:
	_price_top = 26.0
	_price_h = size.y * 0.56
	_axis_y = _price_top + _price_h + 4.0
	_vol_top = _axis_y + 26.0
	_vol_h = maxf(40.0, size.y - _vol_top - 10.0)

func _compute_range() -> void:
	_lo = 1e18; _hi = -1e18; _vmax = 0.0
	for b in _vis():
		_lo = minf(_lo, b["l"]); _hi = maxf(_hi, b["h"]); _vmax = maxf(_vmax, b["v"])
	if _hi <= _lo: _hi = _lo + 1.0
	var pad := (_hi - _lo) * 0.08
	_lo -= pad; _hi += pad

func _vis() -> Array:
	return _vis_bars

func _py(p: float) -> float:
	return _price_top + _price_h - (p - _lo) / (_hi - _lo) * _price_h

func _draw_grid() -> void:
	for i in 5:
		var y := _price_top + _price_h * i / 4.0
		draw_line(Vector2(0, y), Vector2(size.x, y), Const.GRID, 1.0)
		for j in 5:
			var y2 := _vol_top + _vol_h * j / 4.0
			draw_line(Vector2(0, y2), Vector2(size.x, y2), Const.GRID, 1.0)

func _draw_candles() -> void:
	var vis := _vis()
	var n := vis.size()
	if n == 0: return
	_cw = size.x / n
	var w := clampf(_cw * 0.62, 1.0, 16.0)
	for i in n:
		var b = vis[i]
		var x := i * _cw + _cw * 0.5
		var col: Color = UP if b["c"] >= b["o"] else DOWN
		draw_line(Vector2(x, _py(b["h"])), Vector2(x, _py(b["l"])), col, maxf(1.0, w * 0.12))
		var top := _py(maxf(b["o"], b["c"])); var bot := _py(minf(b["o"], b["c"]))
		if bot - top < 1.0: bot = top + 1.0       # 一字板仍可见
		draw_rect(Rect2(x - w/2.0, top, w, bot - top), col, true)

func _ma(n: int, i: int, vis: Array) -> float:
	if i + 1 < n: return 0.0
	var s := 0.0
	for k in n: s += vis[i - k]["c"]
	return s / n

func _draw_ma() -> void:
	var vis := _vis()
	var x_of: Callable = func(i): return i * _cw + _cw * 0.5
	for mi in ma_periods.size():
		var n: int = ma_periods[mi]
		var col: Color = MA_COLORS[mi % MA_COLORS.size()]
		var prev := Vector2.ZERO
		for i in vis.size():
			var v := _ma(n, i, vis)
			if v <= 0.0: continue
			var p := Vector2(x_of.call(i), _py(v))
			if prev != Vector2.ZERO: draw_line(prev, p, col, 1.2)
			prev = p
	var s := "均线 "
	for mi in ma_periods.size():
		var last := _ma(ma_periods[mi], vis.size() - 1, vis)
		if last <= 0.0: continue
		s += "%s:%.2f " % [MA_LABELS[mi % MA_LABELS.size()], last]
	draw_string(ThemeDB.fallback_font, Vector2(8, 18), s,
				HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Const.TEXT_SUB)

func _draw_highlow_marks() -> void:
	var vis := _vis()
	if vis.is_empty(): return
	var hi_i := 0; var lo_i := 0
	for i in vis.size():
		if vis[i]["h"] > vis[hi_i]["h"]: hi_i = i
		if vis[i]["l"] < vis[lo_i]["l"]: lo_i = i
	var xh := hi_i * _cw + _cw * 0.5
	var xl := lo_i * _cw + _cw * 0.5
	draw_string(ThemeDB.fallback_font, Vector2(clampf(xh - 26, 2, size.x - 60), _py(vis[hi_i]["h"]) - 6),
				"%.2f →" % vis[hi_i]["h"], HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Const.TEXT)
	draw_string(ThemeDB.fallback_font, Vector2(clampf(xl - 26, 2, size.x - 60), _py(vis[lo_i]["l"]) + 14),
				"← %.2f" % vis[lo_i]["l"], HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Const.TEXT)

## ★ 日期轴紧贴 K 线下方（与同花顺一致）：均匀抽 5 个标签，避免文字重叠
func _draw_axis() -> void:
	var vis := _vis()
	if vis.is_empty(): return
	draw_line(Vector2(0, _axis_y - 2), Vector2(size.x, _axis_y - 2), Const.BORDER, 1.0)
	var step := maxi(1, floori(float(vis.size()) / 5.0))
	var last_x := -100.0
	for i in vis.size():
		if i % step != 0: continue
		var t: int = vis[i]["t"]
		var x := i * _cw + _cw * 0.5
		if x - last_x < 54.0: continue
		last_x = x
		var col: Color = Const.TEXT_SUB
		var dt: Dictionary = Time.get_datetime_dict_from_unix_time(_unix(t))
		if (period == Const.Period.DAY or period == Const.Period.MONTH) and int(dt["day"]) == 1:
			col = Color(0.86,0.48,0.06)     # 月初高亮
		draw_string(ThemeDB.fallback_font, Vector2(clampf(x - 22, 0, size.x - 46), _axis_y + 12),
					_fmt_date(t), HORIZONTAL_ALIGNMENT_LEFT, -1, 10, col)

func _fmt_date(t: int) -> String:
	var d: Dictionary = Time.get_datetime_dict_from_unix_time(_unix(t))
	if period <= Const.Period.M60:
		return "%02d:%02d" % [int(d["hour"]), int(d["minute"])]
	if period == Const.Period.WEEK:
		return "%02d年%02d月" % [int(d["year"]) % 100, int(d["month"])]
	if period == Const.Period.MONTH:
		return "%02d-%02d" % [int(d["year"]) % 100, int(d["month"])]
	return "%02d-%02d" % [int(d["month"]), int(d["day"])]

func _draw_volume() -> void:
	var vis := _vis()
	var w := clampf(_cw * 0.62, 1.0, 16.0)
	for i in vis.size():
		var b = vis[i]
		var col := UP if b["c"] >= b["o"] else DOWN
		var h: float = (b["v"] / _vmax * _vol_h) if _vmax > 0 else 0.0
		draw_rect(Rect2(i * _cw + _cw * 0.5 - w/2.0, _vol_top + _vol_h - h, w, h),
				  Color(col.r, col.g, col.b, 0.6), true)

func _draw_crosshair() -> void:
	var vis := _vis()
	var start := bars.size() - view_count - view_offset
	var li := cursor_idx - start
	if li < 0 or li >= vis.size(): return
	var x := li * _cw + _cw * 0.5
	var y := clampf(cross_pos.y, _price_top, _vol_top + _vol_h)
	draw_line(Vector2(x, _price_top), Vector2(x, _vol_top + _vol_h), Color(0.35,0.38,0.42,0.75), 1.0)
	draw_line(Vector2(0, y), Vector2(size.x, y), Color(0.35,0.38,0.42,0.75), 1.0)
	var b = vis[li]
	draw_rect(Rect2(4, _price_top + 2, 200, 16), Color(0.1,0.1,0.1,0.75), true)
	draw_string(ThemeDB.fallback_font, Vector2(8, _price_top + 14),
				"%s  O%.2f H%.2f L%.2f C%.2f" % [_fmt_date(b["t"]), b["o"], b["h"], b["l"], b["c"]],
				HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(1,1,1))
