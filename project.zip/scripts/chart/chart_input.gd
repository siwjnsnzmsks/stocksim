extends Node
## K 线触摸手势（安卓为主，桌面鼠标仍可用）
##   单指拖动 → 平移（松手带惯性）
##   双指张开/捏合 → 缩放（自己按两指距离算，不依赖 InputEventMagnifyGesture，
##                     那个事件在 Android 默认不会发，等于没做）
##   双击 → 回到最新一根；长按 → 十字光标读数；移开/松手清光标
##   桌面：左键拖动平移、滚轮缩放由 main.gd 统一处理
##
## 不走 gui_input：那是 GUI 派发链路，受 mouse_filter / 父子遮挡 / 谁先消费影响，
## 之前"点了没反应"就栽在这里。改用 Node 级 _input，自己按 chart 的全局矩形判命中，
## 只要父节点没有 set_input_as_handled，事件一定会送到这里。

const INERTIA_DECAY := 0.92
const INERTIA_MIN := 0.4
const LONG_PRESS_SEC := 0.45
const DOUBLE_TAP_SEC := 0.3
const TAP_SLOP := 12.0

var chart = null   # 不能标 Control：get_cw/zoom/pan_by_bars 是图表脚本自定义成员
var pan_speed := 0.06

# 活跃触点：index -> Vector2（视口坐标）。双指捏合全靠它算距离。
var _points: Dictionary = {}
var _pinch_prev_dist := 0.0
var _pinching := false
var _dragging := false
var _touching := false
var _mouse_down := false
var _last_pos := Vector2.ZERO   # 最近触点位置：长按光标用它，不依赖鼠标位置
var _last_x := 0.0
var _start_x := 0.0
var _press_t := 0.0
var _last_tap_t := -1.0
var _vel := 0.0
var _pointer := -1
var _long_fired := false

func _ready() -> void:
	if chart == null:
		chart = get_parent()
	set_process_input(true)
	set_process(true)
	_update_pan_speed()
	if chart:
		chart.resized.connect(_update_pan_speed)

func _update_pan_speed() -> void:
	if chart and chart.size.x > 0:
		pan_speed = 40.0 / chart.size.x

## 把视口坐标换成 Chart 局部坐标；不在图表内返回 false。
## 用 get_global_rect 而不是 make_input_local，避免事件类型 as 转换返回 null。
func _hit(ev_pos: Vector2, out: Array) -> bool:
	if not chart or not bool(chart.visible):
		return false
	var gr: Rect2 = chart.get_global_rect()
	if not gr.has_point(ev_pos):
		return false
	out.append(ev_pos - gr.position)
	return true

func _two_finger_span() -> float:
	if _points.size() < 2:
		return 0.0
	var ks: Array = _points.keys()
	var a: Vector2 = _points[int(ks[0])]
	var b: Vector2 = _points[int(ks[1])]
	return a.distance_to(b)

func _two_finger_mid_x() -> float:
	if _points.size() < 2:
		return 0.0
	var ks: Array = _points.keys()
	var a: Vector2 = _points[int(ks[0])]
	var b: Vector2 = _points[int(ks[1])]
	return (a.x + b.x) * 0.5

func _begin_single(index: int, p: Vector2) -> void:
	_pointer = index
	_touching = true
	_dragging = false
	_last_x = p.x
	_start_x = p.x
	_last_pos = p
	_press_t = 0.0
	_vel = 0.0
	_long_fired = false

func _finish_tap(end_x: float) -> void:
	var moved_far: bool = absf(end_x - _start_x) >= TAP_SLOP
	if moved_far or _press_t >= LONG_PRESS_SEC:
		chart.cursor_idx = -1
	else:
		var now: float = float(Time.get_ticks_msec()) / 1000.0
		if now - _last_tap_t < DOUBLE_TAP_SEC:
			chart.view_offset = 0        # 双击回到最新一根
			chart.cursor_idx = -1
			_vel = 0.0
			_last_tap_t = -1.0
		else:
			_last_tap_t = now
	_long_fired = false
	chart.queue_redraw()

func _process(delta: float) -> void:
	# 面板打开时 Chart 被隐藏：手势与惯性全部停掉，
	# 否则关掉面板后会发现 K 线被偷偷平移过。
	if not chart or not bool(chart.visible):
		_vel = 0.0
		_touching = false
		_dragging = false
		_pinching = false
		_mouse_down = false
		_long_fired = false
		_points.clear()
		return
	# 长按：单指按住不动才出十字光标。坐标用记录的触点，
	# 不能用 get_local_mouse_position()——关掉鼠标模拟后它不会跟着触屏更新。
	var single: bool = (_touching and _points.size() == 1) or (_mouse_down and _points.is_empty())
	if single and not _dragging and not _pinching:
		if absf(_last_pos.x - _start_x) < TAP_SLOP:
			_press_t += delta
			if _press_t >= LONG_PRESS_SEC and not _long_fired and chart.cursor_idx < 0:
				chart.cross_pos = _last_pos
				chart.cursor_idx = _idx_near(_last_pos.x)
				_long_fired = true
				chart.queue_redraw()
	# 惯性滑动
	if absf(_vel) > INERTIA_MIN:
		var moved: float = _vel * delta * 60.0
		_vel *= INERTIA_DECAY
		if not chart.pan_by_bars(moved * pan_speed):
			_vel = 0.0

func _input(ev: InputEvent) -> void:
	if not chart or not bool(chart.visible) or page_blocked():
		return
	if ev is InputEventScreenTouch:
		var t: InputEventScreenTouch = ev
		var loc: Array = []
		# 抬起时不管手指滑到哪里都必须结算，否则 _points 里会残留触点，手势永久卡住。
		var tracked: bool = _points.has(t.index)
		var allow_up: bool = (not t.pressed) and tracked
		if not _hit(t.position, loc) and not allow_up:
			return
		var p: Vector2 = Vector2.ZERO
		if loc.is_empty():
			var gtr: Rect2 = chart.get_global_rect()
			p = t.position - gtr.position
		else:
			p = loc[0]
		_on_touch(t.index, t.pressed, p)
	elif ev is InputEventScreenDrag:
		var sd: InputEventScreenDrag = ev
		var loc_d: Array = []
		# 手指拖出图表边界时仍要继续跟踪（双指捏合常有一指滑到边缘），
		# 否则那根指的位置不再更新，缩放会卡住。
		var carry_d: bool = _points.has(sd.index) and (_pinching or _dragging)
		if not _hit(sd.position, loc_d) and not carry_d:
			return
		var dp: Vector2 = Vector2.ZERO
		if loc_d.is_empty():
			var gdr: Rect2 = chart.get_global_rect()
			dp = sd.position - gdr.position
		else:
			dp = loc_d[0]
		_on_drag(sd.index, dp)
	elif ev is InputEventMouseButton:
		var mb: InputEventMouseButton = ev
		# 滚轮缩放由 main.gd 的 _input 统一处理（带"鼠标必须在 K 线区内"判定），
		# 这里不重复，避免一次滚动缩放两次。
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP or mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			return
		if mb.button_index != MOUSE_BUTTON_LEFT:
			return
		var loc_m: Array = []
		var allow_mup: bool = (not mb.pressed) and _mouse_down
		if not _hit(mb.position, loc_m) and not allow_mup:
			return
		var pmv: Vector2 = Vector2.ZERO
		if loc_m.is_empty():
			var gmr2: Rect2 = chart.get_global_rect()
			pmv = mb.position - gmr2.position
		else:
			pmv = loc_m[0]
		_on_mouse_button(mb.pressed, pmv)
	elif ev is InputEventMouseMotion:
		var mm: InputEventMouseMotion = ev
		var loc_mm: Array = []
		if not _hit(mm.position, loc_mm) and not _mouse_down:
			return
		var mp: Vector2 = Vector2.ZERO
		if loc_mm.is_empty():
			var gmr: Rect2 = chart.get_global_rect()
			mp = mm.position - gmr.position
		else:
			mp = loc_mm[0]
		_on_mouse_motion(mp)

## 面板打开时 Chart 已隐藏，这里再兜一层，避免任何情况下手势和面板抢事件
func page_blocked() -> bool:
	if not chart:
		return true
	var vis: bool = bool(chart.visible)
	return not vis

func _on_touch(index: int, pressed: bool, p: Vector2) -> void:
	if pressed:
		_points[index] = p
		_last_pos = p
		if _points.size() >= 2:
			# 第二根手指落下 → 进入捏合，取消拖动/惯性/光标
			_pinching = true
			_dragging = false
			_vel = 0.0
			_pinch_prev_dist = _two_finger_span()
			chart.cursor_idx = -1
			chart.queue_redraw()
		else:
			_begin_single(index, p)
		return
	# ---- 抬起 ----
	_points.erase(index)
	if _points.size() >= 2:
		_pinch_prev_dist = _two_finger_span()
		return
	if _pinching:
		# 双指变单指：把剩下那根重新设为平移起点，防止松手瞬间 K 线跳一下
		_pinching = false
		_pinch_prev_dist = 0.0
		if _points.size() == 1:
			var ks: Array = _points.keys()
			var left: int = int(ks[0])
			var lp: Vector2 = _points[left]
			_begin_single(left, lp)
			_press_t = 99.0        # 不触发双击
			_long_fired = true     # 也不再弹长按光标
		return
	if _points.is_empty():
		_touching = false
		_finish_tap(p.x)
		_pointer = -1
		_dragging = false

func _on_drag(index: int, p: Vector2) -> void:
	if not _points.has(index):
		return
	_points[index] = p
	_last_pos = p
	# ---- 双指捏合：距离变大=张开=放大，距离变小=捏合=缩小 ----
	if _pinching and _points.size() >= 2:
		var dist: float = _two_finger_span()
		if _pinch_prev_dist > 1.0 and dist > 1.0:
			var factor: float = clampf(_pinch_prev_dist / dist, 0.55, 1.8)
			# _points 里存的是 Chart 局部坐标，mid 已经是局部 x，
			# 不能再减全局原点，否则缩放锚点会偏到屏幕外。
			var mid: float = _two_finger_mid_x()
			var ratio: float = clampf(mid / maxf(1.0, float(chart.size.x)), 0.0, 1.0)
			chart.zoom(ratio, factor)
		_pinch_prev_dist = dist
		return
	if index != _pointer:
		return
	# ---- 单指平移 ----
	var dx: float = p.x - _last_x
	_last_x = p.x
	if absf(p.x - _start_x) > TAP_SLOP:
		_dragging = true
		_press_t = 99.0
	if _dragging:
		if chart.pan_by_bars(dx * pan_speed):
			_vel = dx * pan_speed
		else:
			_vel = 0.0

func _on_mouse_button(pressed: bool, p: Vector2) -> void:
	if pressed:
		_mouse_down = true
		_touching = false
		_dragging = false
		_pinching = false
		_last_x = p.x
		_start_x = p.x
		_last_pos = p
		_press_t = 0.0
		_vel = 0.0
		_long_fired = false
	else:
		if not _mouse_down:
			return
		_mouse_down = false
		_finish_tap(p.x)
		_dragging = false

func _on_mouse_motion(p: Vector2) -> void:
	if not _mouse_down:
		return
	_last_pos = p
	var dx: float = p.x - _last_x
	_last_x = p.x
	if absf(p.x - _start_x) > TAP_SLOP:
		_dragging = true
		_press_t = 99.0
	if _dragging:
		if chart.pan_by_bars(dx * pan_speed):
			_vel = dx * pan_speed
		else:
			_vel = 0.0

func _idx_near(x: float) -> int:
	var cw: float = float(chart.get_cw())
	if cw <= 0.0:
		return -1
	return int(chart.bar_count() - chart.view_count - chart.view_offset) + floori(x / cw)
