extends Control
## 主界面 v4：白色主题 / 手机竖屏优先 / 双页面结构
##   START 启动页 → HOME 公司列表主页 → DETAIL 单股 K 线与交易详情
## 字号按 720 宽基准放大，按钮最小触摸高度 50，四边统一留白。
## 所有绘制与点击判定共用 _layout() 出的同一份 Rect。

const CASH_OPTIONS := [100000.0, 1000000.0, 10000000.0, 100000000.0]
const QTY_OPTIONS := [100, 500, 1000]
const BTN_ACCENT := Color(0.13, 0.42, 0.86)   # 本地常量：默认参数必须是编译期常量，不能写 Const.ACCENT
## 标的"大类"划分：与 instruments.json 的 group 字段一一对应，点列表顶部的小标签筛选
const GROUP_NAMES := ["全部", "半导体", "科技", "电力能源", "资源", "新能源", "军工航运", "消费医药", "商品"]
## 新闻后面的"基础小提示"池：只讲基础操作与基础常识，不出现涨跌幅度、百分比等具体数值。
## 宏观事件按哈希轮换取一条，避免每条新闻都重复同一句。
const BASE_HINTS := [
	"提示 · 点底栏暂停键或按空格可停时间，捏合或滚轮缩放 K 线，拖动可平移行情。",
	"提示 · 在主页按大类筛选公司，点某一行进入该股的 K 线详情。",
	"提示 · 红涨绿跌，K 线下方是成交量，日期写在 K 线正下方。",
	"提示 · 三档时间流速只改变快进倍率，不会改变行情本身。",
	"提示 · 休市时段不产生新 K 线，影响会留到下一次开盘集中反映。",
	"提示 · 事件冲击会随时间衰减，别把跳空高开当成长期趋势。",
	"提示 · 点底部「持仓」可看每只股票的买入后涨幅与持有天数。",
	"提示 · 面板打开时时间自动暂停，点面板外面或按关闭键即可收起。",
	"提示 · 跌停时卖单要排队，急着出手会吃额外的流动性折价。",
	"提示 · 涨停时买单要排队，一票难求时不一定能按想要的价格成交。",
	"提示 · 周 K、月 K 按真实日历切分，和日 K 用的是同一份行情。",
	"提示 · 廉政类消息属于公司治理问题，只影响涉事的那一家公司。",
	"提示 · 科研点会按季度重新评估，同赛道排名可能被后来者改写。",
	"提示 · 国运推演影响长期风险偏好，不直接决定某只股票的涨跌。",
	"提示 · 进度会自动保存，重进会接着上次的资金、持仓与新闻。",
	"提示 · 想清空重来，点底部「重置」并再确认一次即可。",
	"提示 · 顶部时间左边可直接切换流速，选中档位会高亮显示。",
	"提示 · 顶部提示条点一下可展开事件的因果说明，会自动消失。",
	"提示 · 双指张开是拉近看细节，捏合是拉远看趋势；单指左右拖可翻历史。",
	"提示 · 长按 K 线任一根会出十字光标，读开高低收；松手或移开即消失。",
	"提示 · 双击 K 线区可立刻回到最新一根，不用一路拖回去。",
]

enum Page { START, HOME, DETAIL }
var page: int = Page.START

var _custom_cash: String = ""
var _selected_period: int = Const.Period.DAY
var _current_code: String = "688001"
var _nation: Dictionary = {}
var _toast: String = ""
var _toast_until: int = 0
var _qty: int = 100
var _all_codes: Array = []
var _list_page: int = 0
var _active_group: int = 0            # 0=全部，其余对应 GROUP_NAMES
var _reset_armed: bool = false
var _s: float = 1.0                 # UI 缩放系数，随窗口尺寸变化

# ---- 新闻时间线（国运推演改成带日期的新闻流）----
var _news: Array = []                # {t, date, tag, title, body}，最新在前
var _news_open: bool = false
var _news_page: int = 0
var _hold_open: bool = false          # 持仓仓库面板
var _hold_page: int = 0
var _panel_paused_before: bool = false   # 打开面板前的暂停状态，关闭时恢复

## 事件详情：不再自动弹全屏模态（它会吞掉所有点击），改为手动打开
var _event_detail_open: bool = false
var _last_event: Dictionary = {}

# ---- 流畅性：UI 重绘节流 + 布局缓存 ----
const UI_INTERVAL_MS := 200           # 界面最多约 15Hz 重绘；行情仍按原速推进
var _ui_dirty: bool = false
var _last_ui_ms: int = 0
var _layout_cache: Dictionary = {}
var _layout_w: float = -1.0
var _layout_h: float = -1.0
var _layout_page: int = -1          # 布局缓存要跟着页面走，切页必须失效
var _list_cache: Array = []         # 主页列表行数据缓存，避免每次重绘重算 87 只标的
var _list_cache_key: String = ""

## 脚本挂在根节点 Main 自身，子节点路径是 "Chart"；不标 Control 类型（自定义成员会被判不存在）
@onready var chart = $Chart

func _ready() -> void:
	set_process_input(true)
	set_process(true)
	mouse_filter = Control.MOUSE_FILTER_STOP
	# 安卓返回键交给 _notification 自己处理（返回列表 / 退出），别让引擎直接把应用杀掉
	get_tree().set_auto_accept_quit(false)
	EventBus.price_updated.connect(_on_price_updated)
	EventBus.event_triggered.connect(_on_event)
	EventBus.toast.connect(_on_toast)
	EventBus.day_changed.connect(_on_day)
	SaveMgr.reset_done.connect(_on_reset_done)
	resized.connect(_on_resized)
	_init_nation()
	if SaveMgr.has_save():
		var d: Dictionary = SaveMgr.load_game()
		if d.has("cash") and float(d.get("init_cash", 0.0)) > 0.0:
			Market.init_market()
			SaveMgr.apply_data(d)
			page = Page.HOME
			ClockSys.start()
			_rebuild_codes()
			if chart and chart.has_method("set_symbol"):
				chart.set_symbol(_current_code, _selected_period)
			SaveMgr.enable_autosave(true)
	if _news.is_empty():
		_seed_news()
	_apply_chart_layout()
	queue_redraw()

func _on_resized() -> void:
	_layout_cache.clear()
	_apply_chart_layout()
	queue_redraw()

func _in_game() -> bool:
	return page == Page.HOME or page == Page.DETAIL

func _panel_open() -> bool:
	return _news_open or _hold_open or _event_detail_open

## 节流重绘：行情/时钟仍全速推进，界面最多 5Hz 全量重画。
## 点击、切页、弹窗、toast 走直接 queue_redraw()，保证操作即时反馈。
func _process(_delta: float) -> void:
	if _toast != "" and Time.get_ticks_msec() >= _toast_until:
		_toast = ""
		_ui_dirty = true
	if not _ui_dirty:
		return
	var now: int = Time.get_ticks_msec()
	if now - _last_ui_ms < UI_INTERVAL_MS:
		return
	_last_ui_ms = now
	_ui_dirty = false
	if page == Page.DETAIL and not _panel_open() and chart and chart.has_method("refresh"):
		chart.refresh()
	queue_redraw()

# ================= 自适应布局 =================
## 以 720×1280 竖屏为基准。旧版拿 1080 宽当基准，在 720 宽的工程里 _s≈0.67，
## 于是所有字号和按钮被整体缩小三分之一 —— 这就是"字太小、按钮点好几次才中"的根因。
func _layout() -> Dictionary:
	var w: float = maxf(320.0, get_rect().size.x)
	var h: float = maxf(480.0, get_rect().size.y)
	if not _layout_cache.is_empty() and is_equal_approx(_layout_w, w) \
			and is_equal_approx(_layout_h, h) and _layout_page == page:
		return _layout_cache
	_layout_page = page
	var portrait: bool = h > w * 1.15
	var s: float
	if portrait:
		s = clampf(w / 720.0, 0.85, 1.45)
	else:
		s = clampf(minf(w / 1280.0, h / 800.0), 0.85, 1.45)
	_s = s
	var pad: float = 20.0 * s
	var top_h: float = minf(104.0 * s, h * 0.16)
	var bottom_h: float = minf(96.0 * s, h * 0.14)
	var L: Dictionary = {
		"w": w, "h": h, "pad": pad, "s": s, "portrait": portrait,
		"top": Rect2(0, 0, w, top_h),
		"bottom": Rect2(0, h - bottom_h, w, bottom_h),
	}
	# 顶栏第一行：资产 | 三档时间流速 | 当前完整日期（流速紧贴日期左边）
	var date_w: float = clampf(w * (0.34 if portrait else 0.24), 190.0 * s, 330.0 * s)
	var date_r: Rect2 = Rect2(w - date_w - pad, 8.0 * s, date_w, top_h * 0.42)
	L["date_rect"] = date_r
	var sbw: float = clampf(66.0 * s, 56.0, 110.0)
	var sbg: float = 8.0 * s
	var sbx: float = date_r.position.x - 3.0 * (sbw + sbg)
	var sbh: float = clampf(56.0 * s, 50.0, 80.0)
	var sby: float = 8.0 * s + (top_h * 0.42 - sbh) * 0.5
	var sbs: Array = []
	for i in 3:
		sbs.append(Rect2(sbx + i * (sbw + sbg), sby, sbw, sbh))
	L["speed_btns"] = sbs
	L["speed_labels"] = ["1时", "1天", "1周"]
	L["asset_rect"] = Rect2(pad, 8.0 * s, maxf(90.0 * s, sbx - pad * 2.0), top_h * 0.42)
	L["status_rect"] = Rect2(pad, top_h * 0.46, w * 0.62 - pad, top_h * 0.26)
	L["day_rect"] = Rect2(w * 0.50, top_h * 0.74, w * 0.50 - pad, top_h * 0.22)
	# 底栏 5 键：暂停 / 单步 / 新闻 / 持仓 / 重置
	var bbs: Array = []
	var bw: float = (w - pad * 2.0) / 5.0
	for i in 5:
		bbs.append(Rect2(pad + i * bw, h - bottom_h + 12.0 * s,
				bw - 6.0 * s, bottom_h - 24.0 * s))
	L["bottom_btns"] = bbs
	if page == Page.HOME:
		_layout_home(L, w, h, pad, s, top_h, bottom_h)
	elif page == Page.DETAIL:
		_layout_detail(L, w, h, pad, s, top_h, bottom_h)
	_layout_cache = L
	_layout_w = w
	_layout_h = h
	return L

## 主页：标题 + 3×3 大类标签 + 大字公司卡片列表 + 翻页条
func _layout_home(L: Dictionary, w: float, h: float, pad: float, s: float,
		top_h: float, bottom_h: float) -> void:
	var head_h: float = 236.0 * s
	var nav_h: float = 112.0 * s
	L["home_head"] = Rect2(0, top_h, w, head_h)
	var exit_w_home: float = clampf(130.0 * s, 110.0, 200.0)
	L["home_exit"] = Rect2(w - pad - exit_w_home, top_h + 8.0 * s, exit_w_home, 46.0 * s)
	L["home_title"] = Rect2(pad, top_h + 6.0 * s, w - pad * 2.0 - exit_w_home, 48.0 * s)
	var chip_gap: float = 8.0 * s
	var chip_w: float = (w - pad * 2.0 - chip_gap * 2.0) / 3.0
	var chip_h: float = clampf(50.0 * s, 46.0, 72.0)
	var chips: Array = []
	for i in GROUP_NAMES.size():
		var col: int = i % 3
		var row_i: int = int(floor(float(i) / 3.0))
		chips.append(Rect2(pad + col * (chip_w + chip_gap),
				top_h + 60.0 * s + row_i * (chip_h + chip_gap), chip_w, chip_h))
	L["group_chips"] = chips
	var body_top: float = top_h + head_h
	var body_bottom: float = h - bottom_h - nav_h
	var list_r: Rect2 = Rect2(pad, body_top, w - pad * 2.0,
			maxf(170.0, body_bottom - body_top - pad))
	L["list"] = list_r
	var nav_y: float = h - bottom_h - nav_h + 8.0 * s
	var nav_btn_h: float = 64.0 * s
	L["list_prev"] = Rect2(pad, nav_y,
			(w - pad * 2.0) * 0.5 - 6.0 * s, nav_btn_h)
	L["list_next"] = Rect2(pad + (w - pad * 2.0) * 0.5 + 6.0 * s, nav_y,
			(w - pad * 2.0) * 0.5 - 6.0 * s, nav_btn_h)
	L["list_page_rect"] = Rect2(pad, nav_y + nav_btn_h + 4.0 * s,
			w - pad * 2.0, 30.0 * s)
	var row_h: float = clampf(104.0 * s, 90.0, 155.0)
	var rows: Array = []
	var top_y: float = list_r.position.y + 8.0 * s
	var n: int = maxi(1, int((list_r.size.y - 16.0 * s) / row_h))
	for i in n:
		rows.append(Rect2(list_r.position.x + 6.0 * s, top_y + i * row_h,
				list_r.size.x - 12.0 * s, row_h - 8.0 * s))
	L["list_rows"] = rows

## 详情页：返回/退出 → 现价 → 周期 → K线(最大块) → 交易 → 底栏
func _layout_detail(L: Dictionary, w: float, h: float, pad: float, s: float,
		top_h: float, bottom_h: float) -> void:
	var nav_h: float = 78.0 * s
	var quote_h: float = 112.0 * s
	var period_h: float = 70.0 * s
	var content_top: float = top_h + nav_h + quote_h + period_h
	var trade_h: float = clampf(156.0 * s, 130.0, 210.0)
	var avail: float = h - content_top - bottom_h - trade_h - pad * 3.0
	var chart_h: float = maxf(250.0 * s, avail)
	L["nav"] = Rect2(0, top_h, w, nav_h)
	var back_w: float = clampf(210.0 * s, 170.0, 320.0)
	var exit_w: float = clampf(150.0 * s, 130.0, 230.0)
	L["back_btn"] = Rect2(pad, top_h + 10.0 * s, back_w, nav_h - 20.0 * s)
	L["exit_btn"] = Rect2(w - pad - exit_w, top_h + 10.0 * s, exit_w, nav_h - 20.0 * s)
	L["quote"] = Rect2(0, top_h + nav_h, w, quote_h)
	L["period"] = Rect2(0, top_h + nav_h + quote_h, w, period_h)
	var pw: float = (w - pad * 2.0) / 7.0
	var per_r: Rect2 = L["period"]
	var pbs: Array = []
	for i in 7:
		pbs.append(Rect2(pad + i * pw, per_r.position.y + 6.0 * s,
				pw - 4.0 * s, period_h - 12.0 * s))
	L["period_btns"] = pbs
	L["chart"] = Rect2(pad, content_top + pad, w - pad * 2.0, chart_h)
	var trade_r: Rect2 = Rect2(pad, content_top + pad + chart_h + pad,
			w - pad * 2.0, trade_h)
	L["trade"] = trade_r
	var qw: float = trade_r.size.x / 4.0
	var qh: float = clampf(56.0 * s, 50.0, 78.0)
	var qbs: Array = []
	for i in 4:
		qbs.append(Rect2(trade_r.position.x + i * qw, trade_r.position.y + 6.0 * s,
				qw - 6.0 * s, qh))
	L["qty_btns"] = qbs
	var act_y: float = trade_r.position.y + qh + 14.0 * s
	var act_h: float = maxf(54.0 * s, trade_r.position.y + trade_r.size.y - act_y - 8.0 * s)
	L["buy_btn"] = Rect2(trade_r.position.x, act_y, trade_r.size.x * 0.5 - 6.0 * s, act_h)
	L["sell_btn"] = Rect2(trade_r.position.x + trade_r.size.x * 0.5 + 6.0 * s,
			act_y, trade_r.size.x * 0.5 - 6.0 * s, act_h)

func _apply_chart_layout() -> void:
	if chart == null:
		return
	var L: Dictionary = _layout()
	if L.has("chart"):
		var r: Rect2 = L["chart"]
		chart.set_anchors_preset(Control.PRESET_TOP_LEFT)
		chart.set_position(r.position)
		chart.set_size(r.size)
	# 只有详情页且没开面板才画 K 线。Chart 是子节点，父节点画的覆盖层压不住它，
	# 所以面板/主页一律直接隐藏整个节点。
	chart.visible = (page == Page.DETAIL) and not _panel_open()
	chart.mouse_filter = Control.MOUSE_FILTER_STOP if chart.visible else Control.MOUSE_FILTER_IGNORE

## 字号下限 13：旧版 _fs(11) 在 720 宽下只有 7 像素，手机上根本看不清
func _fs(n: float) -> int:
	return maxi(13, int(round(n * _s)))

func _touch_ui() -> bool:
	var L: Dictionary = _layout()
	return bool(L["portrait"]) or OS.has_feature("mobile")

# ================= 绘制 =================
func _draw() -> void:
	draw_rect(get_rect(), Const.BG, true)
	if page == Page.START:
		_draw_start()
	elif _news_open:
		_draw_news_panel(_layout())
	elif _hold_open:
		_draw_holdings_panel(_layout())
	elif _event_detail_open:
		_draw_event_popup(_layout())
	elif page == Page.HOME:
		_draw_home()
	else:
		_draw_detail()
	if not _panel_open() and _toast != "" and Time.get_ticks_msec() < _toast_until:
		var L: Dictionary = _layout()
		var toast_r: Rect2 = _toast_rect(L)
		draw_rect(toast_r, Color(0.13, 0.15, 0.18), true)
		draw_rect(toast_r, Color(0.13, 0.42, 0.86), false, 2.0)
		_label(Rect2(toast_r.position.x + 16.0 * _s, toast_r.position.y,
				toast_r.size.x - 32.0 * _s, toast_r.size.y * 0.68),
				_toast, _fs(18), Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER)
		var left: float = float(_toast_until - Time.get_ticks_msec()) / 2500.0
		var bar: Rect2 = Rect2(toast_r.position.x, toast_r.position.y + toast_r.size.y - 6.0 * _s,
				toast_r.size.x * clampf(left, 0.0, 1.0), 5.0 * _s)
		draw_rect(bar, Const.ACCENT, true)
		_label(Rect2(toast_r.position.x, toast_r.position.y + toast_r.size.y * 0.68,
				toast_r.size.x, toast_r.size.y * 0.28), "自动消失，不阻断操作",
				_fs(14), Color(0.72, 0.78, 0.88), HORIZONTAL_ALIGNMENT_CENTER)

func _draw_start() -> void:
	var L: Dictionary = _layout()
	var w: float = L["w"]
	var h: float = L["h"]
	var pw: float = minf(w - 40.0 * _s, 680.0 * _s)
	var px: float = (w - pw) / 2.0
	var y: float = maxf(40.0 * _s, h * 0.14)
	_label(Rect2(px, y, pw, 64.0 * _s), "模拟炒股模拟器", _fs(38), Const.TEXT,
			HORIZONTAL_ALIGNMENT_CENTER)
	y += 74.0 * _s
	_label(Rect2(px, y, pw, 44.0 * _s), "选择初始资金", _fs(22), Const.TEXT_SUB,
			HORIZONTAL_ALIGNMENT_CENTER)
	y += 56.0 * _s
	var rects: Array = _start_rects()
	var labels: Array = ["10 万", "100 万", "1000 万", "1 亿"]
	for i in 4:
		_btn(rects[i], str(labels[i]), i == 0 and _custom_cash == "", Const.ACCENT)
	var cr: Rect2 = rects[4]
	draw_rect(cr, Const.PANEL, true)
	draw_rect(cr, Const.BORDER, false, 1.5)
	var ct: String = "自定义资金：%s（点击填入 500 万）" % (_custom_cash if _custom_cash != "" else "未设置")
	_label(cr, ct, _fs(19), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_btn(rects[5], "开始游戏", true, Const.UP)
	if SaveMgr.has_save():
		_btn(rects[6], "读取上次存档", false, Const.ACCENT)
	_label(Rect2(px, h - 56.0 * _s, pw, 36.0 * _s),
			"白色主题 · 竖屏自适应 · 点公司看 K 线", _fs(17), Const.TEXT_SUB,
			HORIZONTAL_ALIGNMENT_CENTER)

func _start_rects() -> Array:
	var L: Dictionary = _layout()
	var w: float = L["w"]
	var h: float = L["h"]
	var pw: float = minf(w - 40.0 * _s, 680.0 * _s)
	var px: float = (w - pw) / 2.0
	var y: float = maxf(40.0 * _s, h * 0.14) + 130.0 * _s
	var rh: float = clampf(80.0 * _s, 58.0, 104.0)
	var gap: float = 14.0 * _s
	var out: Array = []
	for i in 7:
		out.append(Rect2(px, y + i * (rh + gap), pw, rh))
	return out

## 顶栏：两个页面共用
func _draw_topbar(L: Dictionary) -> void:
	var w: float = L["w"]
	var top: Rect2 = L["top"]
	draw_rect(top, Const.HEADER, true)
	draw_line(Vector2(0, top.size.y), Vector2(w, top.size.y), Const.BORDER, 1.5)
	var pf: float = Portfolio.profit()
	var pcol: Color = Const.UP if pf >= 0.0 else Const.DOWN
	var asset_r: Rect2 = L["asset_rect"]
	_label(asset_r, "总资产 %.0f · 盈亏 %+.0f" % [Portfolio.total_asset(), pf],
			_fs(18), pcol)
	var sbs: Array = L["speed_btns"]
	var slabels: Array = L["speed_labels"]
	for i in sbs.size():
		var sr: Rect2 = sbs[i]
		var on: bool = (ClockSys.speed == i)
		draw_rect(sr, Const.ACCENT if on else Const.CARD, true)
		if not on:
			draw_rect(sr, Const.BORDER, false, 1.5)
		_label(sr, str(slabels[i]), _fs(19), Color(1, 1, 1) if on else Const.TEXT_SUB,
				HORIZONTAL_ALIGNMENT_CENTER)
	var date_r2: Rect2 = L["date_rect"]
	_label(date_r2, Const.game_full_datetime(ClockSys.game_minute),
			_fs(18), Const.TEXT, HORIZONTAL_ALIGNMENT_RIGHT)
	var pause_hint: String = "底栏暂停键" if _touch_ui() else "空格暂停"
	var st: String = "%s · 每秒 +%s · %s · %s" % [
			ClockSys.speed_label(), ClockSys.days_per_second(),
			"已暂停" if ClockSys.paused else "运行中", pause_hint]
	var status_r: Rect2 = L["status_rect"]
	var day_r: Rect2 = L["day_rect"]
	_label(status_r, st, _fs(15), Const.TEXT_SUB)
	_label(day_r,
			"第 %d 日 · 累计 %d 分钟" % [ClockSys.current_day(), ClockSys.game_minute],
			_fs(14), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_RIGHT)

## 底栏：两个页面共用
func _draw_bottom(L: Dictionary) -> void:
	var w: float = L["w"]
	var br: Rect2 = L["bottom"]
	draw_rect(br, Const.HEADER, true)
	draw_line(Vector2(0, br.position.y), Vector2(w, br.position.y), Const.BORDER, 1.5)
	var blabels: Array = ["继续" if ClockSys.paused else "暂停", "单步", "新闻", "持仓", "重置"]
	var bbs: Array = L["bottom_btns"]
	for i in bbs.size():
		var r: Rect2 = bbs[i]
		var on: bool = (i == 2 and _news_open) or (i == 3 and _hold_open)
		if i == 4 and _reset_armed:
			_btn(r, "确认?", true, Const.UP)
		else:
			_btn(r, str(blabels[i]), on, Const.ACCENT)

## 主页：只有公司列表
func _draw_home() -> void:
	var L: Dictionary = _layout()
	_draw_topbar(L)
	var head: Rect2 = L["home_head"]
	draw_rect(head, Const.PANEL, true)
	var vis: Array = _view_codes()
	var title_r: Rect2 = L["home_title"]
	_label(title_r, "公司列表 · 共 %d 家" % vis.size(), _fs(26), Const.TEXT)
	_label(Rect2(title_r.position.x, title_r.position.y + 44.0 * _s,
			title_r.size.x, 30.0 * _s),
			"点任意一行进入该股 K 线与交易", _fs(16), Const.TEXT_SUB)
	var home_exit_r: Rect2 = L["home_exit"]
	_btn(home_exit_r, "退出", false, Const.FLAT)
	var chips: Array = L["group_chips"]
	for i in chips.size():
		var cr: Rect2 = chips[i]
		var on: bool = (i == _active_group)
		draw_rect(cr, Const.ACCENT if on else Const.CARD, true)
		if not on:
			draw_rect(cr, Const.BORDER, false, 1.5)
		_label(cr, GROUP_NAMES[i], _fs(18), Color(1, 1, 1) if on else Const.TEXT_SUB,
				HORIZONTAL_ALIGNMENT_CENTER)
	_draw_list(L)
	var prev_btn: Rect2 = L["list_prev"]
	var next_btn: Rect2 = L["list_next"]
	_btn(prev_btn, "◀ 上一页", false, Const.ACCENT)
	_btn(next_btn, "下一页 ▶", false, Const.ACCENT)
	var rows: Array = L["list_rows"]
	var per: int = maxi(1, rows.size())
	var pages: int = maxi(1, ceili(float(_view_codes().size()) / float(per)))
	var page_r: Rect2 = L["list_page_rect"]
	_label(page_r, "第 %d / %d 页" % [_list_page + 1, pages],
			_fs(16), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_draw_bottom(L)

## 主页列表：每张卡片大字，右侧现价与涨跌幅，持仓有标记
func _draw_list(L: Dictionary) -> void:
	var lr: Rect2 = L["list"]
	draw_rect(lr, Const.CARD, true)
	draw_rect(lr, Const.BORDER, false, 1.5)
	var rows: Array = L["list_rows"]
	var per: int = maxi(1, rows.size())
	var start: int = _list_page * per
	var key: String = "%d_%d_%d" % [_active_group, _list_page, per]
	if key != _list_cache_key:
		_list_cache = _build_list_rows(start, per)
		_list_cache_key = key
	for i in rows.size():
		var r: Rect2 = rows[i]
		if start + i >= _list_cache.size():
			break
		var item: Dictionary = _list_cache[i]
		var sel: bool = (str(item["code"]) == _current_code)
		draw_rect(r, Const.ACCENT_BG if sel else Const.PANEL, true)
		draw_rect(r, Const.BORDER, false, 1.0)
		if sel:
			draw_rect(Rect2(r.position.x, r.position.y, 5.0 * _s, r.size.y), Const.ACCENT, true)
		var ins: float = 16.0 * _s
		var left_w: float = r.size.x * 0.58
		var right_x: float = r.position.x + r.size.x * 0.60
		var right_w: float = r.size.x * 0.38
		_label(Rect2(r.position.x + ins, r.position.y + 6.0 * _s, left_w, 42.0 * _s),
				str(item["name"]), _fs(27), Const.TEXT)
		_label(Rect2(r.position.x + ins, r.position.y + 50.0 * _s, left_w, 34.0 * _s),
				str(item["sub"]), _fs(17), Const.TEXT_SUB)
		var dcol: Color = Const.UP if float(item["chg"]) >= 0.0 else Const.DOWN
		_label(Rect2(right_x, r.position.y + 6.0 * _s, right_w, 42.0 * _s),
				"%.2f" % float(item["last"]), _fs(27), dcol, HORIZONTAL_ALIGNMENT_RIGHT)
		_label(Rect2(right_x, r.position.y + 50.0 * _s, right_w, 34.0 * _s),
				"%+.2f%%" % float(item["chg"]), _fs(21), dcol, HORIZONTAL_ALIGNMENT_RIGHT)

## 行数据只在翻页/切大类时算一次，避免 5Hz 重绘重复遍历全部标的
func _build_list_rows(start: int, per: int) -> Array:
	var vis: Array = _view_codes()
	var out: Array = []
	for i in per:
		var idx: int = start + i
		if idx >= vis.size():
			break
		var code: String = str(vis[idx])
		var di: Dictionary = Market.instrument(code)
		var dl: float = Market.last_price(code)
		var db: float = float(di.get("base", dl))
		var dc: float = (dl / db - 1.0) * 100.0 if db > 0.0 else 0.0
		var sub: String = "%s · %s" % [code, str(di.get("group", ""))]
		if Portfolio.positions.has(code):
			sub += " · 持仓 %d" % int(Portfolio.positions[code].get("qty", 0))
		out.append({"code": code, "name": str(di.get("name", code)),
				"sub": sub, "last": dl, "chg": dc})
	return out

## 详情页
func _draw_detail() -> void:
	var L: Dictionary = _layout()
	var w: float = L["w"]
	_draw_topbar(L)
	var nav: Rect2 = L["nav"]
	draw_rect(nav, Const.PANEL, true)
	draw_line(Vector2(0, nav.position.y + nav.size.y),
			Vector2(w, nav.position.y + nav.size.y), Const.BORDER, 1.5)
	var back_b: Rect2 = L["back_btn"]
	var exit_b: Rect2 = L["exit_btn"]
	_btn(back_b, "← 公司列表", false, Const.ACCENT)
	_btn(exit_b, "退出", false, Const.FLAT)
	# 现价栏
	var q: Rect2 = L["quote"]
	draw_rect(q, Const.CARD, true)
	draw_line(Vector2(0, q.position.y + q.size.y),
			Vector2(w, q.position.y + q.size.y), Const.BORDER, 1.5)
	var inst: Dictionary = Market.instrument(_current_code)
	var nm: String = str(inst.get("name", _current_code))
	var last: float = Market.last_price(_current_code)
	var base: float = float(inst.get("base", last))
	var chg: float = (last / base - 1.0) * 100.0 if base > 0.0 else 0.0
	var ccol: Color = Const.UP if chg >= 0.0 else Const.DOWN
	var pad: float = L["pad"]
	_label(Rect2(pad, q.position.y + 6.0 * _s, w * 0.38, 48.0 * _s),
			nm, _fs(29), Const.TEXT)
	_label(Rect2(pad, q.position.y + 56.0 * _s, w * 0.52, 40.0 * _s),
			"%s · %s" % [_current_code, str(inst.get("group", ""))],
			_fs(17), Const.TEXT_SUB)
	_label(Rect2(w * 0.38, q.position.y + 4.0 * _s, w * 0.28, 56.0 * _s),
			"%.2f" % last, _fs(36), ccol, HORIZONTAL_ALIGNMENT_CENTER)
	_label(Rect2(w * 0.38, q.position.y + 60.0 * _s, w * 0.28, 38.0 * _s),
			"%+.2f%%" % chg, _fs(22), ccol, HORIZONTAL_ALIGNMENT_CENTER)
	var held: int = 0
	if Portfolio.positions.has(_current_code):
		held = int(Portfolio.positions[_current_code].get("qty", 0))
	_label(Rect2(w * 0.68, q.position.y + 6.0 * _s, w * 0.32 - pad, 44.0 * _s),
			"持仓 %d" % held, _fs(20), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_RIGHT)
	var held_perf: Dictionary = Portfolio.position_perf(_current_code)
	if not held_perf.is_empty():
		var hpct: float = float(held_perf.get("pct", 0.0))
		var hpcol: Color = Const.UP if hpct >= 0.0 else Const.DOWN
		_label(Rect2(w * 0.68, q.position.y + 52.0 * _s, w * 0.32 - pad, 42.0 * _s),
				"买入后 %+.2f%%" % (hpct * 100.0), _fs(19), hpcol,
				HORIZONTAL_ALIGNMENT_RIGHT)
	# 周期
	var pr: Rect2 = L["period"]
	draw_rect(pr, Const.PANEL, true)
	var pbs: Array = L["period_btns"]
	for i in pbs.size():
		_btn(pbs[i], str(Const.PERIOD_LABEL[i]), i == _selected_period, Const.ACCENT)
	# K 线区边框（蜡烛由子节点 Chart 自己画）
	var cr: Rect2 = L["chart"]
	draw_rect(cr, Const.CARD, true)
	draw_rect(cr, Const.BORDER, false, 1.5)
	# 交易
	var trade_r: Rect2 = L["trade"]
	draw_rect(trade_r, Const.PANEL, true)
	draw_rect(trade_r, Const.BORDER, false, 1.5)
	var qbs: Array = L["qty_btns"]
	var qlabels: Array = ["100", "500", "1000", "全仓"]
	for i in qbs.size():
		var on: bool = (i < 3 and _qty == QTY_OPTIONS[i]) or (i == 3 and _qty < 0)
		_btn(qbs[i], str(qlabels[i]), on, Const.ACCENT)
	var buy_b: Rect2 = L["buy_btn"]
	var sell_b: Rect2 = L["sell_btn"]
	_btn(buy_b, "买入", true, Const.UP)
	_btn(sell_b, "卖出", true, Const.DOWN)
	_draw_bottom(L)

# ================= 面板（不透明覆盖层）=================
## 面板所有可点区域与绘制共用这一份几何
func _news_geometry(L: Dictionary) -> Dictionary:
	var w: float = L["w"]
	var h: float = L["h"]
	var pad: float = L["pad"]
	var pw: float = w - pad * 2.0
	var ph: float = h - pad * 2.0
	var r: Rect2 = Rect2(pad, pad, pw, ph)
	var head_h: float = 96.0 * _s
	var foot_h: float = 132.0 * _s
	var body: Rect2 = Rect2(r.position.x + 18.0 * _s, r.position.y + head_h,
			pw - 36.0 * _s, ph - head_h - foot_h)
	var per: int = clampi(int(body.size.y / (140.0 * _s)), 2, 8)
	var row_h: float = body.size.y / float(per)
	var rows: Array = []
	for i in per:
		rows.append(Rect2(body.position.x, body.position.y + i * row_h,
				body.size.x, row_h - 8.0 * _s))
	var by: float = r.position.y + ph - foot_h
	var bw: float = (pw - 36.0 * _s) / 4.0
	var btns: Array = []
	for i in 4:
		btns.append(Rect2(r.position.x + 18.0 * _s + i * bw, by + 52.0 * _s,
				bw - 6.0 * _s, foot_h - 62.0 * _s))
	var page_r: Rect2 = Rect2(r.position.x + 18.0 * _s, by + 4.0 * _s,
			pw - 36.0 * _s, 26.0 * _s)
	var tip_r: Rect2 = Rect2(r.position.x + 18.0 * _s, by + 28.0 * _s,
			pw - 36.0 * _s, 24.0 * _s)
	return {"r": r, "body": body, "rows": rows, "btns": btns, "per": per,
			"page_r": page_r, "tip_r": tip_r, "foot_top": by}

func _draw_news_panel(L: Dictionary) -> void:
	var G: Dictionary = _news_geometry(L)
	var r: Rect2 = G["r"]
	draw_rect(Rect2(0, 0, L["w"], L["h"]), Color(0.94, 0.95, 0.97), true)
	draw_rect(r, Const.CARD, true)
	draw_rect(r, Const.ACCENT, false, 2.5)
	_label(Rect2(r.position.x + 18.0 * _s, r.position.y + 8.0 * _s,
			r.size.x - 36.0 * _s, 52.0 * _s), "市场新闻 · 时间线", _fs(30), Const.TEXT)
	_label(Rect2(r.position.x + 18.0 * _s, r.position.y + 60.0 * _s,
			r.size.x - 36.0 * _s, 32.0 * _s),
			"当前 " + Const.game_full_datetime(ClockSys.game_minute)
					+ " · " + Const.season_name(Const.game_month(ClockSys.game_minute)),
			_fs(17), Const.TEXT_SUB)
	draw_line(Vector2(r.position.x + 18.0 * _s, r.position.y + 94.0 * _s),
			Vector2(r.position.x + r.size.x - 18.0 * _s, r.position.y + 94.0 * _s),
			Const.BORDER, 1.5)
	var rows: Array = G["rows"]
	var per: int = int(G["per"])
	var pages: int = maxi(1, ceili(float(_news.size()) / float(per)))
	_news_page = clampi(_news_page, 0, pages - 1)
	var start: int = _news_page * per
	for i in per:
		var idx: int = start + i
		if idx >= _news.size():
			break
		var rr: Rect2 = rows[i]
		var item: Dictionary = _news[idx]
		draw_rect(rr, Const.PANEL, true)
		draw_rect(Rect2(rr.position.x, rr.position.y, 5.0 * _s, rr.size.y), Const.ACCENT, true)
		_label(Rect2(rr.position.x + 16.0 * _s, rr.position.y + 4.0 * _s,
				rr.size.x - 32.0 * _s, 30.0 * _s),
				"%s   ·   %s   ·   %s" % [
					str(item["date"]), Const.season_name(Const.game_month(int(item.get("t", 0)))),
					str(item["tag"])], _fs(17), Const.ACCENT)
		_label(Rect2(rr.position.x + 16.0 * _s, rr.position.y + 36.0 * _s,
				rr.size.x - 32.0 * _s, 38.0 * _s), str(item["title"]), _fs(22), Const.TEXT)
		_label(Rect2(rr.position.x + 16.0 * _s, rr.position.y + 74.0 * _s,
				rr.size.x - 32.0 * _s, 30.0 * _s), str(item["body"]), _fs(17), Const.TEXT_SUB)
		var hint: String = str(item.get("hint", ""))
		if hint == "":
			hint = "提示 · 关注该事件对应的板块与持仓；红涨绿跌，事件冲击会随时间衰减。"
		var hr: Rect2 = Rect2(rr.position.x + 16.0 * _s, rr.position.y + 106.0 * _s,
				rr.size.x - 32.0 * _s, 28.0 * _s)
		draw_rect(hr, Const.ACCENT_BG, true)
		_label(hr, hint, _fs(15), Const.ACCENT)
	var btns: Array = G["btns"]
	_label(G["page_r"], "第 %d / %d 页 · 共 %d 条" % [_news_page + 1, pages, _news.size()],
			_fs(16), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_label(G["tip_r"],
			"小提示：宏观按板块扩散 · 廉政只影响涉事公司 · 科研点每季度重评 · 点提示条看因果",
			_fs(14), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_btn(btns[0], "◀ 上一页", false)
	_btn(btns[1], "下一页 ▶", false)
	_btn(btns[2], "推进一季度", false)
	_btn(btns[3], "关闭", true, Const.ACCENT)

func _draw_holdings_panel(L: Dictionary) -> void:
	var G: Dictionary = _news_geometry(L)
	var r: Rect2 = G["r"]
	draw_rect(Rect2(0, 0, L["w"], L["h"]), Color(0.94, 0.95, 0.97), true)
	draw_rect(r, Const.CARD, true)
	draw_rect(r, Const.ACCENT, false, 2.5)
	_label(Rect2(r.position.x + 18.0 * _s, r.position.y + 8.0 * _s,
			r.size.x * 0.36, 50.0 * _s), "持仓仓库", _fs(30), Const.TEXT)
	_label(Rect2(r.position.x + r.size.x * 0.36, r.position.y + 12.0 * _s,
			r.size.x * 0.64 - 18.0 * _s, 44.0 * _s),
			"现金 %.0f · 市值 %.0f · 总资产 %.0f · 盈亏 %+.0f" % [
					Portfolio.cash, Portfolio.market_value(), Portfolio.total_asset(), Portfolio.profit()],
			_fs(16), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_RIGHT)
	var hx0: float = r.position.x + 18.0 * _s
	var hw: float = r.size.x - 36.0 * _s
	var hy: float = r.position.y + 58.0 * _s
	_label(Rect2(hx0 + 14.0 * _s, hy, hw * 0.34, 30.0 * _s), "名称 / 代码", _fs(16), Const.ACCENT)
	_label(Rect2(hx0 + hw * 0.34, hy, hw * 0.12, 30.0 * _s), "数量", _fs(16), Const.ACCENT)
	_label(Rect2(hx0 + hw * 0.46, hy, hw * 0.13, 30.0 * _s), "成本", _fs(16), Const.ACCENT)
	_label(Rect2(hx0 + hw * 0.59, hy, hw * 0.13, 30.0 * _s), "现价", _fs(16), Const.ACCENT)
	_label(Rect2(hx0 + hw * 0.72, hy, hw * 0.13, 30.0 * _s), "买入后涨幅", _fs(15), Const.ACCENT)
	_label(Rect2(hx0 + hw * 0.85, hy, hw * 0.15, 30.0 * _s), "盈亏", _fs(16), Const.ACCENT,
			HORIZONTAL_ALIGNMENT_RIGHT)
	draw_line(Vector2(hx0, r.position.y + 92.0 * _s),
			Vector2(hx0 + hw, r.position.y + 92.0 * _s), Const.BORDER, 1.5)
	var codes: Array = _holding_codes()
	var rows: Array = G["rows"]
	var per: int = maxi(1, int(G["per"]))
	var pages: int = maxi(1, ceili(float(codes.size()) / float(per)))
	_hold_page = clampi(_hold_page, 0, pages - 1)
	if codes.is_empty():
		_label(Rect2(r.position.x + 18.0 * _s, r.position.y + 170.0 * _s,
				r.size.x - 36.0 * _s, 50.0 * _s),
				"还没有买入任何股票。在详情页点「买入」后这里会出现持仓。",
				_fs(20), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	var start: int = _hold_page * per
	for i in per:
		var idx: int = start + i
		if idx >= codes.size():
			break
		var rr: Rect2 = rows[i]
		var code: String = str(codes[idx])
		var p: Dictionary = Portfolio.positions[code]
		var qty: int = int(p.get("qty", 0))
		var cost: float = float(p.get("cost", 0.0))
		var last: float = Market.last_price(code)
		var perf: Dictionary = Portfolio.position_perf(code)
		var pct: float = float(perf.get("pct", (last - cost) / maxf(0.01, cost)))
		var pnl: float = float(perf.get("pnl", (last - cost) * float(qty)))
		var buy_t: int = int(perf.get("buy_t", ClockSys.game_minute))
		var held: int = int(perf.get("held_days", 0))
		var pcol: Color = Const.UP if pct >= 0.0 else Const.DOWN
		var nm: String = str(Market.instrument(code).get("name", code))
		draw_rect(rr, Const.PANEL, true)
		draw_rect(Rect2(rr.position.x, rr.position.y, 5.0 * _s, rr.size.y), Const.ACCENT, true)
		var cw: float = rr.size.x
		_label(Rect2(rr.position.x + 14.0 * _s, rr.position.y + 6.0 * _s, cw * 0.34, 36.0 * _s),
				nm, _fs(21), Const.TEXT)
		_label(Rect2(rr.position.x + 14.0 * _s, rr.position.y + 44.0 * _s, cw * 0.34, 30.0 * _s),
				code, _fs(16), Const.TEXT_SUB)
		_label(Rect2(rr.position.x + cw * 0.34, rr.position.y + 8.0 * _s, cw * 0.12, 36.0 * _s),
				str(qty), _fs(20), Const.TEXT)
		_label(Rect2(rr.position.x + cw * 0.46, rr.position.y + 8.0 * _s, cw * 0.13, 36.0 * _s),
				"%.2f" % cost, _fs(18), Const.TEXT_SUB)
		_label(Rect2(rr.position.x + cw * 0.59, rr.position.y + 8.0 * _s, cw * 0.13, 36.0 * _s),
				"%.2f" % last, _fs(18), Const.TEXT)
		_label(Rect2(rr.position.x + cw * 0.72, rr.position.y + 8.0 * _s, cw * 0.13, 36.0 * _s),
				"%+.2f%%" % (pct * 100.0), _fs(19), pcol)
		_label(Rect2(rr.position.x + cw * 0.85, rr.position.y + 8.0 * _s, cw * 0.15, 36.0 * _s),
				"%+.0f" % pnl, _fs(19), pcol, HORIZONTAL_ALIGNMENT_RIGHT)
		_label(Rect2(rr.position.x + cw * 0.34, rr.position.y + 48.0 * _s, cw * 0.42, 28.0 * _s),
				"买入 %s · 持有 %d 天" % [Const.game_datetime(buy_t), held],
				_fs(15), Const.TEXT_SUB)
		_label(Rect2(rr.position.x + cw * 0.72, rr.position.y + 48.0 * _s, cw * 0.28, 28.0 * _s),
				"点此行跳到 K 线", _fs(15), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_RIGHT)
	var btns: Array = G["btns"]
	_label(G["page_r"], "共 %d 只 · 第 %d / %d 页" % [codes.size(), _hold_page + 1, pages],
			_fs(16), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_label(G["tip_r"], "小提示：涨幅按每只股票的建仓成本单独计算 · 点某一行可跳到该股 K 线",
			_fs(14), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_btn(btns[0], "◀ 上一页", false)
	_btn(btns[1], "下一页 ▶", false)
	_btn(btns[2], "刷新行情", false)
	_btn(btns[3], "关闭", true, Const.ACCENT)

func _draw_event_popup(L: Dictionary) -> void:
	var w: float = L["w"]
	var h: float = L["h"]
	var pad_e: float = L["pad"]
	var pw: float = w - pad_e * 2.0
	var ph: float = minf(h * 0.78, 760.0 * _s)
	var r: Rect2 = Rect2((w - pw) / 2.0, (h - ph) / 2.0, pw, ph)
	draw_rect(Rect2(0, 0, w, h), Color(0.94, 0.95, 0.97), true)
	draw_rect(r, Const.CARD, true)
	draw_rect(r, Const.ACCENT, false, 2.5)
	var ix: float = r.position.x + 24.0 * _s
	var iw: float = pw - 48.0 * _s
	_label(Rect2(ix, r.position.y + 18.0 * _s, iw, 54.0 * _s),
			str(_last_event.get("title", "事件")), _fs(28), Const.TEXT,
			HORIZONTAL_ALIGNMENT_CENTER)
	draw_line(Vector2(ix, r.position.y + 78.0 * _s),
			Vector2(ix + iw, r.position.y + 78.0 * _s), Const.BORDER, 1.5)
	_label(Rect2(ix, r.position.y + 88.0 * _s, iw, 40.0 * _s),
			"【提示模式】为什么涨跌", _fs(22), Const.ACCENT)
	_wrap_text(ix, r.position.y + 138.0 * _s, iw,
			str(_last_event.get("prompt", "")), _fs(19), Const.TEXT)
	var hint_r: Rect2 = Rect2(ix, r.position.y + ph - 148.0 * _s, iw, 52.0 * _s)
	draw_rect(hint_r, Const.ACCENT_BG, true)
	_label(hint_r, _hint_from_event(_last_event), _fs(17), Const.ACCENT)
	var btn: Rect2 = Rect2(r.position.x + pw / 2.0 - 130.0 * _s,
			r.position.y + ph - 82.0 * _s, 260.0 * _s, 62.0 * _s)
	_btn(btn, "关闭", true, Const.ACCENT)

## 简单中文换行（按字符数切行，避免长文本溢出弹窗）
func _wrap_text(x: float, y: float, width: float, t: String, fsz: int, col: Color) -> void:
	if ThemeDB.fallback_font == null:
		return
	var per: int = maxi(8, int(width / float(fsz) * 1.05))
	var line: String = ""
	var yy: float = y
	for ch in t:
		line += ch
		if line.length() >= per or ch == "\n":
			_label(Rect2(x, yy, width, fsz * 1.6), line.strip_edges(), fsz, col)
			yy += fsz * 1.7
			line = ""
	if line != "":
		_label(Rect2(x, yy, width, fsz * 1.6), line, fsz, col)

func _toast_rect(L: Dictionary) -> Rect2:
	var pad_t: float = L["pad"]
	var top_t: Rect2 = L["top"]
	var tw: float = L["w"] - pad_t * 2.0
	var th: float = 76.0 * _s
	return Rect2(pad_t, top_t.size.y + 10.0 * _s, tw, th)

# ================= 绘制辅助 =================
func _label(r: Rect2, t: String, font_size: int, col: Color,
		align: int = HORIZONTAL_ALIGNMENT_LEFT) -> void:
	if ThemeDB.fallback_font == null:
		return
	var y: float = r.position.y + r.size.y * 0.5 + font_size * 0.34
	draw_string(ThemeDB.fallback_font, Vector2(r.position.x, y), t, align, r.size.x, font_size, col)

func _btn(r: Rect2, label: String, filled: bool, accent: Color = BTN_ACCENT) -> void:
	if filled:
		draw_rect(r, accent, true)
	else:
		draw_rect(r, Const.CARD, true)
		draw_rect(r, Const.BORDER, false, 1.5)
	var col: Color = Color(1, 1, 1) if filled else Const.TEXT
	_label(r, label, _fs(21), col, HORIZONTAL_ALIGNMENT_CENTER)

# ================= 交互 =================
## 走 Node 级 _input：_gui_input 受 mouse_filter / 父子遮挡影响，之前"点了没反应"就栽在这里。
func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var k: InputEventKey = event
		if k.pressed and not k.echo:
			if k.keycode == KEY_SPACE and _in_game():
				if _panel_open():
					_close_panel()
				else:
					ClockSys.toggle_pause()
					EventBus.toast.emit("已暂停" if ClockSys.paused else "继续运行")
				return
			if k.keycode == KEY_ESCAPE and _panel_open():
				_close_panel()
				return
		return
	var pos: Vector2 = Vector2.ZERO
	if event is InputEventScreenTouch:
		var st: InputEventScreenTouch = event
		if not st.pressed:
			return
		var lt: InputEventScreenTouch = make_input_local(st) as InputEventScreenTouch
		if lt == null:
			return
		pos = lt.position
	elif event is InputEventMouseButton:
		var mb: InputEventMouseButton = event
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP or mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_on_wheel(mb)
			return
		if not mb.pressed or mb.button_index != MOUSE_BUTTON_LEFT:
			return
		var lm: InputEventMouseButton = make_input_local(mb) as InputEventMouseButton
		if lm == null:
			return
		pos = lm.position
	else:
		return
	# 详情页里落在 K 线区的按下：Main 不处理，也不 set_input_as_handled，
	# 事件继续送到 Chart 的 chart_input.gd 做拖动 / 捏合 / 双击 / 长按。
	if page == Page.DETAIL and not _panel_open():
		var CL: Dictionary = _layout()
		var chart_r: Rect2 = CL["chart"]
		if chart_r.has_point(pos):
			return
	if page == Page.START:
		_handle_start_tap(pos)
	else:
		_handle_tap(pos)

func _on_wheel(mb: InputEventMouseButton) -> void:
	if page != Page.DETAIL or chart == null or _panel_open():
		return
	var L: Dictionary = _layout()
	var cr: Rect2 = L["chart"]
	var lw: InputEventMouseButton = make_input_local(mb) as InputEventMouseButton
	if lw == null:
		return
	var p: Vector2 = lw.position
	if not cr.has_point(p):
		return
	var ratio: float = clampf((p.x - cr.position.x) / maxf(1.0, cr.size.x), 0.0, 1.0)
	var factor: float = 0.88 if mb.button_index == MOUSE_BUTTON_WHEEL_UP else 1.14
	chart.zoom(ratio, factor)

func _handle_start_tap(pos: Vector2) -> void:
	var rects: Array = _start_rects()
	for i in 4:
		var r: Rect2 = rects[i]
		if r.has_point(pos):
			_custom_cash = ""
			_start_game(float(CASH_OPTIONS[i]))
			return
	var cr: Rect2 = rects[4]
	if cr.has_point(pos):
		_custom_cash = "5000000"
		queue_redraw()
		return
	var sr: Rect2 = rects[5]
	if sr.has_point(pos):
		var cash: float = float(CASH_OPTIONS[0])
		if _custom_cash != "":
			cash = float(_custom_cash)
		_start_game(cash)
		return
	var lr: Rect2 = rects[6]
	if SaveMgr.has_save() and lr.has_point(pos):
		var d: Dictionary = SaveMgr.load_game()
		if not d.is_empty() and float(d.get("init_cash", 0.0)) > 0.0:
			Market.init_market()
			SaveMgr.apply_data(d)
			page = Page.HOME
			ClockSys.start()
			_rebuild_codes()
			_apply_chart_layout()
			if chart and chart.has_method("set_symbol"):
				chart.set_symbol(_current_code, _selected_period)
			SaveMgr.enable_autosave(true)
			queue_redraw()
		else:
			EventBus.toast.emit("没有可读取的进度，请重新选择初始资金")

func _start_game(cash: float) -> void:
	Market.init_market()
	Portfolio.reset(cash)
	ClockSys.start()
	page = Page.HOME
	_news_open = false
	_hold_open = false
	_event_detail_open = false
	if _news.is_empty():
		_seed_news()
	_news_page = 0
	_hold_page = 0
	_last_event = {}
	_init_nation()
	_rebuild_codes()
	_apply_chart_layout()
	if chart and chart.has_method("set_symbol"):
		chart.set_symbol(_current_code, _selected_period)
	SaveMgr.enable_autosave(true)
	EventBus.game_started.emit(cash)
	if _touch_ui():
		EventBus.toast.emit("点公司看 K 线 · 底栏暂停 · 双指捏合缩放 · 单指拖动平移")
	else:
		EventBus.toast.emit("点公司看 K 线 · 空格暂停 · 滚轮缩放 · 左键拖动平移")
	queue_redraw()

func _rebuild_codes() -> void:
	_all_codes = []
	for k in Market.instruments.keys():
		_all_codes.append(str(k))
	_list_page = 0
	_active_group = 0
	_list_cache_key = ""
	if not _all_codes.has(_current_code) and _all_codes.size() > 0:
		_current_code = str(_all_codes[0])

func _view_codes() -> Array:
	if _active_group == 0:
		return _all_codes.duplicate()
	var g: String = GROUP_NAMES[_active_group]
	var out: Array = []
	for c in _all_codes:
		if str(Market.instrument(c).get("group", "")) == g:
			out.append(c)
	return out

func _select_group(idx: int) -> void:
	_active_group = clampi(idx, 0, GROUP_NAMES.size() - 1)
	_list_page = 0
	_list_cache_key = ""
	var vis: Array = _view_codes()
	if not vis.is_empty() and not vis.has(_current_code):
		_current_code = str(vis[0])

## 主页点公司 → 详情页
func _open_detail(code: String) -> void:
	_current_code = code
	page = Page.DETAIL
	_layout_cache.clear()
	if chart and chart.has_method("set_symbol"):
		chart.set_symbol(_current_code, _selected_period)
	_apply_chart_layout()
	queue_redraw()

func _go_home() -> void:
	page = Page.HOME
	_layout_cache.clear()
	_list_cache_key = ""
	_apply_chart_layout()
	queue_redraw()

func _quit_app() -> void:
	if _in_game():
		SaveMgr.save_game()
	get_tree().quit()

## 统一点击分发：面板优先 → 公共顶栏/底栏 → 按页面处理
func _handle_tap(pos: Vector2) -> void:
	var L: Dictionary = _layout()
	if _news_open:
		_tap_news(L, pos)
		return
	if _hold_open:
		_tap_holdings(L, pos)
		return
	if _event_detail_open:
		_tap_event(L, pos)
		return
	# 顶栏三档时间流速
	var spbs: Array = L["speed_btns"]
	for i in spbs.size():
		var sr: Rect2 = spbs[i]
		if sr.has_point(pos):
			ClockSys.set_speed(i)
			EventBus.toast.emit("已切换：%s（每现实秒 +%s）" % [
					ClockSys.speed_label(), ClockSys.days_per_second()])
			queue_redraw()
			return
	# 顶部提示条：点它展开事件因果详情（2.5 秒后自动消失，不吞其它点击）
	if _toast != "" and Time.get_ticks_msec() < _toast_until:
		var tst: Rect2 = _toast_rect(L)
		if tst.has_point(pos) and not _last_event.is_empty():
			_open_panel(2)
			return
	if page == Page.HOME:
		if _tap_home(L, pos):
			return
	else:
		if _tap_detail(L, pos):
			return
	# 底栏 5 键（两个页面共用）
	var bbs: Array = L["bottom_btns"]
	for i in bbs.size():
		var br: Rect2 = bbs[i]
		if not br.has_point(pos):
			continue
		if i == 0:
			ClockSys.toggle_pause()
		elif i == 1:
			ClockSys.step_once()
			if page == Page.DETAIL and chart and chart.has_method("refresh"):
				chart.refresh()
		elif i == 2:
			_open_panel(0)
			_news_page = 0
		elif i == 3:
			_open_panel(1)
			_hold_page = 0
		elif i == 4:
			if _reset_armed:
				page = Page.START
				_news_open = false
				_hold_open = false
				_event_detail_open = false
				SaveMgr.reset_progress()
				_apply_chart_layout()
			else:
				_reset_armed = true
				EventBus.toast.emit("再点一次「确认」将清空进度")
		queue_redraw()
		return

func _tap_home(L: Dictionary, pos: Vector2) -> bool:
	var home_exit_r: Rect2 = L["home_exit"]
	if home_exit_r.has_point(pos):
		_quit_app()
		return true
	var chips: Array = L["group_chips"]
	for i in chips.size():
		var cr: Rect2 = chips[i]
		if cr.has_point(pos):
			_select_group(i)
			queue_redraw()
			return true
	var vis: Array = _view_codes()
	var rows: Array = L["list_rows"]
	var prev_r: Rect2 = L["list_prev"]
	var next_r: Rect2 = L["list_next"]
	var per: int = maxi(1, rows.size())
	var pages: int = maxi(1, ceili(float(vis.size()) / float(per)))
	if prev_r.has_point(pos):
		_list_page = maxi(0, _list_page - 1)
		_list_cache_key = ""
		queue_redraw()
		return true
	if next_r.has_point(pos):
		_list_page = mini(pages - 1, _list_page + 1)
		_list_cache_key = ""
		queue_redraw()
		return true
	for i in rows.size():
		var rr: Rect2 = rows[i]
		if rr.has_point(pos):
			var idx: int = _list_page * per + i
			if idx < vis.size():
				_open_detail(str(vis[idx]))
			return true
	return false

func _tap_detail(L: Dictionary, pos: Vector2) -> bool:
	var back_r: Rect2 = L["back_btn"]
	var exit_r: Rect2 = L["exit_btn"]
	if back_r.has_point(pos):
		_go_home()
		return true
	if exit_r.has_point(pos):
		_quit_app()
		return true
	var pbs: Array = L["period_btns"]
	for i in pbs.size():
		var r: Rect2 = pbs[i]
		if r.has_point(pos):
			_selected_period = i
			if chart and chart.has_method("set_symbol"):
				chart.set_symbol(_current_code, _selected_period)
			queue_redraw()
			return true
	var qbs: Array = L["qty_btns"]
	for i in qbs.size():
		var qr: Rect2 = qbs[i]
		if qr.has_point(pos):
			_qty = QTY_OPTIONS[i] if i < 3 else -1
			queue_redraw()
			return true
	var buy_r: Rect2 = L["buy_btn"]
	var sell_r: Rect2 = L["sell_btn"]
	if buy_r.has_point(pos):
		_do_order("BUY")
		return true
	if sell_r.has_point(pos):
		_do_order("SELL")
		return true
	return false

func _tap_news(L: Dictionary, pos: Vector2) -> void:
	var G: Dictionary = _news_geometry(L)
	var btns: Array = G["btns"]
	var per: int = maxi(1, int(G["per"]))
	var pages: int = maxi(1, ceili(float(_news.size()) / float(per)))
	var hit: bool = false
	for i in btns.size():
		var r: Rect2 = btns[i]
		if r.has_point(pos):
			hit = true
			if i == 0:
				_news_page = maxi(0, _news_page - 1)
			elif i == 1:
				_news_page = mini(pages - 1, _news_page + 1)
			elif i == 2:
				_advance_nation()
				_news_page = 0
			elif i == 3:
				_close_panel()
			break
	var pr: Rect2 = G["r"]
	if not hit and not pr.has_point(pos):
		_close_panel()
	queue_redraw()

func _tap_holdings(L: Dictionary, pos: Vector2) -> void:
	var G: Dictionary = _news_geometry(L)
	var btns: Array = G["btns"]
	var per: int = maxi(1, int(G["per"]))
	var codes: Array = _holding_codes()
	var pages: int = maxi(1, ceili(float(codes.size()) / float(per)))
	for i in btns.size():
		var r: Rect2 = btns[i]
		if r.has_point(pos):
			if i == 0:
				_hold_page = maxi(0, _hold_page - 1)
			elif i == 1:
				_hold_page = mini(pages - 1, _hold_page + 1)
			elif i == 2:
				if chart and chart.has_method("refresh"):
					chart.refresh()
			elif i == 3:
				_close_panel()
			queue_redraw()
			return
	var rows: Array = G["rows"]
	for i in rows.size():
		var rr: Rect2 = rows[i]
		if rr.has_point(pos):
			var idx: int = _hold_page * per + i
			if idx < codes.size():
				_close_panel()
				_open_detail(str(codes[idx]))
			return
	var pr: Rect2 = G["r"]
	if not pr.has_point(pos):
		_close_panel()
	queue_redraw()

func _tap_event(L: Dictionary, pos: Vector2) -> void:
	var w: float = L["w"]
	var h: float = L["h"]
	var pad_e: float = L["pad"]
	var pw: float = w - pad_e * 2.0
	var ph: float = minf(h * 0.78, 760.0 * _s)
	var er: Rect2 = Rect2((w - pw) / 2.0, (h - ph) / 2.0, pw, ph)
	var ebtn: Rect2 = Rect2(er.position.x + pw / 2.0 - 130.0 * _s,
			er.position.y + ph - 82.0 * _s, 260.0 * _s, 62.0 * _s)
	if ebtn.has_point(pos) or not er.has_point(pos):
		_close_panel()
	queue_redraw()

func _do_order(side: String) -> void:
	var qty: int = _qty
	if qty < 0:
		if side == "BUY":
			var px: float = Market.last_price(_current_code)
			qty = int(floor(Portfolio.cash / maxf(0.01, px * 1.001) / 100.0)) * 100
		else:
			qty = 0
			if Portfolio.positions.has(_current_code):
				qty = int(Portfolio.positions[_current_code].get("qty", 0))
	if qty <= 0:
		EventBus.toast.emit("数量不足")
		return
	var res: Dictionary = TradeSys.place_order(_current_code, side, qty, "MARKET")
	if not bool(res.get("ok", false)):
		EventBus.toast.emit(str(res.get("note", "下单失败")))
	_list_cache_key = ""
	queue_redraw()

# ================= 回调 =================
## 只打标记，由 _process 按 ~15Hz 统一重绘。行情/时钟仍全速推进，互不拖累。
func _on_price_updated() -> void:
	if _in_game():
		_ui_dirty = true

## 事件不再自动弹全屏模态：只入新闻时间线 + 一条非模态提示（不吞点击）。
## 想看因果说明，点顶部那条提示即可展开详情。
## 新闻后面的小提示：优先用事件自带的 hint（廉政/科研），
## 其余按板块做"偏多/承压"的定性说明，再从基础提示池轮换一条基础引导。
## 全部文案不含涨跌幅度、百分比等具体数值。
func _hint_from_event(ev: Dictionary) -> String:
	var h: String = str(ev.get("hint", ""))
	if h != "":
		return h
	var impact: Dictionary = ev.get("impact", {})
	var ups: String = ""
	var downs: String = ""
	var cnt: int = 0
	for k in impact:
		if cnt >= 3:
			break
		var nm: String = str(k)
		if float(impact[k]) >= 0.0:
			ups += ("/" if ups != "" else "") + nm
		else:
			downs += ("/" if downs != "" else "") + nm
		cnt += 1
	var pre: String = ""
	if ups != "":
		pre += ups + "偏多"
	if downs != "":
		pre += ("，" if pre != "" else "") + downs + "承压"
	if pre != "":
		pre += " · "
	var seed_i: int = floori(float(int(ev.get("news_t", 0))) / 1440.0) \
			+ str(ev.get("title", "")).length()
	return pre + str(BASE_HINTS[absi(seed_i) % BASE_HINTS.size()])

func _on_event(ev: Dictionary) -> void:
	_last_event = ev
	var body: String = str(ev.get("prompt", ""))
	if body.length() > 46:
		body = body.substr(0, 46) + "…"
	var et: int = int(ev.get("news_t", ClockSys.game_minute))
	var tag: String = str(ev.get("tag", "事件·提示"))
	_push_news_at(et, tag, str(ev.get("title", "市场事件")), body, _hint_from_event(ev))
	if _in_game() and not _news_open and not _hold_open and not _event_detail_open:
		EventBus.toast.emit("事件：" + str(ev.get("title", "市场事件")) + "（点此看详情）")
		queue_redraw()

func _on_toast(t: String) -> void:
	_toast = t
	_toast_until = Time.get_ticks_msec() + 2500
	_ui_dirty = true
	queue_redraw()

func _on_day(d: int) -> void:
	# 用"该游戏日"自己的月份，而不是当前时刻月份：
	# 快档一帧跨好几天，补发 day_changed 时每天都要按当天的季节挑事件。
	var day_month: int = Const.game_month(d * 1440 + 720)
	var ev: Dictionary = EventDB.maybe_trigger(d, day_month)
	if not ev.is_empty():
		# 把"事件发生的游戏时刻"带下去：快档一帧跨好几天时，
		# 新闻日期要落在各自那一天，不能全挤在当前的今天。
		var packed: Dictionary = ev.duplicate(true)
		packed["news_t"] = d * 1440 + 720
		EventBus.event_triggered.emit(packed)
	# 廉政事件走独立档期（平均约 90 天一次），不占用宏观事件的播报间隔
	var cor: Dictionary = EventDB.maybe_trigger_corruption(d)
	if not cor.is_empty():
		var cpacked: Dictionary = cor.duplicate(true)
		cpacked["news_t"] = d * 1440 + 720
		EventBus.event_triggered.emit(cpacked)
	# 每 30 个游戏日自动推进一次国运，时间线会自己长出来，不用手动点
	if d > 0 and d % 30 == 0:
		_advance_nation()

# ================= 重置进度 =================
## 由 SaveMgr.reset_done 触发。之前只删了存档文件，内存里的新闻时间线、
## 国运状态、事件详情、分页全留着，所以"重置"后点新闻还是上一局那一堆。
## 这里把 UI 侧的全部局内状态一次性清掉并重新播种开局旧闻。
func _on_reset_done() -> void:
	_news.clear()
	_seed_news()
	_news_page = 0
	_hold_page = 0
	_list_page = 0
	_active_group = 0
	_reset_armed = false
	_last_event = {}
	_toast = ""
	_toast_until = 0
	_init_nation()
	_current_code = "688001"
	_selected_period = Const.Period.DAY
	_qty = 100
	_news_open = false
	_hold_open = false
	_event_detail_open = false
	_panel_paused_before = true   # 时钟已 reset 为暂停，关面板时别把它恢复成运行
	_ui_dirty = true

# ================= 面板开关（打开时暂停，关闭时恢复）=================
## kind: 0=新闻 1=持仓 2=事件详情
func _open_panel(kind: int) -> void:
	_news_open = (kind == 0)
	_hold_open = (kind == 1)
	_event_detail_open = (kind == 2)
	# ★ 核心修复：Chart 是子节点，父节点 _draw 的覆盖层永远盖不住它。
	# 直接隐藏整个 Chart 节点，K 线/均线/成交量/日期轴就都不会画在面板上面。
	if chart != null:
		chart.visible = false
	# 面板打开时暂停：背景不会狂跑、也不会连环弹事件把点击吃掉
	_panel_paused_before = ClockSys.paused
	ClockSys.paused = true
	_ui_dirty = true
	queue_redraw()

func _close_panel() -> void:
	_news_open = false
	_hold_open = false
	_event_detail_open = false
	if chart != null:
		# 与 _apply_chart_layout 同一套规则：只有主界面且无面板才显示 K 线
		chart.visible = (page == Page.DETAIL) and not (_news_open or _hold_open or _event_detail_open)
		chart.mouse_filter = Control.MOUSE_FILTER_STOP if (page == Page.DETAIL) else Control.MOUSE_FILTER_IGNORE
	ClockSys.paused = _panel_paused_before
	_ui_dirty = true
	queue_redraw()

## 持仓列表：只列数量 > 0 的，按代码排序，供仓库面板翻页
func _holding_codes() -> Array:
	var out: Array = []
	for code in Portfolio.positions:
		if int(Portfolio.positions[code].get("qty", 0)) > 0:
			out.append(str(code))
	out.sort()
	return out

# ================= 新闻数据 / 国运推演 =================
func _push_news_at(t: int, tag: String, title: String, body: String, hint: String = "") -> void:
	# 按游戏时间倒序插入（最新在最前）：快档一帧补发好几天时调用顺序可能交错，
	# 单纯 push_front 会让旧新闻盖在新新闻上面。
	var item: Dictionary = {"t": t, "date": Const.game_full_datetime(t),
			"tag": tag, "title": title, "body": body, "hint": hint}
	var at: int = _news.size()
	for i in _news.size():
		if int(_news[i]["t"]) < t:
			at = i
			break
	_news.insert(at, item)
	if _news.size() > 80:
		_news = _news.slice(0, 80)

func _push_news(tag: String, title: String, body: String) -> void:
	_push_news_at(ClockSys.game_minute, tag, title, body)

## 存档用：新闻时间线也要能读回来，否则重进只剩种子旧闻
func get_news_snapshot() -> Array:
	return _news.duplicate(true)

func apply_news_snapshot(arr: Array) -> void:
	_news = arr.duplicate(true)

## 开局给时间线铺一段带日期的旧闻，面板一打开就有内容，不是空列表。
## 每条带允许月份白名单（空=全年），按该条日期所在月份过滤：
## 开局是 1 月，旧闻落在 12 月，以前这里写"迎峰度夏用电负荷创新高"纯属穿帮。
func _seed_news() -> void:
	var items: Array = [
		[-18 * 1440, "地缘", "A、B 两国边境摩擦升温", "避险资金流入黄金与原油，军工板块小幅走强。", [],
			"提示 · 地缘冲突常先涨后回吐，别把传闻阶段的涨幅当成长期趋势。"],
		[-15 * 1440, "能源", "主要产油国讨论延长减产", "WTI 与布伦特连续三日收涨，航运运价同步抬升。", [],
			"提示 · 供给端消息影响能源与航运，黄金、农产品不在这条链上。"],
		[-12 * 1440, "央行", "美联储议息会议维持利率不变", "声明偏鸽，成长板块与黄金受益，银行股承压。", [],
			"提示 · 利率预期主要影响成长股与银行，注意与个股基本面区分。"],
		[-10 * 1440, "天气", "寒潮南下 多地供暖负荷攀升", "火电日耗与煤炭补库同步走高，天然气价格短线偏强。", [11, 12, 1, 2],
			"提示 · 冬季事件：关注电力与煤炭日耗，夏季才会出现高温负荷行情。"],
		[-9 * 1440, "产业", "年末光伏抢装 组件排产回升", "并网节点临近带动抢装，组件与逆变器排产环比改善。", [11, 12],
			"提示 · 抢装改善排产，但价格战仍在压制组件毛利，别只看量不看价。"],
		[-7 * 1440, "煤炭", "北方集中供暖启动 煤炭日耗回升", "供暖季全面开启，电厂库存周转加快，动力煤获季节性支撑。", [11, 12, 1],
			"提示 · 供暖季是煤炭季节性需求，与地缘、货币政策无关。"],
		[-5 * 1440, "宏观", "年末资金面趋紧 短端利率上行", "跨年资金需求抬升，高估值板块承压，防御与黄金相对占优。", [12],
			"提示 · 资金面扰动偏短期，跨年后常自行缓解。"],
		[-3 * 1440, "海外", "海外主要指数震荡回落", "风险偏好下降，资金转向防御与贵金属。", [],
			"提示 · 避险情绪利好黄金，但不改变单个公司的经营状况。"],
		[-1 * 1440, "复盘", "上一交易周：能源领涨，金融走平", "市场等待本周宏观数据与议息纪要指引方向。", [],
			"提示 · 开局资金用左侧列表按大类挑标的，点「持仓」看买入后涨幅。"],
	]
	for it in items:
		var t: int = int(it[0])
		var allowed: Array = it[4]
		var m: int = Const.game_month(t + 720)
		if allowed.is_empty() or allowed.has(m):
			_push_news_at(t, str(it[1]), str(it[2]), str(it[3]), str(it[5]))

func _init_nation() -> void:
	for c in ["A", "B", "C", "D"]:
		_nation[c] = {"gdp": 100.0, "stable": 0.8, "policy": 0.0}

## 国运不再只弹一句 toast，而是产出 4 条带当前日期的新闻进时间线
func _advance_nation() -> void:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var m: int = ClockSys.game_minute
	var month: int = Const.game_month(m)
	var titles: Array = ["经济稳步复苏", "央行调整利率", "社会局势波动",
			"科技产业突破", "贸易摩擦升温", "能源保供政策加码"]
	# 暖季才有大规模开工，冷季是供暖保供与开年信贷，冬季不写"基建集中投产"
	if month >= 4 and month <= 10:
		titles.append_array(["基础设施大规模投产", "算力中心集中开工", "迎峰度夏电力保供"])
	else:
		titles.append_array(["迎峰度冬能源保供", "年末财政支出加速", "开年信贷投放前置"])
	for c in ["A", "B", "C", "D"]:
		var n: Dictionary = _nation[c]
		var growth: float = rng.randfn(0.02, 0.03)
		n["gdp"] = maxf(10.0, float(n["gdp"]) * (1.0 + growth))
		n["stable"] = clampf(float(n["stable"]) + rng.randfn(0.0, 0.05), 0.1, 1.0)
		n["policy"] = clampf(float(n["policy"]) + rng.randfn(0.0, 0.1), -1.0, 1.0)
		var title: String = str(titles[rng.randi_range(0, titles.size() - 1)])
		var body: String = "GDP 指数 %.1f · 稳定度 %.2f · 政策取向 %+.2f" % [
				float(n["gdp"]), float(n["stable"]), float(n["policy"])]
		_push_news_at(m, "国运·%s" % c, "%s国：%s" % [c, title], body,
				"提示 · 国运按季度演化，GDP/稳定度影响长期风险偏好，不直接决定某只股票涨跌。")
	EventBus.toast.emit("国运推演推进，新闻时间线已更新")


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if _panel_open():
			_close_panel()
		elif page == Page.DETAIL:
			_go_home()
		elif page == Page.HOME:
			_quit_app()
		return
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_quit_app()
		return
	if what == NOTIFICATION_EXIT_TREE:
		if _in_game():
			SaveMgr.save_game()
