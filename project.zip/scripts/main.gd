extends Control
## 主界面 v3：白色主题 / 自适应布局（电脑任意窗口 + 手机竖横屏）
## 顶栏(资产·速度) → 现价栏 → 周期切换 → 左标的列表 + 右K线 → 交易面板 → 底部工具栏
## 所有绘制与点击判定共用 _layout() 出的同一份 Rect，杜绝"画在这、点在那"。

const CASH_OPTIONS := [100000.0, 1000000.0, 10000000.0, 100000000.0]
const QTY_OPTIONS := [100, 500, 1000]
const BTN_ACCENT := Color(0.13, 0.42, 0.86)   # 本地常量：默认参数必须是编译期常量，不能写 Const.ACCENT
## 标的"大类"划分：与 instruments.json 的 group 字段一一对应，点列表顶部的小标签筛选
const GROUP_NAMES := ["全部", "半导体", "科技", "电力能源", "资源", "新能源", "军工航运", "消费医药", "商品"]
## 新闻后面的"基础小提示"池：只讲基础操作与基础常识，不出现涨跌幅度、百分比等具体数值。
## 宏观事件按哈希轮换取一条，避免每条新闻都重复同一句。
const BASE_HINTS := [
	"提示 · 点底栏暂停键或按空格可停时间，捏合或滚轮缩放 K 线，拖动可平移行情。",
	"提示 · 点大类标签可筛选标的，点某一行即可切换当前看的股票。",
	"提示 · 红涨绿跌，K 线下方是成交量，日期写在 K 线正下方。",
	"提示 · 三档时间流速只改变快进倍率，不会改变行情本身。",
	"提示 · 休市时段不产生新 K 线，影响会留到下一次开盘集中反映。",
	"提示 · 事件冲击会随时间衰减，别把跳空高开当成长期趋势。",
	"提示 · 点底部「持仓」可看每只股票的买入后涨幅与持有天数。",
	"提示 · 面板打开时时间自动暂停，点面板外面或按关闭键即可收起。",
	"提示 · 跌停时卖单要排队，急着出手会吃额外的流动性折价。",
	"提示 · 涨停时买单要排队，一票难求时不一定能按想要的价格成交。",
	"提示 · 周 K、月 K 按真实日历切分，和日 K 用的是同一份行情。",
	"提示 · 廉政类消息属于公司治理问题，只影响涉事的那一家公司。",
	"提示 · 科研点会按季度重新评估，同赛道排名可能被后来者改写。",
	"提示 · 国运推演影响长期风险偏好，不直接决定某只股票的涨跌。",
	"提示 · 进度会自动保存，重进会接着上次的资金、持仓与新闻。",
	"提示 · 想清空重来，点底部「重置」并再确认一次即可。",
	"提示 · 顶部时间左边可直接切换流速，选中档位会高亮显示。",
	"提示 · 顶部提示条点一下可展开事件的因果说明，会自动消失。",
	"提示 · 双指张开是拉近看细节，捏合是拉远看趋势；单指左右拖可翻历史。",
	"提示 · 长按 K 线任一根会出十字光标，读开高低收；松手或移开即消失。",
	"提示 · 双击 K 线区可立刻回到最新一根，不用一路拖回去。",
]

enum Page { START, MAIN }
var page: int = Page.START

var _custom_cash: String = ""
var _selected_period: int = Const.Period.DAY
var _current_code: String = "688001"
var _nation: Dictionary = {}
var _toast: String = ""
var _toast_until: int = 0
var _qty: int = 100
var _all_codes: Array = []
var _list_page: int = 0
var _active_group: int = 0            # 0=全部，其余对应 GROUP_NAMES
var _reset_armed: bool = false
var _s: float = 1.0                 # UI 缩放系数，随窗口尺寸变化

# ---- 新闻时间线（国运推演改成带日期的新闻流）----
var _news: Array = []                # {t, date, tag, title, body}，最新在前
var _news_open: bool = false
var _news_page: int = 0
var _hold_open: bool = false          # 持仓仓库面板
var _hold_page: int = 0
var _panel_paused_before: bool = false   # 打开面板前的暂停状态，关闭时恢复

## 事件详情：不再自动弹全屏模态（它会吞掉所有点击），改为手动打开
var _event_detail_open: bool = false
var _last_event: Dictionary = {}

# ---- 流畅性：UI 重绘节流 + 布局缓存 ----
const UI_INTERVAL_MS := 66           # 界面最多约 15Hz 重绘；行情仍按原速推进
var _ui_dirty: bool = false
var _last_ui_ms: int = 0
var _layout_cache: Dictionary = {}
var _layout_w: float = -1.0
var _layout_h: float = -1.0

## 脚本挂在根节点 Main 自身，子节点路径是 "Chart"；不标 Control 类型（自定义成员会被判不存在）
@onready var chart = $Chart

func _ready() -> void:
	# 显式开启，避免任何情况下 _input 没被调度（这就是"点了没反应"的最直接兜底）
	set_process_input(true)
	set_process(true)               # UI 节流重绘用
	mouse_filter = Control.MOUSE_FILTER_STOP
	EventBus.price_updated.connect(_on_price_updated)
	EventBus.event_triggered.connect(_on_event)
	EventBus.toast.connect(_on_toast)
	EventBus.day_changed.connect(_on_day)
	SaveMgr.reset_done.connect(_on_reset_done)
	resized.connect(_on_resized)
	_init_nation()
	# 自动读档：有存档直接回主界面
	if SaveMgr.has_save():
		var d: Dictionary = SaveMgr.load_game()
		if d.has("cash") and float(d.get("init_cash", 0.0)) > 0.0:
			Market.init_market()
			SaveMgr.apply_data(d)
			page = Page.MAIN
			ClockSys.start()
			_rebuild_codes()
			if chart and chart.has_method("set_symbol"):
				chart.set_symbol(_current_code, _selected_period)
			SaveMgr.enable_autosave(true)
	if _news.is_empty():
		_seed_news()
	_apply_chart_layout()
	queue_redraw()

func _on_resized() -> void:
	_layout_cache.clear()           # 窗口变了才重算布局，平时每帧直接命中缓存
	_apply_chart_layout()
	queue_redraw()

## 节流重绘：行情/时钟每帧都在推进，但界面没必要跟着 60Hz 全量重画。
## 点击、弹窗、toast 仍走直接 queue_redraw()，保证操作即时反馈。
func _process(_delta: float) -> void:
	if _toast != "" and Time.get_ticks_msec() >= _toast_until:
		_toast = ""
		_ui_dirty = true
	if not _ui_dirty:
		return
	var now: int = Time.get_ticks_msec()
	if now - _last_ui_ms < UI_INTERVAL_MS:
		return
	_last_ui_ms = now
	_ui_dirty = false
	# 新闻/事件覆盖层挡住 K 线时不必再聚合行情，省掉这帧的开销
	if page == Page.MAIN and not _news_open and not _hold_open and not _event_detail_open \
			and chart and chart.has_method("refresh"):
		chart.refresh()
	queue_redraw()

# ================= 自适应布局 =================
## 设计基准 1080x1900；栏高随缩放系数，宽度按实际窗口分栏。
## 窗口再小也保证 K 线区有最小高度，不会把工具栏挤出屏幕。
func _layout() -> Dictionary:
	var w: float = maxf(320.0, get_rect().size.x)
	var h: float = maxf(400.0, get_rect().size.y)
	# 窗口尺寸没变就直接复用：_draw/_draw_main/_handle_main_tap/_start_rects 一帧要调好几次，
	# 以前每次都重建整个字典 + 几十个 Rect2，是明显的帧时间浪费。
	if not _layout_cache.is_empty() and is_equal_approx(_layout_w, w) and is_equal_approx(_layout_h, h):
		return _layout_cache
	# 以宽度为主缩放；高度只做抑制（×1.6 避免桌面矮窗口把字号压到看不清）
	_s = clampf(minf(w / 1080.0, h / 1900.0 * 1.6), 0.50, 1.35)
	var pad: float = 12.0 * _s
	# 竖屏判定：高度明显大于宽度 → 走安卓手机版堆叠布局；否则走桌面左列表 + 右 K 线。
	# 同一个工程两种布局共用一套绘制/点击判定，窗口一拉宽就自动切回桌面版。
	var portrait: bool = h > w * 1.15
	if portrait:
		_s = clampf(minf(w / 1080.0, h / 1900.0 * 1.6), 0.50, 1.10)
		pad = 10.0 * _s

	# 顶栏两行：第一行"资产 + 三档速度 + 当前时间"，第二行"运行状态 + 游戏日历"
	var top_h: float = (96.0 if portrait else 92.0) * _s
	var quote_h: float = 78.0 * _s
	var period_h: float = 52.0 * _s
	var bottom_h: float = 76.0 * _s
	var trade_h: float = 138.0 * _s
	var content_top: float = top_h + quote_h + period_h

	var list_r: Rect2
	var chart_r: Rect2
	var trade_r: Rect2
	if portrait:
		# 手机版竖向堆叠：顶栏 → 现价 → 周期 → 标的(大类+翻页) → K线(最大块) → 交易 → 底栏
		var list_h: float = 290.0 * _s
		var avail: float = h - content_top - bottom_h - list_h - pad * 5.0
		trade_h = clampf(avail * 0.17, 96.0 * _s, 150.0 * _s)
		var chart_h: float = maxf(180.0 * _s, avail - trade_h - pad)
		list_r = Rect2(pad, content_top + pad, w - pad * 2.0, list_h)
		chart_r = Rect2(pad, list_r.position.y + list_h + pad, w - pad * 2.0, chart_h)
		trade_r = Rect2(pad, chart_r.position.y + chart_h + pad, w - pad * 2.0, trade_h)
	else:
		# 桌面横向：左侧标的列表常驻，右侧上下放 K 线与交易
		var content_h: float = h - content_top - bottom_h
		if content_h < 320.0 * _s:
			trade_h = maxf(80.0 * _s, content_h * 0.30)
		var dh: float = maxf(150.0 * _s, content_h - trade_h - pad * 2.0)
		trade_h = maxf(60.0 * _s, content_h - dh - pad * 2.0)
		var list_w: float = clampf(w * 0.235, 148.0 * _s, 272.0 * _s)
		var right_x: float = list_w + pad * 2.0
		var right_w: float = maxf(160.0, w - right_x - pad)
		list_r = Rect2(pad, content_top + pad, list_w - pad * 0.5, content_h - pad * 1.5)
		chart_r = Rect2(right_x, content_top + pad, right_w, dh)
		trade_r = Rect2(right_x, content_top + pad + dh + pad, right_w, trade_h - pad)

	var L: Dictionary = {
		"w": w, "h": h, "pad": pad, "s": _s, "portrait": portrait,
		"top": Rect2(0, 0, w, top_h),
		"quote": Rect2(0, top_h, w, quote_h),
		"period": Rect2(0, top_h + quote_h, w, period_h),
		"list": list_r,
		"chart": chart_r,
		"trade": trade_r,
		"bottom": Rect2(0, h - bottom_h, w, bottom_h),
	}
	# ---- 顶栏：三档时间流速按钮放在"上面当前时间"的左边（手机版设计方案）----
	var date_w: float = w * (0.30 if portrait else 0.26)
	var date_r: Rect2 = Rect2(w - date_w - pad, 0, date_w, top_h * 0.44)
	L["date_rect"] = date_r
	var sbw: float = (52.0 if portrait else 62.0) * _s
	var sbg: float = 4.0 * _s
	var sbx: float = date_r.position.x - 3.0 * (sbw + sbg) - 6.0 * _s
	var sbh: float = minf(32.0 * _s, top_h * 0.36)
	var sby: float = (top_h * 0.44 - sbh) * 0.5
	var sbs: Array = []
	for i in 3:
		sbs.append(Rect2(sbx + i * (sbw + sbg), sby, sbw, sbh))
	L["speed_btns"] = sbs
	L["speed_labels"] = ["1时", "1天", "1周"] if portrait else ["1秒=1时", "1秒=1天", "1秒=1周"]
	L["asset_rect"] = Rect2(pad, 0, maxf(60.0 * _s, sbx - pad * 2.0), top_h * 0.44)
	L["status_rect"] = Rect2(pad, top_h * 0.44, w * 0.64 - pad, top_h * 0.30)
	L["day_rect"] = Rect2(w * 0.58, top_h * 0.74, w * 0.42 - pad, top_h * 0.26)
	# 周期按钮
	var pbs: Array = []
	var pw: float = (w - pad * 2.0) / 7.0
	for i in 7:
		pbs.append(Rect2(pad + i * pw, L["period"].position.y + 6.0 * _s, pw - 4.0 * _s, period_h - 12.0 * _s))
	L["period_btns"] = pbs
	# 底部工具栏 5 键：暂停/单步/新闻/持仓/重置（三档速度已挪到顶栏日期左边）
	var bbs: Array = []
	var bw: float = (w - pad * 2.0) / 5.0
	for i in 5:
		bbs.append(Rect2(pad + i * bw, h - bottom_h + 10.0 * _s, bw - 4.0 * _s, bottom_h - 20.0 * _s))
	L["bottom_btns"] = bbs
	# 标的列表：顶部"大类"筛选标签(3列×3行) + 页脚翻页 + 行
	var lr: Rect2 = L["list"]
	var nav_h: float = 34.0 * _s
	L["list_prev"] = Rect2(lr.position.x, lr.position.y + lr.size.y - nav_h, lr.size.x * 0.5 - 2.0 * _s, nav_h)
	L["list_next"] = Rect2(lr.position.x + lr.size.x * 0.5 + 2.0 * _s, lr.position.y + lr.size.y - nav_h, lr.size.x * 0.5 - 2.0 * _s, nav_h)
	var head_h: float = 24.0 * _s
	var chip_h: float = 22.0 * _s
	var chip_col_w: float = lr.size.x / 3.0
	var chips: Array = []
	for i in GROUP_NAMES.size():
		var col: int = i % 3
		var row_i: int = int(floor(float(i) / 3.0))
		chips.append(Rect2(lr.position.x + col * chip_col_w,
				lr.position.y + head_h + row_i * chip_h,
				chip_col_w - 3.0 * _s, chip_h - 3.0 * _s))
	L["group_chips"] = chips
	var body_top: float = lr.position.y + head_h + 3.0 * chip_h + 4.0 * _s
	L["list_body_top"] = body_top
	var row_h: float = 52.0 * _s
	var body_h: float = maxf(0.0, lr.position.y + lr.size.y - nav_h - body_top - 4.0 * _s)
	var rows: Array = []
	var n: int = maxi(1, int(body_h / row_h))
	for i in n:
		rows.append(Rect2(lr.position.x, body_top + i * row_h, lr.size.x, row_h - 3.0 * _s))
	L["list_rows"] = rows
	# 交易面板：数量档 + 买/卖
	# trade_r 在本函数开头已声明（横竖两套布局各自赋值），这里从字典取回即可，
	# 不能再写一次 "var trade_r"，否则 Godot 4 报 "already a variable named trade_r"。
	trade_r = L["trade"]
	var qw: float = trade_r.size.x / 7.0
	var qbs: Array = []
	for i in 4:
		qbs.append(Rect2(trade_r.position.x + i * qw, trade_r.position.y, qw - 4.0 * _s, 40.0 * _s))
	L["qty_btns"] = qbs
	var act_y: float = trade_r.position.y + 46.0 * _s
	var act_h: float = maxf(38.0 * _s, trade_r.size.y - 50.0 * _s)
	L["buy_btn"] = Rect2(trade_r.position.x, act_y, trade_r.size.x * 0.5 - 4.0 * _s, act_h)
	L["sell_btn"] = Rect2(trade_r.position.x + trade_r.size.x * 0.5 + 4.0 * _s, act_y, trade_r.size.x * 0.5 - 4.0 * _s, act_h)
	_layout_cache = L
	_layout_w = w
	_layout_h = h
	return L

func _apply_chart_layout() -> void:
	if chart == null:
		return
	var L: Dictionary = _layout()
	var r: Rect2 = L["chart"]
	chart.set_anchors_preset(Control.PRESET_TOP_LEFT)
	chart.set_position(r.position)
	chart.set_size(r.size)
	# 启动页按钮与 Chart 区域重叠：忽略输入，避免"开始游戏"点不动
	chart.mouse_filter = Control.MOUSE_FILTER_IGNORE if page == Page.START else Control.MOUSE_FILTER_STOP
	# 只有"主界面且没开任何面板"才显示 Chart：
	# 启动页不画 K 线，面板打开时也不画（否则子节点会盖在面板上面）。
	chart.visible = (page == Page.MAIN) and not (_news_open or _hold_open or _event_detail_open)

func _fs(n: float) -> int:
	return maxi(9, int(round(n * _s)))

## 当前是否按"触摸设备"显示文案：竖屏布局（电脑上把窗口拉竖也能预览手机版）
## 或真的跑在 Android/iOS 上。只影响提示文字，功能两边都保留。
func _touch_ui() -> bool:
	var L: Dictionary = _layout()
	return bool(L["portrait"]) or OS.has_feature("mobile")

# ================= 绘制 =================
func _draw() -> void:
	draw_rect(get_rect(), Const.BG, true)
	# 面板打开时只画面板本身：不画主界面、不画 toast。
	# 关键：Chart 是 Main 的子节点，Godot 永远是"父先画、子后画"，
	# 所以父节点里画多少层覆盖都压不住 K 线 —— 必须同时隐藏 Chart（见 _open_panel）。
	var panel: bool = _news_open or _hold_open or _event_detail_open
	if page == Page.START:
		_draw_start()
	elif _news_open:
		_draw_news_panel(_layout())
	elif _hold_open:
		_draw_holdings_panel(_layout())
	elif _event_detail_open:
		_draw_event_popup(_layout())
	else:
		_draw_main()
	if not panel and _toast != "" and Time.get_ticks_msec() < _toast_until:
		var L: Dictionary = _layout()
		var toast_r: Rect2 = _toast_rect(L)
		draw_rect(toast_r, Color(0.13, 0.15, 0.18), true)
		draw_rect(toast_r, Color(0.13, 0.42, 0.86), false, 1.5)
		_label(Rect2(toast_r.position.x + 12.0 * _s, toast_r.position.y,
				toast_r.size.x - 24.0 * _s, toast_r.size.y * 0.72),
				_toast, _fs(18), Color(1, 1, 1), HORIZONTAL_ALIGNMENT_CENTER)
		# 底部进度条：明确告诉玩家"这是会自动消失的提示，不是弹窗"
		var left: float = float(_toast_until - Time.get_ticks_msec()) / 2500.0
		var bar: Rect2 = Rect2(toast_r.position.x, toast_r.position.y + toast_r.size.y - 5.0 * _s,
				toast_r.size.x * clampf(left, 0.0, 1.0), 4.0 * _s)
		draw_rect(bar, Const.ACCENT, true)
		_label(Rect2(toast_r.position.x, toast_r.position.y + toast_r.size.y * 0.72,
				toast_r.size.x, toast_r.size.y * 0.26), "自动消失，不阻断操作",
				_fs(11), Color(0.72, 0.78, 0.88), HORIZONTAL_ALIGNMENT_CENTER)

func _draw_start() -> void:
	var L: Dictionary = _layout()
	var w: float = L["w"]
	var h: float = L["h"]
	var pw: float = minf(w * 0.82, 700.0 * _s)
	var px: float = (w - pw) / 2.0
	var y: float = maxf(30.0 * _s, h * (0.18 if h > w * 1.15 else 0.09))
	_label(Rect2(px, y, pw, 56.0 * _s), "模拟炒股模拟器", _fs(40), Const.TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	y += 64.0 * _s
	_label(Rect2(px, y, pw, 40.0 * _s), "选择初始资金", _fs(22), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	y += 52.0 * _s
	var rects: Array = _start_rects()
	var labels: Array = ["10 万", "100 万", "1000 万", "1 亿"]
	for i in 4:
		_btn(rects[i], str(labels[i]), i == 0 and _custom_cash == "", Const.ACCENT)
	var cr: Rect2 = rects[4]
	draw_rect(cr, Const.PANEL, true)
	draw_rect(cr, Const.BORDER, false, 1.0)
	var ct: String = "自定义资金：%s（点击填入 500 万）" % (_custom_cash if _custom_cash != "" else "未设置")
	_label(cr, ct, _fs(19), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_btn(rects[5], "开始游戏", true, Const.UP)
	if SaveMgr.has_save():
		_btn(rects[6], "读取上次存档", false, Const.ACCENT)
	_label(Rect2(px, h - 46.0 * _s, pw, 30.0 * _s), "Godot 4.2+ · 安卓 / 桌面自适应",
			_fs(15), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)

func _start_rects() -> Array:
	var L: Dictionary = _layout()
	var w: float = L["w"]
	var h: float = L["h"]
	var pw: float = minf(w * 0.82, 700.0 * _s)
	var px: float = (w - pw) / 2.0
	var y: float = maxf(30.0 * _s, h * (0.18 if h > w * 1.15 else 0.09)) + 116.0 * _s
	var rh: float = minf(76.0 * _s, maxf(38.0 * _s, (h - y - 70.0 * _s) / 8.0))
	var gap: float = 12.0 * _s
	var out: Array = []
	for i in 7:
		out.append(Rect2(px, y + i * (rh + gap), pw, rh))
	return out

func _draw_main() -> void:
	var L: Dictionary = _layout()
	var w: float = L["w"]
	# ---- 顶栏 ----
	var top: Rect2 = L["top"]
	draw_rect(top, Const.HEADER, true)
	draw_line(Vector2(0, top.size.y), Vector2(w, top.size.y), Const.BORDER, 1.0)
	# 第一行：左=资产/盈亏，中=三档时间流速按钮，右=完整当前日期
	# 速度按钮紧贴日期左侧，就是手机版"时间流速放在时间左边"的设计
	var pf: float = Portfolio.profit()
	var pcol: Color = Const.UP if pf >= 0.0 else Const.DOWN
	var asset_r: Rect2 = L["asset_rect"]
	var date_r: Rect2 = L["date_rect"]
	var status_r: Rect2 = L["status_rect"]
	var day_r: Rect2 = L["day_rect"]
	var is_portrait: bool = bool(L["portrait"])
	_label(asset_r, "总资产 %.0f  ·  盈亏 %+.0f" % [Portfolio.total_asset(), pf],
			_fs(17.0 if is_portrait else 21.0), pcol)
	var sbs: Array = L["speed_btns"]
	var slabels: Array = L["speed_labels"]
	for i in sbs.size():
		var sr: Rect2 = sbs[i]
		var on: bool = (ClockSys.speed == i)
		draw_rect(sr, Const.ACCENT if on else Const.CARD, true)
		if not on:
			draw_rect(sr, Const.BORDER, false, 1.0)
		_label(sr, str(slabels[i]), _fs(12), Color(1, 1, 1) if on else Const.TEXT_SUB,
				HORIZONTAL_ALIGNMENT_CENTER)
	_label(date_r, Const.game_full_datetime(ClockSys.game_minute),
			_fs(16.0 if is_portrait else 22.0), Const.TEXT, HORIZONTAL_ALIGNMENT_RIGHT)
	# 第二行：运行状态 + 每现实秒推进量（三档差异一眼可验）+ 游戏日历
	var pause_hint: String = "底栏暂停键" if (is_portrait or OS.has_feature("mobile")) else "空格暂停"
	var st: String = "%s · 每秒 +%s · %s · %s" % [
			ClockSys.speed_label(), ClockSys.days_per_second(),
			"已暂停" if ClockSys.paused else "运行中", pause_hint]
	_label(status_r, st, _fs(12), Const.TEXT_SUB)
	_label(day_r,
			"游戏第 %d 日 · 累计 %d 分钟" % [ClockSys.current_day(), ClockSys.game_minute],
			_fs(11), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_RIGHT)
	# ---- 现价栏 ----
	var q: Rect2 = L["quote"]
	draw_rect(q, Const.CARD, true)
	draw_line(Vector2(0, q.position.y + q.size.y), Vector2(w, q.position.y + q.size.y), Const.BORDER, 1.0)
	var inst: Dictionary = Market.instrument(_current_code)
	var nm: String = str(inst.get("name", _current_code))
	var last: float = Market.last_price(_current_code)
	var base: float = float(inst.get("base", last))
	var chg: float = (last / base - 1.0) * 100.0 if base > 0.0 else 0.0
	var ccol: Color = Const.UP if chg >= 0.0 else Const.DOWN
	_label(Rect2(16.0 * _s, q.position.y + 2.0 * _s, w * 0.34, q.size.y * 0.56),
			"%s  %s" % [nm, _current_code], _fs(24), Const.TEXT)
	var qsub: String = "%s · %s" % [str(inst.get("group", "")), str(inst.get("sector", ""))]
	if float(inst.get("rd", 0.0)) > 0.0:
		qsub += " · 科研 %.0f（%s）" % [float(inst.get("rd", 0.0)), str(inst.get("rival", ""))]
	_label(Rect2(16.0 * _s, q.position.y + q.size.y * 0.56, w * 0.34, q.size.y * 0.40),
			qsub, _fs(12), Const.TEXT_SUB)
	var price_r: Rect2 = Rect2(w * 0.33, q.position.y, w * 0.30, q.size.y)
	_label(price_r, "%.2f" % last, _fs(32), ccol, HORIZONTAL_ALIGNMENT_CENTER)
	_label(Rect2(w * 0.64, q.position.y, w * 0.20, q.size.y), "%+.2f%%" % chg, _fs(24), ccol)
	var held: int = 0
	if Portfolio.positions.has(_current_code):
		held = int(Portfolio.positions[_current_code].get("qty", 0))
	var held_perf: Dictionary = Portfolio.position_perf(_current_code)
	_label(Rect2(w * 0.84, q.position.y, w * 0.16 - 12.0 * _s, q.size.y * 0.5), "持仓 %d" % held,
			_fs(17), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_RIGHT)
	if not held_perf.is_empty():
		var hpct: float = float(held_perf.get("pct", 0.0))
		var hpcol: Color = Const.UP if hpct >= 0.0 else Const.DOWN
		_label(Rect2(w * 0.84, q.position.y + q.size.y * 0.5, w * 0.16 - 12.0 * _s, q.size.y * 0.5),
				"买入后 %+.2f%%" % (hpct * 100.0), _fs(15), hpcol, HORIZONTAL_ALIGNMENT_RIGHT)
	# ---- 周期 ----
	var pr: Rect2 = L["period"]
	draw_rect(pr, Const.PANEL, true)
	var pbs: Array = L["period_btns"]
	for i in pbs.size():
		var r: Rect2 = pbs[i]
		_btn(r, str(Const.PERIOD_LABEL[i]), i == _selected_period, Const.ACCENT)
	# ---- 标的列表 ----
	_draw_list(L)
	# ---- K 线区边框 ----
	var cr: Rect2 = L["chart"]
	draw_rect(cr, Const.CARD, true)
	draw_rect(cr, Const.BORDER, false, 1.0)
	# ---- 交易面板 ----
	var trade_r: Rect2 = L["trade"]
	draw_rect(trade_r, Const.PANEL, true)
	draw_rect(trade_r, Const.BORDER, false, 1.0)
	var qbs: Array = L["qty_btns"]
	var qlabels: Array = ["100", "500", "1000", "全仓"]
	for i in qbs.size():
		var r: Rect2 = qbs[i]
		_btn(r, str(qlabels[i]), (i < 3 and _qty == QTY_OPTIONS[i]) or (i == 3 and _qty < 0), Const.ACCENT)
	var buy: Rect2 = L["buy_btn"]
	var sell: Rect2 = L["sell_btn"]
	_btn(buy, "买入", true, Const.UP)
	_btn(sell, "卖出", true, Const.DOWN)
	# ---- 底部工具栏 ----
	var br: Rect2 = L["bottom"]
	draw_rect(br, Const.HEADER, true)
	draw_line(Vector2(0, br.position.y), Vector2(w, br.position.y), Const.BORDER, 1.0)
	# 三档速度已移到顶栏日期左边，底栏只留 5 个常用键
	var blabels: Array = ["继续" if ClockSys.paused else "暂停", "单步", "新闻", "持仓", "重置"]
	var bbs: Array = L["bottom_btns"]
	for i in bbs.size():
		var r: Rect2 = bbs[i]
		var on: bool = (i == 2 and _news_open) or (i == 3 and _hold_open)
		if i == 4 and _reset_armed:
			_btn(r, "确认?", true, Const.UP)
		else:
			_btn(r, str(blabels[i]), on, Const.ACCENT)
	# 覆盖层统一由 _draw() 分发，这里只负责主界面本身，不再重复画面板。

func _draw_list(L: Dictionary) -> void:
	var lr: Rect2 = L["list"]
	draw_rect(lr, Const.PANEL, true)
	draw_rect(lr, Const.BORDER, false, 1.0)
	var vis: Array = _view_codes()
	_label(Rect2(lr.position.x + 6.0 * _s, lr.position.y + 2.0 * _s, lr.size.x - 12.0 * _s, 24.0 * _s),
			"标的 %d / %d · %s" % [vis.size(), _all_codes.size(), GROUP_NAMES[_active_group]],
			_fs(14), Const.TEXT_SUB)
	# 大类筛选标签：选中态蓝底，绘制与点击判定共用 _layout 的 Rect
	var chips: Array = L["group_chips"]
	for i in chips.size():
		var cr: Rect2 = chips[i]
		var on: bool = (i == _active_group)
		draw_rect(cr, Const.ACCENT if on else Const.CARD, true)
		if not on:
			draw_rect(cr, Const.BORDER, false, 1.0)
		_label(cr, GROUP_NAMES[i], _fs(11), Color(1, 1, 1) if on else Const.TEXT_SUB,
				HORIZONTAL_ALIGNMENT_CENTER)
	var rows: Array = L["list_rows"]
	var n: int = rows.size()
	var start: int = _list_page * n
	for i in n:
		var idx: int = start + i
		if idx >= vis.size():
			break
		var code: String = str(vis[idx])
		var r: Rect2 = rows[i]
		var sel: bool = (code == _current_code)
		if sel:
			draw_rect(r, Const.ACCENT_BG, true)
			draw_rect(Rect2(r.position.x, r.position.y, 4.0 * _s, r.size.y), Const.ACCENT, true)
		else:
			draw_rect(r, Const.CARD, true)
		var di: Dictionary = Market.instrument(code)
		var dnm: String = str(di.get("name", code))
		var dl: float = Market.last_price(code)
		var db: float = float(di.get("base", dl))
		var dc: float = (dl / db - 1.0) * 100.0 if db > 0.0 else 0.0
		var dcol: Color = Const.UP if dc >= 0.0 else Const.DOWN
		var gname: String = str(di.get("group", ""))
		var rd_v: float = float(di.get("rd", 0.0))
		var sub: String = gname
		if rd_v > 0.0:
			sub += " · 科研 %.0f" % rd_v
			sub += " · " + str(di.get("rival", ""))
		_label(Rect2(r.position.x + 10.0 * _s, r.position.y + 2.0 * _s, r.size.x * 0.58, 24.0 * _s),
				dnm, _fs(16), Const.TEXT)
		_label(Rect2(r.position.x + 10.0 * _s, r.position.y + 26.0 * _s, r.size.x * 0.72, 20.0 * _s),
				sub, _fs(11), Const.TEXT_SUB)
		_label(Rect2(r.position.x + r.size.x * 0.56, r.position.y + 4.0 * _s, r.size.x * 0.42, 24.0 * _s),
				"%+.1f%%" % dc, _fs(15), dcol, HORIZONTAL_ALIGNMENT_RIGHT)
		_label(Rect2(r.position.x + r.size.x * 0.56, r.position.y + 26.0 * _s, r.size.x * 0.42, 20.0 * _s),
				"%.2f" % dl, _fs(11), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_RIGHT)
	var prev: Rect2 = L["list_prev"]
	var next: Rect2 = L["list_next"]
	_btn(prev, "▲ 上一页", false, Const.ACCENT)
	_btn(next, "▼ 下一页", false, Const.ACCENT)
	var pages: int = maxi(1, ceili(float(vis.size()) / float(maxi(1, n))))
	_label(Rect2(lr.position.x, lr.position.y + lr.size.y - 34.0 * _s - 18.0 * _s, lr.size.x, 18.0 * _s),
			"%d / %d" % [_list_page + 1, pages], _fs(13), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)

func _draw_event_popup(L: Dictionary) -> void:
	var w: float = L["w"]
	var h: float = L["h"]
	var pw: float = minf(w * 0.86, 760.0 * _s)
	var ph: float = minf(h * 0.72, 620.0 * _s)
	var r: Rect2 = Rect2((w - pw) / 2.0, (h - ph) / 2.0, pw, ph)
	draw_rect(Rect2(0, 0, w, h), Color(0.94, 0.95, 0.97), true)
	draw_rect(r, Const.CARD, true)
	draw_rect(r, Const.ACCENT, false, 2.0)
	var ix: float = r.position.x + 24.0 * _s
	var iw: float = pw - 48.0 * _s
	var y: float = r.position.y + 24.0 * _s
	_label(Rect2(ix, y, iw, 44.0 * _s), str(_last_event.get("title", "事件")), _fs(28), Const.TEXT,
			HORIZONTAL_ALIGNMENT_CENTER)
	y += 56.0 * _s
	draw_line(Vector2(ix, y), Vector2(ix + iw, y), Const.BORDER, 1.0)
	y += 12.0 * _s
	_label(Rect2(ix, y, iw, 34.0 * _s), "【提示模式】为什么涨跌", _fs(20), Const.ACCENT)
	y += 40.0 * _s
	_wrap_text(ix, y, iw, str(_last_event.get("prompt", "")), _fs(18), Const.TEXT)
	var hint_r: Rect2 = Rect2(ix, r.position.y + ph - 132.0 * _s, iw, 44.0 * _s)
	draw_rect(hint_r, Const.ACCENT_BG, true)
	_label(hint_r, _hint_from_event(_last_event), _fs(15), Const.ACCENT)
	var btn: Rect2 = Rect2(r.position.x + pw / 2.0 - 110.0 * _s, r.position.y + ph - 68.0 * _s, 220.0 * _s, 48.0 * _s)
	_btn(btn, "关闭", true, Const.ACCENT)

# ================= 新闻时间线（国运推演改为带日期的新闻流）=================
## 面板所有可点区域与绘制共用这一份几何，避免"画在这、点在那"
func _news_geometry(L: Dictionary) -> Dictionary:
	var w: float = L["w"]
	var h: float = L["h"]
	# 竖屏手机下面板按屏幕高度铺开，不再被 780*s 卡死成一小块
	var pw: float = minf(w * 0.94, 900.0 * _s)
	var ph: float = minf(h * 0.88, 1600.0 * _s)
	var r: Rect2 = Rect2((w - pw) / 2.0, (h - ph) / 2.0, pw, ph)
	var head_h: float = 78.0 * _s
	# 页脚留出两行：页码 + 小提示（"新闻后面加点小提示"的固定说明行）
	var foot_h: float = 84.0 * _s
	var body: Rect2 = Rect2(r.position.x + 20.0 * _s, r.position.y + head_h,
			pw - 40.0 * _s, ph - head_h - foot_h)
	# 每条新闻 4 行：日期季节 / 标题 / 摘要 / 小提示
	# 竖屏屏幕高，可多显示几条；上限 9 与开局 9 条种子新闻刚好一页，
	# 同时避免每条被拉得过高、底部空一大片
	var per: int = clampi(int(body.size.y / (106.0 * _s)), 2, 9)
	var row_h: float = body.size.y / float(per)
	var rows: Array = []
	for i in per:
		rows.append(Rect2(body.position.x, body.position.y + i * row_h,
				body.size.x, row_h - 6.0 * _s))
	var by: float = r.position.y + ph - foot_h
	var bw: float = (pw - 40.0 * _s) / 4.0
	var btns: Array = []
	for i in 4:
		btns.append(Rect2(r.position.x + 20.0 * _s + i * bw, by + 40.0 * _s,
				bw - 6.0 * _s, foot_h - 48.0 * _s))
	var page_r: Rect2 = Rect2(r.position.x + 20.0 * _s, by + 2.0 * _s, pw - 40.0 * _s, 16.0 * _s)
	var tip_r: Rect2 = Rect2(r.position.x + 20.0 * _s, by + 20.0 * _s, pw - 40.0 * _s, 18.0 * _s)
	return {"r": r, "body": body, "rows": rows, "btns": btns, "per": per,
			"page_r": page_r, "tip_r": tip_r, "foot_top": by}

func _draw_news_panel(L: Dictionary) -> void:
	var G: Dictionary = _news_geometry(L)
	var r: Rect2 = G["r"]
	draw_rect(Rect2(0, 0, L["w"], L["h"]), Color(0.94, 0.95, 0.97), true)
	draw_rect(r, Const.CARD, true)
	draw_rect(r, Const.ACCENT, false, 2.0)
	_label(Rect2(r.position.x + 20.0 * _s, r.position.y + 10.0 * _s,
			r.size.x - 40.0 * _s, 42.0 * _s), "市场新闻 · 时间线", _fs(28), Const.TEXT)
	_label(Rect2(r.position.x + 20.0 * _s, r.position.y + 50.0 * _s,
			r.size.x - 40.0 * _s, 24.0 * _s),
			"当前 " + Const.game_full_datetime(ClockSys.game_minute)
					+ " · " + Const.season_name(Const.game_month(ClockSys.game_minute)),
			_fs(15), Const.TEXT_SUB)
	draw_line(Vector2(r.position.x + 20.0 * _s, r.position.y + 76.0 * _s),
			Vector2(r.position.x + r.size.x - 20.0 * _s, r.position.y + 76.0 * _s), Const.BORDER, 1.0)

	var rows: Array = G["rows"]
	var per: int = int(G["per"])
	var pages: int = maxi(1, ceili(float(_news.size()) / float(per)))
	_news_page = clampi(_news_page, 0, pages - 1)
	var start: int = _news_page * per
	for i in per:
		var idx: int = start + i
		if idx >= _news.size():
			break
		var rr: Rect2 = rows[i]
		var item: Dictionary = _news[idx]
		draw_rect(rr, Const.PANEL, true)
		draw_rect(Rect2(rr.position.x, rr.position.y, 4.0 * _s, rr.size.y), Const.ACCENT, true)
		_label(Rect2(rr.position.x + 14.0 * _s, rr.position.y + 2.0 * _s,
				rr.size.x - 28.0 * _s, 22.0 * _s),
				"%s   ·   %s   ·   %s" % [
						str(item["date"]), Const.season_name(Const.game_month(int(item.get("t", 0)))),
						str(item["tag"])], _fs(14), Const.ACCENT)
		_label(Rect2(rr.position.x + 14.0 * _s, rr.position.y + 24.0 * _s,
				rr.size.x - 28.0 * _s, 28.0 * _s), str(item["title"]), _fs(19), Const.TEXT)
		_label(Rect2(rr.position.x + 14.0 * _s, rr.position.y + 52.0 * _s,
				rr.size.x - 28.0 * _s, 24.0 * _s), str(item["body"]), _fs(14), Const.TEXT_SUB)
		# 每条新闻后面的"小提示"：浅蓝底独立一行，与正文分开
		var hint: String = str(item.get("hint", ""))
		if hint == "":
			hint = "提示 · 关注该事件对应的板块与持仓；红涨绿跌，事件冲击会随时间衰减。"
		var hr: Rect2 = Rect2(rr.position.x + 14.0 * _s, rr.position.y + 76.0 * _s,
				rr.size.x - 28.0 * _s, 20.0 * _s)
		draw_rect(hr, Const.ACCENT_BG, true)
		_label(hr, hint, _fs(12), Const.ACCENT)

	var btns: Array = G["btns"]
	var page_r: Rect2 = G["page_r"]
	var tip_r: Rect2 = G["tip_r"]
	_label(page_r, "第 %d / %d 页 · 共 %d 条" % [_news_page + 1, pages, _news.size()],
			_fs(13), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_label(tip_r,
			"小提示：宏观事件按板块扩散 · 廉政事件只影响涉事公司 · 科研点每季度重评 · 点提示条看因果",
			_fs(11), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_btn(btns[0], "◀ 上一页", false)
	_btn(btns[1], "下一页 ▶", false)
	_btn(btns[2], "推进一季度", false)
	_btn(btns[3], "关闭", true, Const.ACCENT)

# ================= 持仓仓库（买入的股票与数量）=================
func _draw_holdings_panel(L: Dictionary) -> void:
	var G: Dictionary = _news_geometry(L)
	var r: Rect2 = G["r"]
	# 实色不透明：面板背后不透视主界面
	draw_rect(Rect2(0, 0, L["w"], L["h"]), Color(0.94, 0.95, 0.97), true)
	draw_rect(r, Const.CARD, true)
	draw_rect(r, Const.ACCENT, false, 2.0)
	_label(Rect2(r.position.x + 20.0 * _s, r.position.y + 8.0 * _s,
			r.size.x * 0.40, 40.0 * _s), "持仓仓库", _fs(28), Const.TEXT)
	_label(Rect2(r.position.x + r.size.x * 0.40, r.position.y + 12.0 * _s,
			r.size.x * 0.60 - 20.0 * _s, 36.0 * _s),
			"现金 %.0f · 市值 %.0f · 总资产 %.0f · 盈亏 %+.0f" % [
					Portfolio.cash, Portfolio.market_value(), Portfolio.total_asset(), Portfolio.profit()],
			_fs(14), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_RIGHT)
	# 列名按数据行相同的列比例分格画，保证表头与数字严格对齐
	# 列：名称/代码 0.34 | 数量 0.12 | 成本 0.13 | 现价 0.13 | 买入后涨幅 0.13 | 盈亏 0.15
	var hx0: float = r.position.x + 20.0 * _s
	var hw: float = r.size.x - 40.0 * _s
	var hy: float = r.position.y + 48.0 * _s
	_label(Rect2(hx0 + 14.0 * _s, hy, hw * 0.34, 24.0 * _s), "名称 / 代码", _fs(13), Const.ACCENT)
	_label(Rect2(hx0 + hw * 0.34, hy, hw * 0.12, 24.0 * _s), "数量", _fs(13), Const.ACCENT)
	_label(Rect2(hx0 + hw * 0.46, hy, hw * 0.13, 24.0 * _s), "成本", _fs(13), Const.ACCENT)
	_label(Rect2(hx0 + hw * 0.59, hy, hw * 0.13, 24.0 * _s), "现价", _fs(13), Const.ACCENT)
	_label(Rect2(hx0 + hw * 0.72, hy, hw * 0.13, 24.0 * _s), "买入后涨幅", _fs(12), Const.ACCENT)
	_label(Rect2(hx0 + hw * 0.85, hy, hw * 0.15, 24.0 * _s), "盈亏", _fs(13), Const.ACCENT,
			HORIZONTAL_ALIGNMENT_RIGHT)
	draw_line(Vector2(r.position.x + 20.0 * _s, r.position.y + 76.0 * _s),
			Vector2(r.position.x + r.size.x - 20.0 * _s, r.position.y + 76.0 * _s), Const.BORDER, 1.0)

	var codes: Array = _holding_codes()
	var rows: Array = G["rows"]
	var per: int = maxi(1, int(G["per"]))
	var pages: int = maxi(1, ceili(float(codes.size()) / float(per)))
	_hold_page = clampi(_hold_page, 0, pages - 1)
	if codes.is_empty():
		_label(Rect2(r.position.x + 20.0 * _s, r.position.y + 160.0 * _s,
				r.size.x - 40.0 * _s, 40.0 * _s),
				"还没有买入任何股票。点右侧「买入」后这里会出现持仓。",
				_fs(19), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	var start: int = _hold_page * per
	for i in per:
		var idx: int = start + i
		if idx >= codes.size():
			break
		var rr: Rect2 = rows[i]
		var code: String = str(codes[idx])
		var p: Dictionary = Portfolio.positions[code]
		var qty: int = int(p.get("qty", 0))
		var cost: float = float(p.get("cost", 0.0))
		var last: float = Market.last_price(code)
		# 每只股票单独按"建仓成本 → 现价"算涨幅，不与账户总盈亏混算
		var perf: Dictionary = Portfolio.position_perf(code)
		var pct: float = float(perf.get("pct", (last - cost) / maxf(0.01, cost)))
		var pnl: float = float(perf.get("pnl", (last - cost) * float(qty)))
		var buy_t: int = int(perf.get("buy_t", ClockSys.game_minute))
		var held: int = int(perf.get("held_days", 0))
		var pcol: Color = Const.UP if pct >= 0.0 else Const.DOWN
		var nm: String = str(Market.instrument(code).get("name", code))
		draw_rect(rr, Const.PANEL, true)
		draw_rect(Rect2(rr.position.x, rr.position.y, 4.0 * _s, rr.size.y), Const.ACCENT, true)
		var cw: float = rr.size.x
		_label(Rect2(rr.position.x + 14.0 * _s, rr.position.y + 6.0 * _s, cw * 0.34, 26.0 * _s),
				nm, _fs(18), Const.TEXT)
		_label(Rect2(rr.position.x + 14.0 * _s, rr.position.y + 32.0 * _s, cw * 0.34, 22.0 * _s),
				code, _fs(13), Const.TEXT_SUB)
		_label(Rect2(rr.position.x + cw * 0.34, rr.position.y + 8.0 * _s, cw * 0.12, 30.0 * _s),
				str(qty), _fs(18), Const.TEXT)
		_label(Rect2(rr.position.x + cw * 0.46, rr.position.y + 8.0 * _s, cw * 0.13, 30.0 * _s),
				"%.2f" % cost, _fs(16), Const.TEXT_SUB)
		_label(Rect2(rr.position.x + cw * 0.59, rr.position.y + 8.0 * _s, cw * 0.13, 30.0 * _s),
				"%.2f" % last, _fs(16), Const.TEXT)
		_label(Rect2(rr.position.x + cw * 0.72, rr.position.y + 8.0 * _s, cw * 0.13, 30.0 * _s),
				"%+.2f%%" % (pct * 100.0), _fs(17), pcol)
		_label(Rect2(rr.position.x + cw * 0.85, rr.position.y + 8.0 * _s, cw * 0.15, 30.0 * _s),
				"%+.0f" % pnl, _fs(17), pcol, HORIZONTAL_ALIGNMENT_RIGHT)
		# "买时后"的时间维度：建仓日期与持有天数，点行可跳 K 线
		_label(Rect2(rr.position.x + cw * 0.34, rr.position.y + 36.0 * _s, cw * 0.42, 20.0 * _s),
				"买入 %s · 持有 %d 天" % [Const.game_datetime(buy_t), held],
				_fs(12), Const.TEXT_SUB)
		_label(Rect2(rr.position.x + cw * 0.72, rr.position.y + 36.0 * _s, cw * 0.28, 20.0 * _s),
				"点此行跳转 K 线", _fs(12), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_RIGHT)

	var btns: Array = G["btns"]
	var hpage_r: Rect2 = G["page_r"]
	var htip_r: Rect2 = G["tip_r"]
	_label(hpage_r, "共 %d 只 · 第 %d / %d 页" % [codes.size(), _hold_page + 1, pages],
			_fs(13), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_label(htip_r, "小提示：涨幅按每只股票的建仓成本单独计算 · 点某一行可跳到该股 K 线",
			_fs(11), Const.TEXT_SUB, HORIZONTAL_ALIGNMENT_CENTER)
	_btn(btns[0], "◀ 上一页", false)
	_btn(btns[1], "下一页 ▶", false)
	_btn(btns[2], "刷新行情", false)
	_btn(btns[3], "关闭", true, Const.ACCENT)

## 简单中文换行（按字符数切行，避免长文本溢出弹窗）
func _wrap_text(x: float, y: float, width: float, t: String, fsz: int, col: Color) -> void:
	if ThemeDB.fallback_font == null:
		return
	var per: int = maxi(8, int(width / float(fsz) * 1.05))
	var line: String = ""
	var yy: float = y
	for ch in t:
		line += ch
		if line.length() >= per or ch == "\n":
			_label(Rect2(x, yy, width, fsz * 1.6), line.strip_edges(), fsz, col)
			yy += fsz * 1.7
			line = ""
	if line != "":
		_label(Rect2(x, yy, width, fsz * 1.6), line, fsz, col)

## toast 固定放在顶栏下方，绘制与点击判定共用
func _toast_rect(L: Dictionary) -> Rect2:
	var tw: float = minf(L["w"] * 0.7, 700.0 * _s)
	var th: float = 58.0 * _s
	return Rect2((L["w"] - tw) / 2.0, L["top"].size.y + 6.0 * _s, tw, th)

# ================= 绘制辅助 =================
func _label(r: Rect2, t: String, font_size: int, col: Color,
			align: int = HORIZONTAL_ALIGNMENT_LEFT) -> void:
	if ThemeDB.fallback_font == null:
		return
	var y: float = r.position.y + r.size.y * 0.5 + font_size * 0.34
	draw_string(ThemeDB.fallback_font, Vector2(r.position.x, y), t, align, r.size.x, font_size, col)

func _btn(r: Rect2, label: String, filled: bool, accent: Color = BTN_ACCENT) -> void:
	if filled:
		draw_rect(r, accent, true)
	else:
		draw_rect(r, Const.CARD, true)
		draw_rect(r, Const.BORDER, false, 1.0)
	var col: Color = Color(1, 1, 1) if filled else Const.TEXT
	_label(r, label, _fs(19), col, HORIZONTAL_ALIGNMENT_CENTER)

# ================= 交互 =================
## 用 _input 而非 _gui_input：
## _gui_input 是"GUI 派发"链路，受 mouse_filter、父子节点遮挡、是否有子 Control 抢先消费影响，
## 根节点 Main 上很容易收不到（表现就是"点了没反应"）。_input 是 Node 级最早回调，
## 只要节点在场景树里就一定会收到，与 mouse_filter 无关。
## 坐标统一换算成 Main 的局部坐标，与 _layout()/_draw() 用的同一套。
func _input(event: InputEvent) -> void:
	# 键盘：空格暂停 / ESC 关面板（按住不重复触发）
	if event is InputEventKey:
		var k: InputEventKey = event
		if k.pressed and not k.echo:
			if k.keycode == KEY_SPACE and page == Page.MAIN:
				if _news_open or _hold_open or _event_detail_open:
					_close_panel()
				else:
					ClockSys.toggle_pause()
					EventBus.toast.emit("已暂停" if ClockSys.paused else "继续运行")
				return
			if k.keycode == KEY_ESCAPE and (_news_open or _hold_open or _event_detail_open):
				_close_panel()
				return
		return
	var pos: Vector2 = Vector2.ZERO
	if event is InputEventScreenTouch:
		var st: InputEventScreenTouch = event
		if not st.pressed:
			return
		# make_input_local 由引擎把事件坐标转成 Control 局部坐标，
		# 比手算 global_mouse_position - origin 稳（窗口缩放/锚点/Canvas transform 都不会偏）。
		var lt := make_input_local(st) as InputEventScreenTouch
		pos = lt.position
	elif event is InputEventMouseButton:
		var mb: InputEventMouseButton = event
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP or mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_on_wheel(mb)
			return
		if not mb.pressed or mb.button_index != MOUSE_BUTTON_LEFT:
			return
		var lm := make_input_local(mb) as InputEventMouseButton
		pos = lm.position
	else:
		return
	# 落在 K 线区内的按下/拖动：Main 不处理，也【不】set_input_as_handled，
	# 事件会继续送到 Chart 的 chart_input.gd（Node 级 _input），由它做
	# 单指平移 / 双指捏合 / 惯性 / 双击 / 长按。
	# 早退省掉几十个按钮矩形判定，避免图表手势被误判成按钮点击。
	if page == Page.MAIN and not _news_open and not _hold_open and not _event_detail_open:
		var CL: Dictionary = _layout()
		var chart_r: Rect2 = CL["chart"]
		if chart_r.has_point(pos):
			return
	if page == Page.START:
		_handle_start_tap(pos)
	else:
		_handle_main_tap(pos)

## 滚轮缩放 K 线（仅桌面）：以鼠标所在位置为锚点，向上拉近、向下拉远。
## 手机没有滚轮，缩放走 chart_input.gd 的双指捏合，两条路径互不冲突。
func _on_wheel(mb: InputEventMouseButton) -> void:
	if page != Page.MAIN or chart == null:
		return
	var L: Dictionary = _layout()
	var cr: Rect2 = L["chart"]
	var lw := make_input_local(mb) as InputEventMouseButton
	var p: Vector2 = lw.position
	if not cr.has_point(p):
		return
	var ratio: float = clampf((p.x - cr.position.x) / maxf(1.0, cr.size.x), 0.0, 1.0)
	var factor: float = 0.88 if mb.button_index == MOUSE_BUTTON_WHEEL_UP else 1.14
	chart.zoom(ratio, factor)

func _handle_start_tap(pos: Vector2) -> void:
	var rects: Array = _start_rects()
	for i in 4:
		var r: Rect2 = rects[i]
		if r.has_point(pos):
			_custom_cash = ""
			_start_game(float(CASH_OPTIONS[i]))
			return
	var cr: Rect2 = rects[4]
	if cr.has_point(pos):
		_custom_cash = "5000000"
		queue_redraw()
		return
	var sr: Rect2 = rects[5]
	if sr.has_point(pos):
		var cash: float = float(CASH_OPTIONS[0])
		if _custom_cash != "":
			cash = float(_custom_cash)
		_start_game(cash)
		return
	var lr: Rect2 = rects[6]
	if SaveMgr.has_save() and lr.has_point(pos):
		var d: Dictionary = SaveMgr.load_game()
		# 只认有效开局档（初始资金 > 0），避免把重置残留的空档读成一个 0 资金的局
		if not d.is_empty() and float(d.get("init_cash", 0.0)) > 0.0:
			Market.init_market()
			SaveMgr.apply_data(d)
			page = Page.MAIN
			ClockSys.start()
			_rebuild_codes()
			_apply_chart_layout()
			chart.set_symbol(_current_code, _selected_period)
			SaveMgr.enable_autosave(true)
			queue_redraw()
		else:
			EventBus.toast.emit("没有可读取的进度，请重新选择初始资金")

func _start_game(cash: float) -> void:
	# 重置后 Market 已被清空，这里会重新预填一段全新的历史行情
	Market.init_market()
	Portfolio.reset(cash)
	ClockSys.start()
	page = Page.MAIN
	_news_open = false
	_hold_open = false
	_event_detail_open = false
	if _news.is_empty():
		_seed_news()
	_news_page = 0
	_hold_page = 0
	_last_event = {}
	_init_nation()
	_rebuild_codes()
	_apply_chart_layout()
	chart.set_symbol(_current_code, _selected_period)
	# 重置时自动存档被停用，新局开始再打开，避免把 0 资金的空档写回去
	SaveMgr.enable_autosave(true)
	EventBus.game_started.emit(cash)
	if _touch_ui():
		EventBus.toast.emit("点底栏暂停键 · 双指捏合缩放K线 · 单指拖动平移 · 长按看数值")
	else:
		EventBus.toast.emit("空格暂停/继续 · 滚轮缩放K线 · 左键拖动平移")
	queue_redraw()

func _rebuild_codes() -> void:
	_all_codes = []
	for k in Market.instruments.keys():
		_all_codes.append(str(k))
	_list_page = 0
	_active_group = 0
	if not _all_codes.has(_current_code) and _all_codes.size() > 0:
		_current_code = str(_all_codes[0])

## 当前大类下的可见标的：分页、绘制、点击判定三处共用，保证一致
func _view_codes() -> Array:
	if _active_group == 0:
		return _all_codes.duplicate()
	var g: String = GROUP_NAMES[_active_group]
	var out: Array = []
	for c in _all_codes:
		if str(Market.instrument(c).get("group", "")) == g:
			out.append(c)
	return out

func _select_group(idx: int) -> void:
	_active_group = clampi(idx, 0, GROUP_NAMES.size() - 1)
	_list_page = 0
	var vis: Array = _view_codes()
	# 换大类后若当前标的被筛掉，自动跳到该大类第一只，K 线跟着换
	if not vis.is_empty() and not vis.has(_current_code):
		_current_code = str(vis[0])
		if chart and chart.has_method("set_symbol"):
			chart.set_symbol(_current_code, _selected_period)

func _handle_main_tap(pos: Vector2) -> void:
	var L: Dictionary = _layout()
	# ---- 覆盖层优先：任何面板打开时，只处理面板内的点击 ----
	# 关键：事件详情不再自动弹出，所以不会吞掉底栏按钮/新闻关闭键。
	if _news_open:
		var G: Dictionary = _news_geometry(L)
		var nbtns: Array = G["btns"]
		var nper: int = maxi(1, int(G["per"]))
		var npages: int = maxi(1, ceili(float(_news.size()) / float(nper)))
		var hit: bool = false
		for i in nbtns.size():
			var nr: Rect2 = nbtns[i]
			if nr.has_point(pos):
				hit = true
				if i == 0:
					_news_page = maxi(0, _news_page - 1)
				elif i == 1:
					_news_page = mini(npages - 1, _news_page + 1)
				elif i == 2:
					_advance_nation()
					_news_page = 0
				elif i == 3:
					_close_panel()
				break
		var npr: Rect2 = G["r"]
		if not hit and not npr.has_point(pos):
			_close_panel()      # 点面板外面也能关
		queue_redraw()
		return
	if _hold_open:
		var HG: Dictionary = _news_geometry(L)
		var hbtns: Array = HG["btns"]
		var hper: int = maxi(1, int(HG["per"]))
		var hcodes: Array = _holding_codes()
		var hpages: int = maxi(1, ceili(float(hcodes.size()) / float(hper)))
		var hhit: bool = false
		for i in hbtns.size():
			var hr: Rect2 = hbtns[i]
			if hr.has_point(pos):
				hhit = true
				if i == 0:
					_hold_page = maxi(0, _hold_page - 1)
				elif i == 1:
					_hold_page = mini(hpages - 1, _hold_page + 1)
				elif i == 2:
					if chart and chart.has_method("refresh"):
						chart.refresh()
				elif i == 3:
					_close_panel()
				break
		if not hhit:
			# 点某一行 = 跳转到该标的看 K 线，并关闭面板
			var hrows: Array = HG["rows"]
			for i in hrows.size():
				var rr: Rect2 = hrows[i]
				if rr.has_point(pos):
					var idx: int = _hold_page * hper + i
					if idx < hcodes.size():
						_current_code = str(hcodes[idx])
						chart.set_symbol(_current_code, _selected_period)
						_close_panel()
					break
			var hpr: Rect2 = HG["r"]
			if not hpr.has_point(pos):
				_close_panel()
		queue_redraw()
		return
	if _event_detail_open:
		var pw: float = minf(L["w"] * 0.86, 760.0 * _s)
		var ph: float = minf(L["h"] * 0.72, 620.0 * _s)
		var er: Rect2 = Rect2((L["w"] - pw) / 2.0, (L["h"] - ph) / 2.0, pw, ph)
		var ebtn: Rect2 = Rect2(er.position.x + pw / 2.0 - 110.0 * _s,
				er.position.y + ph - 68.0 * _s, 220.0 * _s, 48.0 * _s)
		if ebtn.has_point(pos) or not er.has_point(pos):
			_close_panel()
		queue_redraw()
		return
	# 顶栏三档时间流速（在日期左边，手机版也够得着）
	var spbs: Array = L["speed_btns"]
	for i in spbs.size():
		var sr2: Rect2 = spbs[i]
		if sr2.has_point(pos):
			ClockSys.set_speed(i)
			EventBus.toast.emit("已切换：%s（每现实秒 +%s）" % [
					ClockSys.speed_label(), ClockSys.days_per_second()])
			queue_redraw()
			return
	# 顶部提示条：点它展开事件因果详情；提示条 2.5 秒后自动消失，不吞其它点击
	if _toast != "" and Time.get_ticks_msec() < _toast_until:
		var tst: Rect2 = _toast_rect(L)
		if tst.has_point(pos) and not _last_event.is_empty():
			_open_panel(2)
			queue_redraw()
			return
	# 周期
	var pbs: Array = L["period_btns"]
	for i in pbs.size():
		var r2: Rect2 = pbs[i]
		if r2.has_point(pos):
			_selected_period = i
			chart.set_symbol(_current_code, _selected_period)
			queue_redraw()
			return
	# 大类筛选标签（在列表顶部，必须先于列表行判定）
	var chips: Array = L["group_chips"]
	for i in chips.size():
		var cr: Rect2 = chips[i]
		if cr.has_point(pos):
			_select_group(i)
			queue_redraw(); return
	# 标的列表翻页 / 选标的
	var vis: Array = _view_codes()
	var prev: Rect2 = L["list_prev"]
	var next: Rect2 = L["list_next"]
	var rows: Array = L["list_rows"]
	var per: int = maxi(1, rows.size())
	var pages: int = maxi(1, ceili(float(vis.size()) / float(per)))
	if prev.has_point(pos):
		_list_page = maxi(0, _list_page - 1)
		queue_redraw(); return
	if next.has_point(pos):
		_list_page = mini(pages - 1, _list_page + 1)
		queue_redraw(); return
	for i in rows.size():
		var rr: Rect2 = rows[i]
		if rr.has_point(pos):
			var idx: int = _list_page * per + i
			if idx < vis.size():
				_current_code = str(vis[idx])
				chart.set_symbol(_current_code, _selected_period)
				queue_redraw()
			return
	# 数量档
	var qbs: Array = L["qty_btns"]
	for i in qbs.size():
		var qr: Rect2 = qbs[i]
		if qr.has_point(pos):
			_qty = QTY_OPTIONS[i] if i < 3 else -1
			queue_redraw(); return
	# 买 / 卖（走 TradeSys：含涨跌停排队与滑点）
	var buy: Rect2 = L["buy_btn"]
	var sell: Rect2 = L["sell_btn"]
	if buy.has_point(pos):
		_do_order("BUY"); return
	if sell.has_point(pos):
		_do_order("SELL"); return
	# 底部工具栏 5 键（三档速度已移到顶栏日期左边）
	var bbs: Array = L["bottom_btns"]
	for i in bbs.size():
		var br: Rect2 = bbs[i]
		if not br.has_point(pos):
			continue
		if i == 0:
			ClockSys.toggle_pause()
		elif i == 1:
			ClockSys.step_once()
			# 单步要立刻看到那一分钟的变化，不等节流
			if chart and chart.has_method("refresh"):
				chart.refresh()
			queue_redraw()
		elif i == 2:
			_open_panel(0)
			_news_page = 0
		elif i == 3:
			_open_panel(1)
			_hold_page = 0
		elif i == 4:
			if _reset_armed:
				page = Page.START
				_news_open = false
				_hold_open = false
				_event_detail_open = false
				# reset_done 会清空新闻、国运、事件、分页并重播开局旧闻
				SaveMgr.reset_progress()
				_apply_chart_layout()
				queue_redraw()
			else:
				_reset_armed = true
				EventBus.toast.emit("再点一次「确认」将清空进度")
		queue_redraw()
		return

func _do_order(side: String) -> void:
	var qty: int = _qty
	if qty < 0:
		if side == "BUY":
			var px: float = Market.last_price(_current_code)
			qty = int(floor(Portfolio.cash / maxf(0.01, px * 1.001) / 100.0)) * 100
		else:
			qty = 0
			if Portfolio.positions.has(_current_code):
				qty = int(Portfolio.positions[_current_code].get("qty", 0))
	if qty <= 0:
		EventBus.toast.emit("数量不足")
		return
	var res: Dictionary = TradeSys.place_order(_current_code, side, qty, "MARKET")
	if not bool(res.get("ok", false)):
		EventBus.toast.emit(str(res.get("note", "下单失败")))
	queue_redraw()

# ================= 回调 =================
## 只打标记，由 _process 按 ~15Hz 统一重绘。行情/时钟仍全速推进，互不拖累。
func _on_price_updated() -> void:
	if page == Page.MAIN:
		_ui_dirty = true

## 事件不再自动弹全屏模态：只入新闻时间线 + 一条非模态提示（不吞点击）。
## 想看因果说明，点顶部那条提示即可展开详情。
## 新闻后面的小提示：优先用事件自带的 hint（廉政/科研），
## 其余按板块做"偏多/承压"的定性说明，再从基础提示池轮换一条基础引导。
## 全部文案不含涨跌幅度、百分比等具体数值。
func _hint_from_event(ev: Dictionary) -> String:
	var h: String = str(ev.get("hint", ""))
	if h != "":
		return h
	var impact: Dictionary = ev.get("impact", {})
	var ups: String = ""
	var downs: String = ""
	var cnt: int = 0
	for k in impact:
		if cnt >= 3:
			break
		var nm: String = str(k)
		if float(impact[k]) >= 0.0:
			ups += ("/" if ups != "" else "") + nm
		else:
			downs += ("/" if downs != "" else "") + nm
		cnt += 1
	var pre: String = ""
	if ups != "":
		pre += ups + "偏多"
	if downs != "":
		pre += ("，" if pre != "" else "") + downs + "承压"
	if pre != "":
		pre += " · "
	var seed_i: int = floori(float(int(ev.get("news_t", 0))) / 1440.0) \
			+ str(ev.get("title", "")).length()
	return pre + str(BASE_HINTS[absi(seed_i) % BASE_HINTS.size()])

func _on_event(ev: Dictionary) -> void:
	_last_event = ev
	var body: String = str(ev.get("prompt", ""))
	if body.length() > 46:
		body = body.substr(0, 46) + "…"
	var et: int = int(ev.get("news_t", ClockSys.game_minute))
	var tag: String = str(ev.get("tag", "事件·提示"))
	_push_news_at(et, tag, str(ev.get("title", "市场事件")), body, _hint_from_event(ev))
	if page == Page.MAIN and not _news_open and not _hold_open and not _event_detail_open:
		EventBus.toast.emit("事件：" + str(ev.get("title", "市场事件")) + "（点此看详情）")
		queue_redraw()

func _on_toast(t: String) -> void:
	_toast = t
	_toast_until = Time.get_ticks_msec() + 2500
	_ui_dirty = true
	queue_redraw()

func _on_day(d: int) -> void:
	# 用"该游戏日"自己的月份，而不是当前时刻月份：
	# 快档一帧跨好几天，补发 day_changed 时每天都要按当天的季节挑事件。
	var day_month: int = Const.game_month(d * 1440 + 720)
	var ev: Dictionary = EventDB.maybe_trigger(d, day_month)
	if not ev.is_empty():
		# 把"事件发生的游戏时刻"带下去：快档一帧跨好几天时，
		# 新闻日期要落在各自那一天，不能全挤在当前的今天。
		var packed: Dictionary = ev.duplicate(true)
		packed["news_t"] = d * 1440 + 720
		EventBus.event_triggered.emit(packed)
	# 廉政事件走独立档期（平均约 90 天一次），不占用宏观事件的播报间隔
	var cor: Dictionary = EventDB.maybe_trigger_corruption(d)
	if not cor.is_empty():
		var cpacked: Dictionary = cor.duplicate(true)
		cpacked["news_t"] = d * 1440 + 720
		EventBus.event_triggered.emit(cpacked)
	# 每 30 个游戏日自动推进一次国运，时间线会自己长出来，不用手动点
	if d > 0 and d % 30 == 0:
		_advance_nation()

# ================= 重置进度 =================
## 由 SaveMgr.reset_done 触发。之前只删了存档文件，内存里的新闻时间线、
## 国运状态、事件详情、分页全留着，所以"重置"后点新闻还是上一局那一堆。
## 这里把 UI 侧的全部局内状态一次性清掉并重新播种开局旧闻。
func _on_reset_done() -> void:
	_news.clear()
	_seed_news()
	_news_page = 0
	_hold_page = 0
	_list_page = 0
	_active_group = 0
	_reset_armed = false
	_last_event = {}
	_toast = ""
	_toast_until = 0
	_init_nation()
	_current_code = "688001"
	_selected_period = Const.Period.DAY
	_qty = 100
	_news_open = false
	_hold_open = false
	_event_detail_open = false
	_panel_paused_before = true   # 时钟已 reset 为暂停，关面板时别把它恢复成运行
	_ui_dirty = true

# ================= 面板开关（打开时暂停，关闭时恢复）=================
## kind: 0=新闻 1=持仓 2=事件详情
func _open_panel(kind: int) -> void:
	_news_open = (kind == 0)
	_hold_open = (kind == 1)
	_event_detail_open = (kind == 2)
	# ★ 核心修复：Chart 是子节点，父节点 _draw 的覆盖层永远盖不住它。
	# 直接隐藏整个 Chart 节点，K 线/均线/成交量/日期轴就都不会画在面板上面。
	if chart != null:
		chart.visible = false
	# 面板打开时暂停：背景不会狂跑、也不会连环弹事件把点击吃掉
	_panel_paused_before = ClockSys.paused
	ClockSys.paused = true
	_ui_dirty = true
	queue_redraw()

func _close_panel() -> void:
	_news_open = false
	_hold_open = false
	_event_detail_open = false
	if chart != null:
		# 与 _apply_chart_layout 同一套规则：只有主界面且无面板才显示 K 线
		chart.visible = (page == Page.MAIN) and not (_news_open or _hold_open or _event_detail_open)
		chart.mouse_filter = Control.MOUSE_FILTER_IGNORE if page == Page.START else Control.MOUSE_FILTER_STOP
	ClockSys.paused = _panel_paused_before
	_ui_dirty = true
	queue_redraw()

## 持仓列表：只列数量 > 0 的，按代码排序，供仓库面板翻页
func _holding_codes() -> Array:
	var out: Array = []
	for code in Portfolio.positions:
		if int(Portfolio.positions[code].get("qty", 0)) > 0:
			out.append(str(code))
	out.sort()
	return out

# ================= 新闻数据 / 国运推演 =================
func _push_news_at(t: int, tag: String, title: String, body: String, hint: String = "") -> void:
	# 按游戏时间倒序插入（最新在最前）：快档一帧补发好几天时调用顺序可能交错，
	# 单纯 push_front 会让旧新闻盖在新新闻上面。
	var item: Dictionary = {"t": t, "date": Const.game_full_datetime(t),
			"tag": tag, "title": title, "body": body, "hint": hint}
	var at: int = _news.size()
	for i in _news.size():
		if int(_news[i]["t"]) < t:
			at = i
			break
	_news.insert(at, item)
	if _news.size() > 80:
		_news = _news.slice(0, 80)

func _push_news(tag: String, title: String, body: String) -> void:
	_push_news_at(ClockSys.game_minute, tag, title, body)

## 存档用：新闻时间线也要能读回来，否则重进只剩种子旧闻
func get_news_snapshot() -> Array:
	return _news.duplicate(true)

func apply_news_snapshot(arr: Array) -> void:
	_news = arr.duplicate(true)

## 开局给时间线铺一段带日期的旧闻，面板一打开就有内容，不是空列表。
## 每条带允许月份白名单（空=全年），按该条日期所在月份过滤：
## 开局是 1 月，旧闻落在 12 月，以前这里写"迎峰度夏用电负荷创新高"纯属穿帮。
func _seed_news() -> void:
	var items: Array = [
		[-18 * 1440, "地缘", "A、B 两国边境摩擦升温", "避险资金流入黄金与原油，军工板块小幅走强。", [],
			"提示 · 地缘冲突常先涨后回吐，别把传闻阶段的涨幅当成长期趋势。"],
		[-15 * 1440, "能源", "主要产油国讨论延长减产", "WTI 与布伦特连续三日收涨，航运运价同步抬升。", [],
			"提示 · 供给端消息影响能源与航运，黄金、农产品不在这条链上。"],
		[-12 * 1440, "央行", "美联储议息会议维持利率不变", "声明偏鸽，成长板块与黄金受益，银行股承压。", [],
			"提示 · 利率预期主要影响成长股与银行，注意与个股基本面区分。"],
		[-10 * 1440, "天气", "寒潮南下 多地供暖负荷攀升", "火电日耗与煤炭补库同步走高，天然气价格短线偏强。", [11, 12, 1, 2],
			"提示 · 冬季事件：关注电力与煤炭日耗，夏季才会出现高温负荷行情。"],
		[-9 * 1440, "产业", "年末光伏抢装 组件排产回升", "并网节点临近带动抢装，组件与逆变器排产环比改善。", [11, 12],
			"提示 · 抢装改善排产，但价格战仍在压制组件毛利，别只看量不看价。"],
		[-7 * 1440, "煤炭", "北方集中供暖启动 煤炭日耗回升", "供暖季全面开启，电厂库存周转加快，动力煤获季节性支撑。", [11, 12, 1],
			"提示 · 供暖季是煤炭季节性需求，与地缘、货币政策无关。"],
		[-5 * 1440, "宏观", "年末资金面趋紧 短端利率上行", "跨年资金需求抬升，高估值板块承压，防御与黄金相对占优。", [12],
			"提示 · 资金面扰动偏短期，跨年后常自行缓解。"],
		[-3 * 1440, "海外", "海外主要指数震荡回落", "风险偏好下降，资金转向防御与贵金属。", [],
			"提示 · 避险情绪利好黄金，但不改变单个公司的经营状况。"],
		[-1 * 1440, "复盘", "上一交易周：能源领涨，金融走平", "市场等待本周宏观数据与议息纪要指引方向。", [],
			"提示 · 开局资金用左侧列表按大类挑标的，点「持仓」看买入后涨幅。"],
	]
	for it in items:
		var t: int = int(it[0])
		var allowed: Array = it[4]
		var m: int = Const.game_month(t + 720)
		if allowed.is_empty() or allowed.has(m):
			_push_news_at(t, str(it[1]), str(it[2]), str(it[3]), str(it[5]))

func _init_nation() -> void:
	for c in ["A", "B", "C", "D"]:
		_nation[c] = {"gdp": 100.0, "stable": 0.8, "policy": 0.0}

## 国运不再只弹一句 toast，而是产出 4 条带当前日期的新闻进时间线
func _advance_nation() -> void:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var m: int = ClockSys.game_minute
	var month: int = Const.game_month(m)
	var titles: Array = ["经济稳步复苏", "央行调整利率", "社会局势波动",
			"科技产业突破", "贸易摩擦升温", "能源保供政策加码"]
	# 暖季才有大规模开工，冷季是供暖保供与开年信贷，冬季不写"基建集中投产"
	if month >= 4 and month <= 10:
		titles.append_array(["基础设施大规模投产", "算力中心集中开工", "迎峰度夏电力保供"])
	else:
		titles.append_array(["迎峰度冬能源保供", "年末财政支出加速", "开年信贷投放前置"])
	for c in ["A", "B", "C", "D"]:
		var n: Dictionary = _nation[c]
		var growth: float = rng.randfn(0.02, 0.03)
		n["gdp"] = maxf(10.0, float(n["gdp"]) * (1.0 + growth))
		n["stable"] = clampf(float(n["stable"]) + rng.randfn(0.0, 0.05), 0.1, 1.0)
		n["policy"] = clampf(float(n["policy"]) + rng.randfn(0.0, 0.1), -1.0, 1.0)
		var title: String = str(titles[rng.randi_range(0, titles.size() - 1)])
		var body: String = "GDP 指数 %.1f · 稳定度 %.2f · 政策取向 %+.2f" % [
				float(n["gdp"]), float(n["stable"]), float(n["policy"])]
		_push_news_at(m, "国运·%s" % c, "%s国：%s" % [c, title], body,
				"提示 · 国运按季度演化，GDP/稳定度影响长期风险偏好，不直接决定某只股票涨跌。")
	EventBus.toast.emit("国运推演推进，新闻时间线已更新")

func _notification(what: int) -> void:
	if what == NOTIFICATION_EXIT_TREE:
		if page == Page.MAIN:
			SaveMgr.save_game()
