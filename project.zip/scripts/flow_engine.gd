extends RefCounted
class_name FlowEngine
## 内生价格层：Agent 不直接改价，只产出「当日净资金流」这一个中间变量，
## 由 Market 一处统一施加到价格管线（随机游走 + shock + 脉冲 + κ×净流/流动性）。
##
## 三条纪律（与工程约束对齐）：
##  1) 不新增 autoload。本类 extends RefCounted，由 Market 持有；EventBus 不新增必需信号。
##  2) 按「游戏日」决策一次，日内按 /240 匀速释放。慢档每分钟 flow/240，
##     快档一次施加整日 flow，两种速度的日内总冲击完全相同。
##  3) 商品（C.*）不进 flow 链条，沿用「黄金白银不进链条」的既有口径。
##
## 顺序保证：day_changed 在每日行情之前发出 → 事件先跳价 → 本类第一次收到
## 该日的 minute_ticked / bulk_advanced 时才 begin_day()，读到的必是跳后价。

const SESSION_MIN := 240.0
const ATT_DECAY := 0.70          # 关注度半衰期约 3 游戏日（0.7^3≈0.34）
const MAX_DAILY_IMPACT := 0.035 # 单日单票资金流冲击封顶，再交给涨跌停兜底
const KAPPA := 0.034             # 资金流→收益率的总增益（环路增益 < 1）
const K_INST := 1.40             # 机构负反馈增益（偏离越大拉力越强）
const RD_WINDOW := 30            # 复用科研重评节奏做 anchor 漂移

const TEMP_LABEL := ["冷静", "常态", "狂躁"]
## 按性格分档的资金流增益 / 单日冲击上限：体感拉开，但护栏不撤
const TEMP_KAPPA := [0.018, 0.030, 0.042]
const TEMP_IMPACT := [0.020, 0.032, 0.046]
const W_RETAIL := [0.35, 0.60, 0.90]
## 狂躁档机构不能太弱，否则散户踩踏没人接，365 天会单调跌到 0。
const W_INST := [1.35, 1.15, 0.95]
const ALPHA := [0.22, 0.38, 0.62]
const GAMMA := [0.10, 0.22, 0.40]

var enabled := false
var run_seed := 0
var temperament := 1
var rng := RandomNumberGenerator.new()

## code -> 每票两个情绪标量 + 一个价值锚 + 企业行为持久状态
var st: Dictionary = {}
var industry: Dictionary = {}     # sector -> 慢变量行业强度
var sector_codes: Dictionary = {} # sector -> [code,...]
var pending_att: Dictionary = {}  # 事件带来的关注度尖峰（下个游戏日消费）
var pending_news: Dictionary = {} # 事件带来的情绪冲击（带方向）
var notices: Array = []           # 待播报的企业行为 / 监管问询新闻
var _day := -1
var _rng_state := 0

func configure(seed_value: int, instruments: Dictionary, by_sector: Dictionary,
		by_rival: Dictionary, temp: int) -> void:
	run_seed = seed_value
	temperament = clampi(temp, 0, 2)
	rng.seed = seed_value
	st.clear()
	industry.clear()
	sector_codes = by_sector.duplicate(true)
	pending_att.clear()
	pending_news.clear()
	notices.clear()
	_day = -1
	for code in instruments:
		var inst: Dictionary = instruments[code]
		var base: float = float(inst["base"])
		var rd: float = float(inst.get("rd", 0.0))
		var sec: String = str(inst.get("sector", ""))
		var anchor: float = base * (1.0 + 0.004 * rd)
		st[code] = {
			"s": 0.0, "att": 0.0, "anchor": anchor,
			"flow": 0.0, "fr": 0.0, "fi": 0.0, "fc": 0.0,
			"vr": 0.0, "vi": 0.0, "vc": 0.0,
			"hist_ret": [], "hist_inst": [], "closes": [],
			"streak": 0, "down_streak": 0, "hot": 0, "shares": 1.0,
			"corp": {}, "pump": {},
		}
		if not industry.has(sec):
			industry[sec] = 0.0

## 事件尖峰：只记状态，不立刻改情绪。等下个游戏日 begin_day 统一消费，
## 这样事件就有了多日余波，而不是一次性跳完就消失。
func on_event(ev: Dictionary) -> void:
	if not enabled:
		return
	var sev: float = absf(float(ev.get("severity", 0.3)))
	var spike: float = 0.55 + 0.95 * sev
	var d: float = float(ev.get("dir", 1.0))
	var tc: String = str(ev.get("target_code", ""))
	if tc != "" and st.has(tc):
		pending_att[tc] = float(pending_att.get(tc, 0.0)) + spike
		pending_news[tc] = float(pending_news.get(tc, 0.0)) + d * spike
	var sec: String = str(ev.get("sector", ""))
	if sec != "" and sector_codes.has(sec):
		for c in sector_codes[sec]:
			var cc: String = str(c)
			if st.has(cc):
				pending_att[cc] = float(pending_att.get(cc, 0.0)) + spike * 0.35
				pending_news[cc] = float(pending_news.get(cc, 0.0)) + d * spike * 0.35

## 每天只在第一次行情事件到达时调一次（Market._ensure_flow_day 保证）。
func begin_day(day: int, instruments: Dictionary) -> void:
	if not enabled or day == _day:
		return
	_day = day
	# 先把行业情绪算出来，个股的 γ·(s_industry − s_i) 才有一致参照
	var ind_s: Dictionary = {}
	for sec in industry:
		var tot := 0.0
		var n := 0
		for c in sector_codes.get(sec, []):
			var cc: String = str(c)
			if st.has(cc):
				tot += float(st[cc]["s"])
				n += 1
		ind_s[sec] = tot / float(maxi(1, n))
	for code in instruments:
		if not st.has(code):
			continue
		_step_one(code, day, instruments, ind_s)
	# 消费事件尖峰
	pending_att.clear()
	pending_news.clear()

func _step_one(code: String, day: int, instruments: Dictionary, ind_s: Dictionary) -> void:
	var q: Dictionary = st[code]
	var inst: Dictionary = instruments[code]
	# 日线收盘是批量推进中的权威现价（bars 在快档末尾才 append，会滞后）
	var price: float = float(inst["days"][-1]["c"])
	var vol: float = maxf(0.004, float(inst["vol"]))
	var sec: String = str(inst.get("sector", ""))
	# 商品不进 flow 链条：保持原有外生随机价格，不被情绪/资金流推动
	if code.begins_with("C."):
		q["flow"] = 0.0
		q["fr"] = 0.0
		q["fi"] = 0.0
		q["fc"] = 0.0
		q["vr"] = 0.0
		q["vi"] = 0.0
		q["vc"] = 0.0
		return

	# ---- 近 5 日收益（用于情绪与处置效应）----
	var closes: Array = q["closes"]
	closes.append(price)
	if closes.size() > 7:
		closes = closes.slice(closes.size() - 7)
		q["closes"] = closes
	var ret5 := 0.0
	if closes.size() >= 6:
		var p0: float = float(closes[closes.size() - 6])
		if p0 > 0.0:
			ret5 = price / p0 - 1.0

	# ---- A. 傻钱：情绪 + 关注度 ----
	var s: float = float(q["s"])
	var att: float = float(q["att"])
	var news_shock: float = float(pending_news.get(code, 0.0))
	var atk: float = float(pending_att.get(code, 0.0))
	var volratio: float = _vol_ratio(q)
	var r: float = clampf(ret5 / (vol * 2.24), -3.0, 3.0)
	var isec: float = float(ind_s.get(sec, 0.0))
	var next_s: float = tanh(s
			+ ALPHA[temperament] * r * 0.25
			+ 0.30 * news_shock
			+ GAMMA[temperament] * (isec - s)
			- 0.12 * s)
	att = att * ATT_DECAY + atk + 0.45 * maxf(0.0, volratio - 1.0)
	att = clampf(att, 0.0, 6.0)
	q["s"] = next_s
	q["att"] = att

	# ---- B. 聪明钱：慢变量价值锚（数值不对外暴露）----
	var anchor: float = float(q["anchor"])
	if day > 0 and day % RD_WINDOW == 0:
		anchor *= (1.0 + rng.randfn(0.0, 0.018) + 0.25 * float(industry.get(sec, 0.0)))
		# 锚必须缓慢拉回基准，否则 RNG 漂移会让它自己游走，负反馈失去参照
		var base: float = float(inst["base"])
		anchor = lerpf(anchor, base * (1.0 + 0.004 * float(inst.get("rd", 0.0))), 0.15)
		anchor = maxf(0.01, anchor)
		q["anchor"] = anchor
	var rd_gap: float = float(inst.get("rd", 0.0)) * 0.004
	var ind_part: float = 0.30 * float(industry.get(sec, 0.0))
	var anchor_full: float = anchor * (1.0 + rd_gap + ind_part)
	var gap: float = (anchor_full - price) / maxf(0.01, anchor_full)

	# ---- 三个 cohort 的净流（无量纲比率，后面统一乘 κ/流动性）----
	var retail_r: float = clampf(tanh(next_s) * (att / (1.0 + att)), -1.0, 1.0)
	retail_r *= W_RETAIL[temperament]
	# 处置效应：浮亏时卖出放大（踩踏），浮盈时不变（惜售）。
	# 倍率不能到 3：散户流会远超机构锚上限，环路增益 > 1，狂躁档一年跌到 0。
	if ret5 < 0.0 and retail_r < 0.0:
		retail_r *= 1.6
	retail_r = clampf(retail_r, -0.55, 0.55)
	# 连涨落袋 / 连跌回补：两个方向都给强制再平衡，避免任何一侧单调发散
	if ret5 > 0.0:
		q["streak"] = int(q["streak"]) + 1
		q["down_streak"] = 0
	else:
		q["streak"] = 0
		q["down_streak"] = int(q["down_streak"]) + 1
	if int(q["streak"]) >= 5:
		retail_r -= 0.30
		q["streak"] = 0
	if int(q["down_streak"]) >= 5:
		retail_r += 0.30
		q["down_streak"] = 0
	retail_r = clampf(retail_r, -0.60, 0.60)

	# 机构是唯一负反馈稳定器：偏离锚越远，拉力非线性越强
	var inst_r: float = clampf(gap * K_INST * (1.0 + 2.0 * absf(gap)), -0.75, 0.75)
	inst_r *= W_INST[temperament]
	var corp_r: float = _corp_flow(code, q, price, day, instruments)
	var pump_r: float = _pump_flow(code, q, att, next_s)
	var net_r: float = clampf(retail_r + inst_r + corp_r + pump_r, -1.0, 1.0)

	# 流动性分母：股本越轻越容易被推动（定增会永久抬高它）
	var liq: float = clampf(0.55 + 0.45 * float(q["shares"]), 0.35, 2.2)
	var cap: float = minf(TEMP_IMPACT[temperament], MAX_DAILY_IMPACT)
	var impact: float = clampf(TEMP_KAPPA[temperament] * net_r / liq, -cap, cap)
	q["flow"] = impact
	q["fr"] = retail_r
	q["fi"] = inst_r
	q["fc"] = corp_r + pump_r

	# 成交量从派生产物升级为状态量：Σ|各 cohort 流| / price
	var base_v: float = 10000.0 + 380000.0 * (0.25 + absf(retail_r) + absf(inst_r) + absf(corp_r))
	var tot: float = maxf(0.0001, absf(retail_r) + absf(inst_r) + absf(corp_r) + absf(pump_r))
	q["vr"] = base_v * absf(retail_r) / tot
	q["vi"] = base_v * absf(inst_r) / tot
	q["vc"] = base_v * (absf(corp_r) + absf(pump_r)) / tot

	# 近 5 日资金流（指标带用）
	var hr: Array = q["hist_ret"]
	hr.append(retail_r)
	if hr.size() > 5: q["hist_ret"] = hr.slice(hr.size() - 5)
	hi_append(q, inst_r)

	# 行业慢变量：按当日板块平均收益小幅漂移
	industry[sec] = clampf(float(industry.get(sec, 0.0)) * 0.85 + clampf(ret5, -0.1, 0.1) * 0.6,
			-0.35, 0.35)

	# 护栏 5：情绪饱和连续 3 天 → 监管问询
	if absf(next_s) > 0.82:
		q["hot"] = int(q["hot"]) + 1
	else:
		q["hot"] = 0
	if int(q["hot"]) >= 2:
		q["hot"] = 0
		q["s"] = next_s * 0.45
		q["att"] = att * 0.4
		notices.append({
			"tag": "监管·问询",
			"title": "%s：交易异常波动收到问询函" % str(inst.get("name", code)),
			"body": "短期情绪过热，交易所要求公司说明情况，炒作资金开始退潮。",
			"hint": "现实：连续异常波动会被交易所问询，短线资金通常退场。|模拟器：这家公司的热度可能降下来，涨势可能放缓。",
		})

func hi_append(q: Dictionary, v: float) -> void:
	var hi: Array = q["hist_inst"]
	hi.append(v)
	if hi.size() > 5:
		q["hist_inst"] = hi.slice(hi.size() - 5)

func _vol_ratio(q: Dictionary) -> float:
	var hr: Array = q["hist_ret"]
	if hr.is_empty():
		return 1.0
	var last: float = absf(float(hr[hr.size() - 1]))
	var prev: float = 0.0
	for v in hr:
		prev += absf(float(v))
	prev /= float(hr.size())
	return clampf(last / maxf(0.02, prev), 0.0, 4.0)

## ---- C. 企业投资行为：持久化状态 ----
func _corp_flow(code: String, q: Dictionary, price: float, day: int,
		instruments: Dictionary) -> float:
	var corp: Dictionary = q["corp"]
	var f := 0.0
	if corp.is_empty():
		# 每天小概率给一家公司开一项计划（回购 / 增减持 / 定增 / 扩产停产）
		if rng.randf() < 0.012:
			var roll: float = rng.randf()
			var kind: String
			if roll < 0.32: kind = "BUYBACK"
			elif roll < 0.62: kind = "INSIDER"
			elif roll < 0.80: kind = "ISSUANCE"
			else: kind = "EXPAND"
			corp["kind"] = kind
			corp["left"] = 6 + rng.randi_range(0, 9)
			corp["day0"] = day
			q["corp"] = corp
			var inst: Dictionary = instruments[code]
			var nm: String = str(inst.get("name", code))
			if kind == "BUYBACK":
				notices.append({"tag": "公司·回购", "title": "%s：披露股份回购计划" % nm,
					"body": "公司公告将在一段时间内分批回购股份，并注销相应股本。",
					"hint": "现实：回购会持续带来买盘，股本减少后每股更容易被推动。|模拟器：这家公司可能连续几天有买盘支撑。"})
			elif kind == "INSIDER":
				notices.append({"tag": "公司·增减持", "title": "%s：披露内部人交易意向" % nm,
					"body": "内部人按自己的判断在情绪高位减、低位增，方向与市场情绪常常相反。",
					"hint": "现实：内部人更清楚公司经营，高位减持常被视为先行信号。|模拟器：情绪过热时这家公司可能出现卖压。"})
			elif kind == "ISSUANCE":
				notices.append({"tag": "公司·定增", "title": "%s：完成定向增发" % nm,
					"body": "新增股份上市流通，盘子变大，同样的资金推动起来更费劲。",
					"hint": "现实：增发会稀释每股权益，流通盘变大后波动通常变钝。|模拟器：这家公司之后对资金流的反应可能变小。"})
			else:
				notices.append({"tag": "公司·经营", "title": "%s：调整产能安排" % nm,
					"body": "公司调整产线节奏，上下游的订单预期跟着变化。",
					"hint": "现实：扩产会拉动上游材料需求，停产则相反。|模拟器：同板块与关联材料可能跟着波动。"})
	if corp.is_empty():
		return 0.0
	var kind2: String = str(corp.get("kind", ""))
	var left: int = int(corp.get("left", 0))
	if kind2 == "BUYBACK":
		f = 0.16
		q["shares"] = maxf(0.45, float(q["shares"]) * 0.995)
	elif kind2 == "INSIDER":
		# 反身性：情绪高位减、低位增
		f = -0.20 * float(q["s"])
	elif kind2 == "ISSUANCE":
		f = -0.10
		q["shares"] = minf(2.2, float(q["shares"]) * 1.18)
		left = 0
	elif kind2 == "EXPAND":
		f = 0.09
		var sec: String = str(instruments[code].get("sector", ""))
		industry[sec] = clampf(float(industry.get(sec, 0.0)) + 0.012, -0.35, 0.35)
	left -= 1
	corp["left"] = left
	if left <= 0:
		q["corp"] = {}
	else:
		q["corp"] = corp
	return f

## ---- P3 游资：拉高出货 ----
func _pump_flow(code: String, q: Dictionary, att: float, s: float) -> float:
	var pump: Dictionary = q["pump"]
	if pump.is_empty():
		if att > 2.4 and s > 0.55 and rng.randf() < 0.06:
			pump["left"] = 4
			q["pump"] = pump
			return 0.28
		return 0.0
	var left: int = int(pump.get("left", 0))
	var f: float = 0.24 if left > 2 else -0.30
	left -= 1
	if left <= 0:
		q["pump"] = {}
	else:
		pump["left"] = left
		q["pump"] = pump
	return f

## ---- 对外读数 ----
func day_impact(code: String) -> float:
	if not enabled or code.begins_with("C.") or not st.has(code):
		return 0.0
	return float(st[code]["flow"])

func minute_impact(code: String) -> float:
	return day_impact(code) / SESSION_MIN

func vol_parts(code: String) -> Array:
	if not enabled or not st.has(code):
		return []
	var q: Dictionary = st[code]
	return [float(q["vr"]), float(q["vi"]), float(q["vc"])]

func snapshot(code: String) -> Dictionary:
	if not enabled or not st.has(code):
		return {}
	var q: Dictionary = st[code]
	var ri := 0.0
	for v in q["hist_ret"]:
		ri += float(v)
	var ii := 0.0
	for v in q["hist_inst"]:
		ii += float(v)
	var follow: float = clampf((absf(float(q["s"])) * 60.0
			+ clampf(float(q["att"]) / 4.0, 0.0, 1.0) * 40.0), 0.0, 100.0)
	return {"retail5": ri, "inst5": ii, "follow": follow}

func consume_notices() -> Array:
	var out: Array = notices.duplicate(true)
	notices.clear()
	return out

func is_commodity(code: String) -> bool:
	return code.begins_with("C.")

## ---- 存读档：企业行为 / 情绪 / 股本 / RNG 状态全部持久化 ----
func serialize() -> Dictionary:
	return {
		"enabled": enabled, "run_seed": run_seed, "temperament": temperament,
		"day": _day, "rng_state": rng.state,
		"st": st.duplicate(true), "industry": industry.duplicate(true),
		"pending_att": pending_att.duplicate(true),
		"pending_news": pending_news.duplicate(true),
		"notices": notices.duplicate(true),
	}

func deserialize(d: Dictionary) -> void:
	if d.is_empty():
		return
	enabled = bool(d.get("enabled", false))
	run_seed = int(d.get("run_seed", 0))
	temperament = clampi(int(d.get("temperament", 1)), 0, 2)
	_day = int(d.get("day", -1))
	st = d.get("st", {})
	industry = d.get("industry", {})
	pending_att = d.get("pending_att", {})
	pending_news = d.get("pending_news", {})
	notices = d.get("notices", [])
	rng.seed = run_seed
	var rs: int = int(d.get("rng_state", 0))
	if rs != 0:
		rng.state = rs
