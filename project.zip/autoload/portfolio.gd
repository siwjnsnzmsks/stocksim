extends Node
## 持仓与现金

var cash := 0.0
var init_cash := 0.0
var positions: Dictionary = {}   # code -> {qty, cost}
const FEE := 0.0003              # 佣金万三

func reset(start_cash: float) -> void:
	cash = start_cash
	init_cash = start_cash
	positions = {}

func buy(code: String, price: float, qty: int) -> bool:
	if qty <= 0 or price <= 0.0:
		return false
	var cost := price * qty * (1.0 + FEE)
	if cost > cash:
		return false
	cash -= cost
	if positions.has(code):
		var p: Dictionary = positions[code]
		var new_qty: int = int(p["qty"]) + qty
		p["cost"] = (float(p["cost"]) * int(p["qty"]) + price * qty) / new_qty
		p["qty"] = new_qty
	else:
		# buy_t = 建仓时的游戏分钟，用于"买入后涨幅"与持有天数
		positions[code] = {"qty": qty, "cost": price, "buy_t": ClockSys.game_minute}
	EventBus.toast.emit("买入 %d 股，成交价 %.2f" % [qty, price])
	return true

func sell(code: String, price: float, qty: int) -> bool:
	if qty <= 0 or price <= 0.0 or not positions.has(code):
		return false
	var p: Dictionary = positions[code]
	if qty > int(p["qty"]):
		return false
	cash += price * qty * (1.0 - FEE)
	p["qty"] = int(p["qty"]) - qty
	if int(p["qty"]) <= 0:
		positions.erase(code)
	EventBus.toast.emit("卖出 %d 股，成交价 %.2f" % [qty, price])
	return true

func market_value() -> float:
	var mv := 0.0
	for code in positions:
		mv += Market.last_price(code) * float(positions[code]["qty"])
	return mv

## 单只持仓"买入后"的表现：以加权成本为基准，返回 {pct, pnl, buy_t, held_days}
## 涨幅按每只股票单独算，不与其他持仓混在一起，也不从账户初始资金算。
func position_perf(code: String) -> Dictionary:
	if not positions.has(code):
		return {}
	var p: Dictionary = positions[code]
	var cost: float = float(p.get("cost", 0.0))
	var qty: float = float(p.get("qty", 0))
	if cost <= 0.0 or qty <= 0.0:
		return {}
	var last: float = Market.last_price(code)
	var pct: float = (last - cost) / cost
	var buy_t: int = int(p.get("buy_t", ClockSys.game_minute))
	var held_days: int = maxi(0, floori(float(ClockSys.game_minute - buy_t) / 1440.0))
	return {"pct": pct, "pnl": (last - cost) * qty, "buy_t": buy_t, "held_days": held_days}

func total_asset() -> float:
	return cash + market_value()

func profit() -> float:
	return total_asset() - init_cash

func profit_pct() -> float:
	if init_cash <= 0.0:
		return 0.0
	return profit() / init_cash
