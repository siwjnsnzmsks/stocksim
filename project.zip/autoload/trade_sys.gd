extends Node
## 交易系统 v2：涨跌停滑点 / 排队成交 / 涨停周高溢价
##
## 设计要点（对应需求）：
##   1. 跌停卖出：买盘蒸发，滑点惩罚，最坏额外损失约 10%（封死一字板）
##   2. 涨停卖出：卖单稀缺，秒成；若持有到连板，可按本周最高价溢价结算
##   3. 正常行情：平方根冲击模型算滑点
##   4. 条件单（止损/止盈）：触发后转市价，需承担跳空与滑点
##
## 依赖：Const / EventBus / ClockSys / Market（均为 autoload，勿改顺序）

# ---------- 可调参数（设计值，需实机调手感） ---------
const SLIP_BASE := 0.003           ## 正常行情基础滑点 0.3%（约一个价差）
const SLIP_IMPACT_K := 0.25        ## 平方根冲击系数
const SLIP_DOWN_MIN := 0.03        ## 跌停卖出最小滑点 3%
const SLIP_DOWN_MAX := 0.12        ## 跌停卖出滑点上限 12%（≈“额外再损失10%”）
const SLIP_DOWN_PER_DAY := 0.02    ## 连续跌停每天额外 +2%
const FEE_RATE := 0.0003           ## 佣金万三
const TAX_RATE := 0.0005           ## 印花税万五（仅卖出）
const LOT_SIZE := 100              ## A股一手 100 股
const WEEK_MINUTES := 1440 * 5     ## 周线跨度（与 market.gd 口径一致）
const WEEK_HIGH_BONUS_CAP := 0.15  ## 周高溢价上限 15%，防连板刷钱

# ---------- 运行时状态 ----------
var _rng := RandomNumberGenerator.new()
## code -> {dir:+1涨停/-1跌停/0正常, since_minute:int, days:int}
var _limit_state: Dictionary = {}
## code -> 挂单队列 [{kind, price, qty, expire_minute, ref}, ...]
var _pending: Dictionary = {}

signal order_filled(result: Dictionary)
signal order_rejected(reason: String, info: Dictionary)

func _ready() -> void:
	_rng.randomize()
	EventBus.minute_ticked.connect(_on_minute)
	EventBus.bulk_advanced.connect(_on_bulk)

# ================= 对外查询接口 =================

## 当前涨跌停状态：返回 {limit_up, limit_down, dir, days, price}
func limit_info(code: String) -> Dictionary:
	var inst: Dictionary = Market.instrument(code)
	if inst.is_empty():
		return {}
	var price := Market.last_price(code)
	var prev := _prev_close(code)
	var mkt: int = inst.get("mkt", Const.Mkt.A)
	var limit := _limit_rate(code, mkt)
	var st: Dictionary = _limit_state.get(code, {"dir": 0, "since": 0, "days": 0})
	return {
		"limit_up": _round_price(prev * (1.0 + limit)),
		"limit_down": _round_price(prev * (1.0 - limit)),
		"limit_rate": limit,
		"dir": int(st.get("dir", 0)),
		"days": int(st.get("days", 0)),
		"prev_close": prev,
		"price": price,
	}

## 是否处在涨停 / 跌停
func is_limit_up(code: String) -> bool:
	return int(_limit_state.get(code, {}).get("dir", 0)) > 0

func is_limit_down(code: String) -> bool:
	return int(_limit_state.get(code, {}).get("dir", 0)) < 0

## 预估成交结果（下单前给玩家看的提示，提示模式用）
## 返回 {price, qty, slippage, fee, tax, fill_rate, note, week_high}
func quote(code: String, side: String, qty: int, order_type: String = "MARKET",
		limit_price: float = 0.0) -> Dictionary:
	var inst: Dictionary = Market.instrument(code)
	if inst.is_empty():
		return {"ok": false, "note": "标的不存在"}
	if qty <= 0:
		return {"ok": false, "note": "数量必须大于 0"}
	var px := Market.last_price(code)
	if px <= 0.0:
		return {"ok": false, "note": "价格无效"}
	var liq := _liquidity(code)
	var book := _orderbook(code, px, liq)
	var res := _match(code, side, qty, order_type, limit_price, book)
	res["week_high"] = _week_high(code)
	res["limit"] = limit_info(code)
	res["liquidity"] = liq
	return res

# ================= 下单接口 =================

## 主下单入口
##   side  : "BUY" / "SELL"
##   qty   : 股数（A股按手取整）
##   type  : "MARKET" 市价 / "LIMIT" 限价 / "COND" 条件单
##   price : LIMIT 时为委托价；COND 时为触发价
##   ref   : 条件单附加 {stop_dir:"UP"/"DOWN", kind:"MARKET"/"LIMIT"}
## 返回 {ok, filled, price, qty, slippage, fee, tax, note, pending}
func place_order(code: String, side: String, qty: int, order_type: String = "MARKET",
		price: float = 0.0, ref: Dictionary = {}) -> Dictionary:
	var inst: Dictionary = Market.instrument(code)
	if inst.is_empty():
		return _reject("标的不存在", {"code": code})
	if side != "BUY" and side != "SELL":
		return _reject("方向非法", {"side": side})
	var mkt: int = inst.get("mkt", Const.Mkt.A)
	if mkt == Const.Mkt.A and qty % LOT_SIZE != 0 and order_type != "COND":
		qty = int(round(float(qty) / float(LOT_SIZE))) * LOT_SIZE
	if qty <= 0:
		return _reject("数量不足一手（100 股）", {})

	# 条件单先挂起，不立即成交
	if order_type == "COND":
		return _place_cond(code, side, qty, price, ref)

	var res: Dictionary = quote(code, side, qty, order_type, price)
	if res.get("ok", false) == false:
		return _reject(String(res.get("note", "无法成交")), {"code": code})

	# 涨停时“买入”要排队：散户基本排不上，返回挂单
	if side == "BUY" and bool(res.get("queue_buy", false)):
		return _enqueue(code, side, qty, order_type, price,
			"涨停封板，已挂单排队（时间优先，成交概率约 %d%%）" % int(res.get("queue_fill_pct", 0)))

	# 跌停时“卖出”可能完全无买盘
	if side == "SELL" and bool(res.get("no_bid", false)):
		return _enqueue(code, side, qty, order_type, price,
			"跌停封死无买盘，已挂单排队（当日可能完全不成交）")

	var fill_price := float(res["price"])
	var fill_qty := int(res["filled"])
	if side == "BUY":
		var need := fill_price * fill_qty * (1.0 + FEE_RATE)
		if need > Portfolio.cash:
			# 现金不足则按可买量缩减
			fill_qty = int(floor(Portfolio.cash / (fill_price * (1.0 + FEE_RATE))))
			if mkt == Const.Mkt.A:
				fill_qty = int(floor(float(fill_qty) / float(LOT_SIZE))) * LOT_SIZE
			if fill_qty <= 0:
				return _reject("现金不足", {"need": need, "cash": Portfolio.cash})
			res["filled"] = fill_qty
			res["note"] = String(res.get("note", "")) + "（现金不足，已缩减）"
	else:
		var held := 0
		if Portfolio.positions.has(code):
			held = int(Portfolio.positions[code].get("qty", 0))
		if fill_qty > held:
			fill_qty = held
		if fill_qty <= 0:
			return _reject("无持仓", {"code": code})
		res["filled"] = fill_qty

	var fee := fill_price * fill_qty * FEE_RATE
	var tax := 0.0
	if side == "SELL" and mkt == Const.Mkt.A:
		tax = fill_price * fill_qty * TAX_RATE

	var ok := false
	if side == "BUY":
		ok = Portfolio.buy(code, fill_price, fill_qty)
	else:
		ok = Portfolio.sell(code, fill_price, fill_qty)
	if not ok:
		return _reject("账户操作失败", {"code": side})

	# 印花税从现金里单独扣（Portfolio 里只算了佣金）
	Portfolio.cash -= tax
	res["fee"] = fee
	res["tax"] = tax
	res["ok"] = true
	# 成交后标记存档，1 秒内自动覆盖写盘
	var sm = get_node_or_null("/root/SaveMgr")
	if sm:
		sm.mark_dirty()
	order_filled.emit(res)
	EventBus.toast.emit(_build_toast(res, side))
	return res

# ================= 内部撮合 =================

## 生成盘口：返回 {bid:[[price,size],...], ask:[...], spread}
func _orderbook(_code: String, px: float, liq: Dictionary) -> Dictionary:
	var depth := maxf(1.0, float(liq.get("depth", 1000.0)))
	var tick := _tick_size(px)
	var bids: Array = []
	var asks: Array = []
	for i in 5:
		var d := float(i + 1)
		bids.append([px - tick * d, depth / (d * d)])
		asks.append([px + tick * d, depth / (d * d)])
	return {"bid": bids, "ask": asks, "spread": tick, "depth": depth}

## 核心撮合：算成交价、滑点、成交率
func _match(code: String, side: String, qty: int, order_type: String,
		limit_price: float, book: Dictionary) -> Dictionary:
	var px := Market.last_price(code)
	var li: Dictionary = limit_info(code)
	var dir: int = int(li.get("dir", 0))
	var book_side: Array = book["ask"] if side == "BUY" else book["bid"]

	# ---- 跌停卖出：滑点惩罚（需求核心） ----
	if side == "SELL" and dir < 0:
		var down_days: int = int(li.get("days", 0))
		var slip: float = clampf(SLIP_DOWN_MIN + float(down_days) * SLIP_DOWN_PER_DAY,
			SLIP_DOWN_MIN, SLIP_DOWN_MAX)
		var fill_px: float = float(li.get("limit_down", px))
		fill_px = _round_price(fill_px * (1.0 - slip))
		var bid0 := float(book["bid"][0][1]) if not book["bid"].is_empty() else 0.0
		var fill_qty := qty
		if bid0 <= 0.0:
			# 封死一字板：无买盘
			return {"ok": true, "filled": 0, "price": fill_px, "slippage": slip, "premium": 0.0,
				"no_bid": true, "queue_fill_pct": 0,
				"note": "跌停封死无买盘，挂单排队；若成交将额外损失 %.1f%%" % (slip * 100.0)}
		if bid0 < float(qty):
			fill_qty = int(bid0)
		return {"ok": true, "filled": fill_qty, "price": fill_px, "slippage": slip,
			"queue_buy": false, "no_bid": false,
			"note": "跌停卖出：滑点 %.1f%%（连续跌停 %d 天），成交价 %.2f" % [slip * 100.0, down_days, fill_px]}

	# ---- 涨停买入：排队，散户难成交 ----
	if side == "BUY" and dir > 0:
		var fill_pct := _queue_fill_pct(code, qty)
		var fill_qty2 := int(round(float(qty) * fill_pct / 100.0))
		var up_px: float = float(li.get("limit_up", px))
		return {"ok": true, "filled": fill_qty2, "price": up_px, "slippage": 0.0,
			"queue_buy": true, "queue_fill_pct": fill_pct, "no_bid": false,
			"note": "涨停价 %.2f 排队，预计成交概率 %d%%" % [up_px, fill_pct]}

	# ---- 涨停卖出：秒成，按本周最高价给溢价 ----
	if side == "SELL" and dir > 0:
		var up_px2: float = float(li.get("limit_up", px))
		var wh := _week_high(code)
		var bonus := 0.0
		if wh > up_px2:
			bonus = minf((wh - up_px2) / up_px2, WEEK_HIGH_BONUS_CAP)
		var fill_px2: float = _round_price(up_px2 * (1.0 + bonus))
		return {"ok": true, "filled": qty, "price": fill_px2, "slippage": 0.0, "premium": bonus,
			"queue_buy": false, "no_bid": false,
			"note": "涨停卖出秒成，含本周高点溢价 %.1f%%，成交价 %.2f" % [bonus * 100.0, fill_px2]}

	# ---- 限价单：价格不穿透则按限价成交 ----
	if order_type == "LIMIT" and limit_price > 0.0:
		var crossed := (side == "BUY" and limit_price >= px) or (side == "SELL" and limit_price <= px)
		if crossed:
			var slip_l := SLIP_BASE
			return {"ok": true, "filled": qty, "price": limit_price, "slippage": slip_l, "premium": 0.0,
				"queue_buy": false, "no_bid": false,
				"note": "限价单穿透成交，滑点 %.1f%%" % (slip_l * 100.0)}
		return {"ok": true, "filled": 0, "price": limit_price, "slippage": 0.0,
			"queue_buy": true, "queue_fill_pct": 0, "no_bid": false,
			"note": "限价未触及，已挂单 %s %.2f" % ["买入" if side == "BUY" else "卖出", limit_price]}

	# ---- 正常行情：平方根冲击模型 ----
	# 注意：只走一条价格路径。先用冲击模型定滑点，再吃盘口档位取实际均价；
	#       不再把滑点二次乘到价格上（旧版这里重复计算，导致 100 股就 2% 滑点）
	var depth := maxf(1.0, float(book.get("depth", 1000.0)))
	var slip_n: float = SLIP_BASE + SLIP_IMPACT_K * sqrt(float(qty) / depth)
	slip_n = clampf(slip_n, SLIP_BASE, 0.5)   # 正常行情滑点封顶 50%，防极端单量
	var exec_px := px
	var fill_qty_n := qty
	if side == "BUY":
		exec_px = px * (1.0 + slip_n)
		# 吃穿盘口档位，用实际加权均价替代
		var left := float(qty)
		var acc := 0.0
		var filled_n := 0.0
		for lvl in book_side:
			var lv_size := float(lvl[1])
			var take: float = minf(left, lv_size)
			acc += take * float(lvl[0])
			filled_n += take
			left -= take
			if left <= 0.0:
				break
		if left <= 0.0 and filled_n > 0.0:
			exec_px = acc / filled_n
		else:
			# 盘口吃穿后仍有剩余：深度不足，只能部分成交，滑点取上限
			fill_qty_n = int(filled_n)
			if fill_qty_n <= 0:
				return {"ok": true, "filled": 0, "price": _round_price(px),
					"slippage": 0.0, "premium": 0.0, "queue_buy": true,
					"note": "盘口过薄，无法成交，已挂单"}
			slip_n = 0.5
			exec_px = acc / filled_n
	else:
		exec_px = px * (1.0 - slip_n)
	return {"ok": true, "filled": fill_qty_n, "price": _round_price(exec_px),
		"slippage": slip_n, "premium": 0.0, "queue_buy": false, "no_bid": false,
		"note": "成交，滑点 %.2f%%" % (slip_n * 100.0)}

# ================= 条件单与挂单 =================

func _place_cond(code: String, side: String, qty: int, trigger: float, ref: Dictionary) -> Dictionary:
	if trigger <= 0.0:
		return _reject("条件单需给触发价", {})
	var dir: String = String(ref.get("stop_dir", "DOWN" if side == "SELL" else "UP"))
	var kind: String = String(ref.get("kind", "MARKET"))
	if not _pending.has(code):
		_pending[code] = []
	_pending[code].append({
		"kind": "COND", "side": side, "qty": qty, "trigger": trigger,
		"dir": dir, "exec": kind, "ref": ref,
		"expire_minute": ClockSys.game_minute + 1440 * 30,
	})
	EventBus.toast.emit("条件单已挂：%s %s 触发价 %.2f" % [code, "止损" if dir == "DOWN" else "止盈", trigger])
	return {"ok": true, "pending": true, "filled": 0, "note": "条件单已挂起"}

func _enqueue(code: String, side: String, qty: int, order_type: String,
		price: float, note: String) -> Dictionary:
	if not _pending.has(code):
		_pending[code] = []
	_pending[code].append({
		"kind": order_type, "side": side, "qty": qty, "price": price,
		"expire_minute": ClockSys.game_minute + 1440,
	})
	EventBus.toast.emit(note)
	return {"ok": true, "pending": true, "filled": 0, "note": note}

## 每分钟推进：更新涨跌停连续天数、尝试撮合挂单
func _on_minute(minute: int) -> void:
	_update_limit_state(minute)
	_try_fill_pending(minute)

## 批量推进不再逐分钟 emit，挂单若只挂在 minute_ticked 上会永远不成交。
## 用区间末刻做一次状态更新 + 撮合，语义等价于"这一批走完后的最终状态"。
func _on_bulk(_from_min: int, to_min: int) -> void:
	_update_limit_state(to_min)
	_try_fill_pending(to_min)

func _update_limit_state(minute: int) -> void:
	for code in Market.instruments:
		var inst: Dictionary = Market.instruments[code]
		if not Market._is_open(int(inst.get("mkt", Const.Mkt.A)), minute):
			continue
		var li := limit_info(code)
		var d: int = int(li.get("dir", 0))
		var st: Dictionary = _limit_state.get(code, {"dir": 0, "since": minute, "days": 0})
		if d != 0 and int(st.get("dir", 0)) == d:
			# 连续同向：满一天才累加天数
			if minute - int(st.get("since", minute)) >= 1440:
				st["days"] = int(st.get("days", 0)) + 1
				st["since"] = minute
		elif d != int(st.get("dir", 0)):
			st = {"dir": d, "since": minute, "days": 1 if d != 0 else 0}
		_limit_state[code] = st

func _try_fill_pending(minute: int) -> void:
	for code in _pending.keys():
		var arr: Array = _pending[code]
		var keep: Array = []
		for od in arr:
			if int(od.get("expire_minute", 0)) < minute:
				EventBus.toast.emit("%s 挂单已过期撤单" % code)
				continue
			if String(od.get("kind", "")) == "COND":
				var px := Market.last_price(code)
				var trig: float = float(od.get("trigger", 0.0))
				var dir: String = str(od.get("dir", "DOWN"))
				var hit := (dir == "DOWN" and px <= trig) or (dir == "UP" and px >= trig)
				if hit:
					var exec_type: String = str(od.get("exec", "MARKET"))
					var lp := 0.0
					if exec_type == "LIMIT":
						lp = trig
						exec_type = "LIMIT"
					place_order(code, String(od["side"]), int(od["qty"]), exec_type, lp)
					continue
			else:
				# 普通挂单：价格回到可成交区间则按市价重下
				var lp2: float = float(od.get("price", 0.0))
				var px2 := Market.last_price(code)
				var ok: bool = (String(od["side"]) == "BUY" and px2 <= lp2) \
		or (String(od["side"]) == "SELL" and px2 >= lp2)
				if ok:
					place_order(code, String(od["side"]), int(od["qty"]), "MARKET")
					continue
			keep.append(od)
		if keep.is_empty():
			_pending.erase(code)
		else:
			_pending[code] = keep

# ================= 工具函数 =================

func _limit_rate(code: String, mkt: int) -> float:
	if mkt == Const.Mkt.A:
		# 主板/ST 均 10%（ST 自 2026-07-06 由 5% 放宽到 10%），创业板 30x/301 开头 20%，北交所 30%
		var c := code
		var sname: String = str(Market.instrument(code).get("name", ""))
		if c.begins_with("30") or c.begins_with("301") or c.begins_with("688"):
			return Const.LIMIT_GEM
		if c.begins_with("8") or c.begins_with("4"):
			return Const.LIMIT_BJ
		return Const.LIMIT_ST if sname.begins_with("ST") else Const.LIMIT_A
	if mkt == Const.Mkt.US:
		return 1.0
	return 1.0   # 商品不设涨跌停

func _prev_close(code: String) -> float:
	var inst: Dictionary = Market.instrument(code)
	if inst.is_empty():
		return 0.0
	var bars: Array = inst.get("bars", [])
	# 找上一根跨日的收盘价
	var cur_day: int = floori(float(int(bars[-1].get("t", 0))) / 1440.0) if not bars.is_empty() else 0
	for i in range(bars.size() - 1, -1, -1):
		if floori(float(int(bars[i].get("t", 0))) / 1440.0) < cur_day:
			return float(bars[i].get("c", Market.last_price(code)))
	return float(inst.get("base", Market.last_price(code)))

## 本周最高价（周一起算，仅取本周已走的交易日）
func _week_high(code: String) -> float:
	var bars: Array = Market.get_bars(code, Const.Period.M1)
	if bars.is_empty():
		return 0.0
	var last_t: int = int(bars[-1].get("t", 0))
	var day: int = floori(float(last_t) / 1440.0)
	var week_start: int = day - day % 7   # 与 ClockSys/周线分桶一致（每 7 天）
	var hi := 0.0
	for b in bars:
		if floori(float(int(b.get("t", 0))) / 1440.0) >= week_start:
			hi = maxf(hi, float(b.get("h", 0.0)))
	return hi if hi > 0.0 else Market.last_price(code)

## 当日成交量（用于流动性深度）
func _liquidity(code: String) -> Dictionary:
	var inst: Dictionary = Market.instrument(code)
	var bars: Array = inst.get("bars", [])
	var vol := 0.0
	if not bars.is_empty():
		var day: int = floori(float(int(bars[-1].get("t", 0))) / 1440.0)
		for b in bars:
			if floori(float(int(b.get("t", 0))) / 1440.0) == day:
				vol += float(b.get("v", 0.0))
	return {"depth": maxf(vol, 100.0), "today_vol": vol}

func _queue_fill_pct(code: String, qty: int) -> int:
	var liq := _liquidity(code)
	var depth: float = float(liq.get("depth", 1000.0))
	var pct := 100.0 - float(qty) / maxf(depth, 1.0) * 100.0
	# 散户单量相对封单极小，成交概率低
	pct = clampf(pct * 0.15, 0.0, 25.0)
	return int(round(pct))

func _tick_size(px: float) -> float:
	if px >= 100.0:
		return 0.1
	if px >= 10.0:
		return 0.01
	return 0.001

func _round_price(p: float) -> float:
	if p >= 100.0:
		return snappedf(p, 0.1)
	if p >= 10.0:
		return snappedf(p, 0.01)
	return snappedf(p, 0.001)

func _reject(reason: String, info: Dictionary) -> Dictionary:
	order_rejected.emit(reason, info)
	EventBus.toast.emit("下单失败：" + reason)
	return {"ok": false, "note": reason}

func _build_toast(res: Dictionary, side: String) -> String:
	var act := "买入" if side == "BUY" else "卖出"
	return "%s %d 股 @ %.2f（%s）" % [act, int(res.get("filled", 0)),
		float(res.get("price", 0.0)), String(res.get("note", ""))]

## 挂单列表（界面用）
func pending_orders(code: String) -> Array:
	return _pending.get(code, [])

func all_pending() -> Dictionary:
	return _pending
