extends Node
## 全局信号总线：解耦各系统

signal game_started(cash: float)          # 游戏开始，带初始资金
signal minute_ticked(game_minute: int)    # 游戏内每推进1分钟
signal bulk_advanced(from_minute: int, to_minute: int)  # 快档按日批量推进
signal day_changed(day: int)              # 跨天
signal event_triggered(ev: Dictionary)    # 事件播报（提示模式用）
signal price_updated()                    # 行情刷新，界面重绘
signal toast(text: String)                # 顶部轻提示

## 这些信号由其它 autoload 连接/发送，静态分析器不跨文件识别，会误报"未使用"。
## 此函数仅供编译期引用，永远不会被调用，无运行时副作用。
func _reference_signals() -> void:
	game_started.emit(0.0)
	minute_ticked.emit(0)
	bulk_advanced.emit(0, 0)
	day_changed.emit(0)
	event_triggered.emit({})
	price_updated.emit()
	toast.emit("")
