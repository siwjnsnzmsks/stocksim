extends Node
## 时间系统：现实中 1 秒 = 游戏里 N 分钟
## 慢档 60（1小时） / 中档 1440（1天） / 快档 10080（1周）
##
## 修复记录：
##  - 旧版 mini(steps,240) 把截掉的拍数留在 _carry 里，快档卡一帧就永久欠债，
##    三档被压到同一个上限，看起来"流速一样"。现在超预算直接丢弃，不追帧。
##  - 快档不再逐分钟 emit（一帧 168 拍 × 36 标的 = 6000 次循环），
##    改用 bulk_advanced 按日批量推进，一帧最多几根日线。

enum Speed { SLOW, NORMAL, FAST }
const SPEED_MINUTES := [60, 1440, 10080]
const SPEED_LABEL := ["1秒=1小时", "1秒=1天", "1秒=1周"]
const SPEED_DAYS := ["1/24 天", "1 天", "7 天"]   # 每现实秒推进的游戏天数，用于界面明示

const MAX_STEPS_PER_FRAME := 20000      # 切后台回来的兜底上限
const BULK_THRESHOLD := 240            # 超过就走按日批量

var speed: int = Speed.NORMAL
var paused := true
var game_minute := 0
var _carry := 0.0
var _started := false

func _process(delta: float) -> void:
	if not _started or paused:
		return
	_carry += delta * float(SPEED_MINUTES[speed])
	var steps: int = int(floor(_carry))
	_carry -= float(steps)
	# 超预算直接丢弃（不累积债务）：宁可少走一点，也不能让快档被钉死在上限
	if steps > MAX_STEPS_PER_FRAME:
		steps = MAX_STEPS_PER_FRAME
		_carry = 0.0
	if steps <= 0:
		return

	var prev_day: int = floori(float(game_minute) / 1440.0)
	var from_min: int = game_minute + 1
	if steps <= BULK_THRESHOLD:
		# 慢档 / 中档：逐分钟，保留原有逐拍行为
		for i in steps:
			game_minute += 1
			EventBus.minute_ticked.emit(game_minute)
	else:
		# 快档：按日批量推进行情，避免每帧几千次循环
		EventBus.bulk_advanced.emit(from_min, from_min + steps - 1)
		game_minute += steps
	var now_day: int = floori(float(game_minute) / 1440.0)
	# 跨了几天就补发几次，事件调度按游戏日走（批量时最多几次，开销可忽略）
	for d in range(prev_day + 1, now_day + 1):
		EventBus.day_changed.emit(d)
	EventBus.price_updated.emit()

func start() -> void:
	_started = true
	paused = false
	_carry = 0.0

## 重置进度：时间归零并停住，等玩家选完初始资金再 start()
## 必须清 _carry / _started，否则回到启动页时钟还在后台偷偷跑，日期又涨上去了
func reset() -> void:
	game_minute = 0
	_carry = 0.0
	_started = false
	paused = true
	speed = Speed.NORMAL

func speed_label() -> String:
	return SPEED_LABEL[speed]

func days_per_second() -> String:
	return SPEED_DAYS[speed]

func set_speed(s: int) -> void:
	# 只改档位，不碰 paused：暂停状态下切速度仍应保持暂停
	speed = clampi(s, 0, 2)
	_carry = 0.0

func toggle_pause() -> void:
	if not _started:
		return
	paused = not paused
	_carry = 0.0

func step_once() -> void:
	if not _started:
		return
	paused = true
	game_minute += 1
	EventBus.minute_ticked.emit(game_minute)
	EventBus.price_updated.emit()

func current_day() -> int:
	return floori(float(game_minute) / 1440.0)
