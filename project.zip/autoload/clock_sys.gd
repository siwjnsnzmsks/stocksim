extends Node
## 时间系统：现实中 1 秒 = 游戏里 N 分钟
## 慢档 60（1小时） / 中档 1440（1天） / 快档 10080（1周）
##
## 修复记录：
##  - 旧版 mini(steps,240) 把截掉的拍数留在 _carry 里，快档卡一帧就永久欠债，
##    三档被压到同一个上限，看起来"流速一样"。现在超预算直接丢弃，不追帧。
##  - 快档不再逐分钟 emit（一帧 168 拍 × 36 标的 = 6000 次循环），
##    改用 bulk_advanced 按日批量推进，一帧最多几根日线。

enum Speed { SLOW, NORMAL, FAST }
const SPEED_MINUTES := [60, 1440, 10080]
const SPEED_LABEL := ["1秒=1小时", "1秒=1天", "1秒=1周"]
const SPEED_DAYS := ["1/24 天", "1 天", "7 天"]   # 每现实秒推进的游戏天数，用于界面明示

const MAX_STEPS_PER_FRAME := 20000      # 切后台回来的兜底上限
# 旧值 240 永远不触发：快档每帧只 168 拍（10080/60），于是三档全都逐分钟 emit。
# 改成 8，中/快档一律走批量；慢档每拍 6 分钟仍逐分钟。
const BULK_THRESHOLD := 8
# 行情推进降到 10Hz：原来 60fps 每帧都遍历 87 标的 × 168 拍 × 2 个订阅者，
# 主线程被占满，才导致"时间一走，切页/点按钮/K线全卡"。
const TICK_INTERVAL := 0.1

var speed: int = Speed.NORMAL
var paused := true
var game_minute := 0
var _carry := 0.0
var _acc := 0.0
var _started := false

func _process(delta: float) -> void:
	if not _started or paused:
		_acc = 0.0
		_carry = 0.0
		return
	_acc += delta
	if _acc < TICK_INTERVAL:
		return
	var dt: float = _acc
	_acc = 0.0
	_carry += dt * float(SPEED_MINUTES[speed])
	var steps: int = int(floor(_carry))
	_carry -= float(steps)
	# 超预算直接丢弃（不累积债务）：宁可少走一点，也不能让快档被钉死在上限
	if steps > MAX_STEPS_PER_FRAME:
		steps = MAX_STEPS_PER_FRAME
		_carry = 0.0
	if steps <= 0:
		return

	## 顺序（内生价格层的硬约束）：day_changed 必须在「该日行情推进之前」发出。
	## 旧版把跨天补发放到一帧末尾，慢档每天都经过 day_changed、快档却要等
	## 批量跑完才补发几天，事件跳价的时点两档不一致，Flow 的目标价就对不上。
	## 现在慢档在跨那一分钟前先发，快档按「游戏日」切片、每段之前先发，
	## 于是两档都是：先事件跳价 → 再用跳后价算当日资金流 → 再推行情。
	var end_min: int = game_minute + steps
	if steps <= BULK_THRESHOLD:
		# 慢档 / 中档：逐分钟，保留原有逐拍行为
		for i in steps:
			var next_min: int = game_minute + 1
			if floori(float(next_min) / 1440.0) > floori(float(game_minute) / 1440.0):
				EventBus.day_changed.emit(floori(float(next_min) / 1440.0))
			game_minute = next_min
			EventBus.minute_ticked.emit(game_minute)
	else:
		# 快档：按游戏日切成多段批量推进，每段一天，段首先发 day_changed。
		var cur_min: int = game_minute
		while cur_min < end_min:
			var d_cur: int = floori(float(cur_min + 1) / 1440.0)
			var boundary: int = (d_cur + 1) * 1440 - 1
			var seg_end: int = mini(end_min, boundary)
			if floori(float(cur_min + 1) / 1440.0) > floori(float(cur_min) / 1440.0):
				EventBus.day_changed.emit(d_cur)
			EventBus.bulk_advanced.emit(cur_min + 1, seg_end)
			game_minute = seg_end
			cur_min = seg_end
	EventBus.price_updated.emit()

func start() -> void:
	_started = true
	paused = false
	_carry = 0.0

## 重置进度：时间归零并停住，等玩家选完初始资金再 start()
## 必须清 _carry / _started，否则回到启动页时钟还在后台偷偷跑，日期又涨上去了
func reset() -> void:
	game_minute = 0
	_carry = 0.0
	_acc = 0.0
	_started = false
	paused = true
	speed = Speed.NORMAL

func speed_label() -> String:
	return SPEED_LABEL[speed]

func days_per_second() -> String:
	return SPEED_DAYS[speed]

func set_speed(s: int) -> void:
	# 只改档位，不碰 paused：暂停状态下切速度仍应保持暂停
	speed = clampi(s, 0, 2)
	_carry = 0.0
	_acc = 0.0

func toggle_pause() -> void:
	if not _started:
		return
	paused = not paused
	_carry = 0.0
	_acc = 0.0

func step_once() -> void:
	if not _started:
		return
	paused = true
	var next_min2: int = game_minute + 1
	if floori(float(next_min2) / 1440.0) > floori(float(game_minute) / 1440.0):
		EventBus.day_changed.emit(floori(float(next_min2) / 1440.0))
	game_minute = next_min2
	EventBus.minute_ticked.emit(game_minute)
	EventBus.price_updated.emit()

func current_day() -> int:
	return floori(float(game_minute) / 1440.0)
