extends Node
## 全局常量与枚举

# 市场
enum Mkt { A, US, COMMODITY }
const MKT_NAME := ["A股", "美股", "商品"]

# 涨跌停（比例）
const LIMIT_A := 0.10        # A股主板 ±10%
const LIMIT_GEM := 0.20      # 创业板 30x/301x、科创板 688x ±20%
const LIMIT_BJ := 0.30       # 北交所 8x/4x ±30%
const LIMIT_ST := 0.10       # ST 自 2026-07-06 起由 5% 放宽到 10%
const LIMIT_US := 1.0        # 美股/商品不设涨跌停（模拟给个宽松值）

# K线周期
enum Period { M1, M5, M15, M60, DAY, WEEK, MONTH }
const PERIOD_LABEL := ["1分", "5分", "15分", "60分", "日K", "周K", "月K"]
const PERIOD_MINUTES := [1, 5, 15, 60, 0, 0, 0]

# ---------------- 白色主题（同花顺浅色风格）----------------
# 红涨绿跌，A股习惯
const UP    := Color(0.89, 0.17, 0.21)   # 涨 红
const DOWN  := Color(0.04, 0.60, 0.34)   # 跌 绿
const FLAT  := Color(0.42, 0.45, 0.50)   # 中性灰文字

const BG        := Color(1.00, 1.00, 1.00)   # 主背景 纯白
const PANEL     := Color(0.96, 0.97, 0.985)  # 卡片/面板 浅灰
const HEADER    := Color(0.97, 0.98, 0.995)  # 顶栏
const GRID      := Color(0.90, 0.92, 0.94)   # 网格线
const BORDER    := Color(0.84, 0.87, 0.90)   # 边框
const TEXT      := Color(0.13, 0.15, 0.18)   # 主文字 深灰
const TEXT_SUB  := Color(0.45, 0.48, 0.53)   # 次要文字
const ACCENT    := Color(0.13, 0.42, 0.86)   # 选中/主按钮 蓝
const ACCENT_BG := Color(0.90, 0.94, 1.00)   # 选中态浅蓝底
const CARD      := Color(1.00, 1.00, 1.00)   # 列表卡片

# ---------------- 游戏日历 ----------------
## t 是"游戏内累计分钟"（t=0 为开局时刻）。统一在这里换算日期，
## 主界面右上角、新闻时间线、K 线日期轴共用，避免各处算出不同日期。
const BASE_UNIX := 1767225600            # 2026-01-01 00:00:00 UTC

func game_unix(minute: int) -> int:
	return BASE_UNIX + minute * 60

func game_date(minute: int) -> String:
	var d: Dictionary = Time.get_datetime_dict_from_unix_time(game_unix(minute))
	return "%04d-%02d-%02d" % [int(d["year"]), int(d["month"]), int(d["day"])]

func game_datetime(minute: int) -> String:
	var d: Dictionary = Time.get_datetime_dict_from_unix_time(game_unix(minute))
	return "%02d-%02d %02d:%02d" % [int(d["month"]), int(d["day"]), int(d["hour"]), int(d["minute"])]

func game_short_datetime(minute: int) -> String:
	var d: Dictionary = Time.get_datetime_dict_from_unix_time(game_unix(minute))
	return "%02d/%02d %02d:%02d" % [int(d["month"]), int(d["day"]), int(d["hour"]), int(d["minute"])]

func game_full_datetime(minute: int) -> String:
	var d: Dictionary = Time.get_datetime_dict_from_unix_time(game_unix(minute))
	return "%04d-%02d-%02d %02d:%02d" % [int(d["year"]), int(d["month"]), int(d["day"]), int(d["hour"]), int(d["minute"])]

## 事件季节调度用：取该游戏时刻所在的月份(1..12)
func game_month(minute: int) -> int:
	var d: Dictionary = Time.get_datetime_dict_from_unix_time(game_unix(minute))
	return int(d["month"])

## 季节名，用于新闻文案
func season_name(month: int) -> String:
	if month >= 3 and month <= 5: return "春季"
	if month >= 6 and month <= 8: return "夏季"
	if month >= 9 and month <= 11: return "秋季"
	return "冬季"
