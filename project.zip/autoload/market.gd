extends Node
## 行情引擎 v3：历史日线 + 近端分钟线 双层存储
##  - inst["days"]：260 根历史日线 + 实时当日线，日/周/月K 直接取，切周期零等待
##  - inst["bars"]：最近 1800 根分钟线，1/5/15/60 分K 用
##  - get_bars 带版本缓存：同一帧内重复取数不再重算聚合
##  - 周K按真实日历周（周一起）、月K按自然月分桶，不再 7天/30天 硬切
##  - 休市标的最先跳过，快档一帧少算三分之二

const BUDGET := 0.06
const BASE_VOL_PER_MIN := 0.0006
const HIST_DAYS := 260
const MAX_DAYS := 520
const MAX_MIN_BARS := 1800

var instruments: Dictionary = {}   # code -> {name,sector,group,rd,rival,base,vol,mkt,bars,days,c,shock}
var _by_sector: Dictionary = {}    # sector -> [code,...]
var _by_rival: Dictionary = {}     # rival赛道 -> [code,...]，用于科研点同业对比
var _tech_codes: Array = []        # 有科研点的科技公司
var _last_research_day: int = 0
var _rng := RandomNumberGenerator.new()
var _initialized := false

var _cache: Dictionary = {}        # "code|period" -> {ver:int, bars:Array}
var _ver: int = 0

func _ready() -> void:
	_rng.randomize()
	EventBus.minute_ticked.connect(_on_minute)
	EventBus.bulk_advanced.connect(_on_bulk)
	EventBus.day_changed.connect(_on_day_tick)
	EventBus.event_triggered.connect(_on_event)

func is_initialized() -> bool:
	return _initialized

## 重置进度：清空行情，让下一次 init_market() 重新预填历史，
## 否则新一局开局看到的还是上一局跑到最后的 K 线和残留的事件冲击。
func reset_market() -> void:
	instruments.clear()
	_by_sector.clear()
	_by_rival.clear()
	_tech_codes.clear()
	_last_research_day = 0
	_cache.clear()
	_initialized = false
	bump_version()

## 行情数据变了就升版本，缓存自动失效
func bump_version() -> void:
	_ver += 1

func init_market() -> void:
	if _initialized:
		return
	var f: FileAccess = FileAccess.open("res://data/instruments.json", FileAccess.READ)
	if f == null:
		push_error("instruments.json 读取失败")
		return
	var data = JSON.parse_string(f.get_as_text())
	f.close()
	for mkt_key in ["A", "US", "COMMODITY"]:
		var _mkt_map := {"A": Const.Mkt.A, "US": Const.Mkt.US, "COMMODITY": Const.Mkt.COMMODITY}
		var mkt_id: int = int(_mkt_map[mkt_key])
		for it in data.get(mkt_key, []):
			var code: String = it["code"]
			var rd_v: float = float(it.get("rd", 0.0))
			var rival_v: String = str(it.get("rival", ""))
			instruments[code] = {
				"code": code, "name": it["name"], "sector": it["sector"],
				"group": str(it.get("group", "其他")),
				"rd": rd_v, "rival": rival_v,
				"base": float(it["base"]), "vol": float(it["vol"]),
				"mkt": mkt_id, "bars": [], "days": [],
				"c": float(it["base"]), "shock": 0.0,
			}
			var sec: String = it["sector"]
			if not _by_sector.has(sec):
				_by_sector[sec] = []
			_by_sector[sec].append(code)
			# 科研点赛道：只有"有 rival 且 rd>0"的公司参与同业比拼
			if rd_v > 0.0 and rival_v != "":
				_tech_codes.append(code)
				if not _by_rival.has(rival_v):
					_by_rival[rival_v] = []
				_by_rival[rival_v].append(code)
	_prefill_history()
	_cache.clear()
	_initialized = true
	bump_version()

## 开局预填：260 根历史日线（日/周/月K 一进来就有内容）+ 240 根预热分钟线
func _prefill_history() -> void:
	for code in instruments:
		var inst = instruments[code]
		var price: float = float(inst["base"])
		var vol: float = float(inst["vol"])
		var days: Array = []
		for i in HIST_DAYS:
			var o: float = price
			var c: float = maxf(0.01, o * (1.0 + _rng.randfn(0.0002, vol)))
			var h: float = maxf(o, c) * (1.0 + absf(_rng.randfn(0.0, vol * 0.55)))
			var l: float = minf(o, c) * (1.0 - absf(_rng.randfn(0.0, vol * 0.55)))
			var dnum: int = -(HIST_DAYS - i)
			days.append({
				"o": o, "h": h, "l": l, "c": c,
				"v": _rng.randf_range(10000.0, 1000000.0),
				"t": dnum * 1440, "day": dnum,
			})
			price = c
		# 当日线（游戏分钟 0 起），实时推进时只更新这一根
		days.append({"o": price, "h": price, "l": price, "c": price,
					"v": 0.0, "t": 0, "day": 0})
		inst["days"] = days
		inst["c"] = price
		var warm: Array = []
		var p2: float = price
		for m in range(1, 241):
			p2 = maxf(0.01, p2 * (1.0 + _rng.randfn(0.0, BASE_VOL_PER_MIN)))
			warm.append({"o": p2, "h": p2, "l": p2, "c": p2,
						"v": _rng.randf_range(100.0, 1000.0), "t": -240 + m})
		inst["bars"] = warm

func _is_open(mkt: int, minute: int) -> bool:
	var in_day := (minute % 1440)
	if mkt == Const.Mkt.COMMODITY:
		return true
	var day_of_week := floori(float(minute) / 1440.0) % 7
	if day_of_week >= 5:
		return false
	if mkt == Const.Mkt.US:
		return in_day >= 1290 or in_day <= 240
	return (570 <= in_day and in_day <= 690) or (780 <= in_day and in_day <= 900)

func _on_minute(minute: int) -> void:
	if not _initialized:
		return
	var day_idx: int = floori(float(minute) / 1440.0)
	var changed: bool = false
	for code in instruments:
		var inst = instruments[code]
		var mkt: int = int(inst["mkt"])
		# 休市最先跳过：A股一天只开 240 分钟，快档下能省掉大部分循环
		if not _is_open(mkt, minute):
			inst["shock"] = float(inst["shock"]) * 0.999
			continue
		var bars: Array = inst["bars"]
		var last: float = float(bars[-1]["c"])
		var shock: float = float(inst["shock"])
		var vol: float = float(inst["vol"]) * BASE_VOL_PER_MIN * 20.0
		var step: float = _rng.randfn(0.0, vol) + shock
		var price: float = last * (1.0 + step)
		var limit: float = Const.LIMIT_A if mkt == Const.Mkt.A else Const.LIMIT_US
		price = clampf(price, last * (1.0 - limit), last * (1.0 + limit))
		var bar: Dictionary = {
			"o": last, "h": maxf(last, price), "l": minf(last, price),
			"c": price, "v": _rng.randf_range(100.0, 2000.0), "t": minute,
		}
		bars.append(bar)
		if bars.size() > MAX_MIN_BARS:
			inst["bars"] = bars.slice(bars.size() - MAX_MIN_BARS)
		inst["shock"] = shock * 0.97
		# 日线跨天新建、当天原地更新：切到日/周/月K 不用临时聚合
		var days: Array = inst["days"]
		if int(days[-1]["day"]) != day_idx:
			days.append({
				"o": last, "h": maxf(last, price), "l": minf(last, price),
				"c": price, "v": float(bar["v"]), "t": day_idx * 1440, "day": day_idx,
			})
			if days.size() > MAX_DAYS:
				inst["days"] = days.slice(days.size() - MAX_DAYS)
				days = inst["days"]
		var cur: Dictionary = days[-1]
		cur["h"] = maxf(float(cur["h"]), price)
		cur["l"] = minf(float(cur["l"]), price)
		cur["c"] = price
		cur["v"] = float(cur["v"]) + float(bar["v"])
		changed = true
	# 休市 / 暂停时数据没变，缓存继续命中，不做无谓的重新聚合
	if changed:
		bump_version()

## 快档批量推进：按"游戏日"生成日线，分钟线只留最近一段。
## 一帧最多几根日线/标的，而不是几千次逐分钟循环。
func _on_bulk(from_min: int, to_min: int) -> void:
	if not _initialized or to_min < from_min:
		return
	var changed: bool = false
	for code in instruments:
		var inst = instruments[code]
		var vol: float = float(inst["vol"])
		var days: Array = inst["days"]
		var price: float = float(days[-1]["c"])
		var shock: float = float(inst["shock"])
		var d0: int = floori(float(from_min) / 1440.0)
		var d1: int = floori(float(to_min) / 1440.0)
		var day_t: int = d0 * 1440
		for di in range(d0, d1 + 1):
			day_t = di * 1440
			# 冲击按天衰减，一天内给一次总冲击，避免逐分钟放大
			var step_day: float = _rng.randfn(0.0004, vol) + shock
			var o: float = price
			price = maxf(0.01, price * (1.0 + step_day))
			var h: float = maxf(o, price) * (1.0 + absf(_rng.randfn(0.0, vol * 0.6)))
			var l: float = minf(o, price) * (1.0 - absf(_rng.randfn(0.0, vol * 0.6)))
			if int(days[-1]["day"]) == di:
				var cur: Dictionary = days[-1]
				cur["h"] = maxf(float(cur["h"]), h)
				cur["l"] = minf(float(cur["l"]), l)
				cur["c"] = price
				cur["v"] = float(cur["v"]) + _rng.randf_range(10000.0, 1000000.0)
			else:
				days.append({
					"o": o, "h": h, "l": l, "c": price,
					"v": _rng.randf_range(10000.0, 1000000.0),
					"t": day_t, "day": di,
				})
			shock *= 0.55
		if days.size() > MAX_DAYS:
			inst["days"] = days.slice(days.size() - MAX_DAYS)
			days = inst["days"]
		inst["shock"] = shock
		# 分钟线：旧版每跨一个游戏日就重铺 120 根 × 87 标的；快档一秒跨 7 天，
		# 等于每秒构造七万多个 Dictionary —— 这才是"时间一走就卡死"的最大单点。
		# 改成每批只追加 1 根（开局已有预热分钟线），10Hz 下每秒仅 870 次 append。
		var bars: Array = inst["bars"]
		if bars.is_empty():
			bars.append({"o": price, "h": price, "l": price, "c": price,
						"v": _rng.randf_range(100.0, 2000.0), "t": to_min})
		else:
			var prev_bar: Dictionary = bars[-1]
			var o: float = float(prev_bar["c"])
			bars.append({"o": o, "h": maxf(o, price), "l": minf(o, price),
						"c": price, "v": _rng.randf_range(100.0, 2000.0), "t": to_min})
			if bars.size() > MAX_MIN_BARS:
				inst["bars"] = bars.slice(bars.size() - MAX_MIN_BARS)
		changed = true
	if changed:
		bump_version()

## 公司级一次性小幅跳价：直接改最后一根分钟线/日线收盘，
## 不经过 shock 管道（那个管道逐分钟与按日批量两套衰减，量级差十倍）。
## 这样廉政事件、科研点评级都是"一次性、幅度可控、三档速度一致"的小幅影响，
## 并且只作用于指定公司，不碰 C.* 商品、不碰同板块其它公司。
func apply_company_move(code: String, pct: float) -> void:
	if not instruments.has(code) or str(code).begins_with("C."):
		return
	var inst: Dictionary = instruments[code]
	var bars: Array = inst["bars"]
	if not bars.is_empty():
		var b: Dictionary = bars[-1]
		var old: float = float(b["c"])
		var np: float = maxf(0.01, old * (1.0 + pct))
		b["c"] = np
		b["h"] = maxf(float(b["h"]), np)
		b["l"] = minf(float(b["l"]), np)
	var days: Array = inst["days"]
	if not days.is_empty():
		var dd: Dictionary = days[-1]
		var old2: float = float(dd["c"])
		var np2: float = maxf(0.01, old2 * (1.0 + pct))
		dd["c"] = np2
		dd["h"] = maxf(float(dd["h"]), np2)
		dd["l"] = minf(float(dd["l"]), np2)
	if not bars.is_empty():
		inst["c"] = float(bars[-1]["c"])
	bump_version()

## 顺应当前时代发展：每 30 个游戏日推进一次科研点，同赛道做相对比较。
## 领跑者轻微溢价，科研点落后的一方按差距小幅下跌（一次性、幅度封顶）。
func _on_day_tick(d: int) -> void:
	if not _initialized or d <= 0 or d - _last_research_day < 30:
		return
	_last_research_day = d
	for code in _tech_codes:
		var inst: Dictionary = instruments[code]
		var gain: float = _rng.randfn(1.2, 1.8)
		inst["rd"] = clampf(float(inst["rd"]) + gain, 0.0, 100.0)
	var report: Array = []
	for rival in _by_rival:
		var codes: Array = _by_rival[rival]
		if codes.size() < 2:
			continue
		var best_code: String = str(codes[0])
		var best_rd: float = float(instruments[best_code]["rd"])
		for c in codes:
			var rr: float = float(instruments[c]["rd"])
			if rr > best_rd:
				best_rd = rr
				best_code = str(c)
		for c in codes:
			var inst2: Dictionary = instruments[c]
			var gap: float = best_rd - float(inst2["rd"])
			if str(c) == best_code:
				apply_company_move(str(c), 0.004)
			elif gap > 0.0:
				apply_company_move(str(c), -minf(0.025, gap * 0.001))
		report.append("%s赛道：%s 领跑（%.0f 分）" % [
				str(rival), str(instruments[best_code]["name"]), best_rd])
	if report.is_empty():
		return
	var pick: String = str(report[_rng.randi_range(0, report.size() - 1)])
	EventBus.event_triggered.emit({
		"id": "research_review", "cat": "科研", "kind": "研发", "months": [], "tag": "科研·季度",
		"title": "科研点季度评估 · " + pick, "severity": 0.2,
		"prompt": "顺应当前技术迭代：各公司科研点按季度推进。同赛道里科研点落后的一方，市场会给出小幅估值折价；领跑者获得轻微溢价。下季度的研发投入可能改写排名。",
		"hint": "提示 · 科研点落后的一方会被市场给出估值折价，不波及黄金、原油等商品；左侧列表可看各公司科研点。",
		"impact": {}, "news_t": d * 1440 + 720,
	})

func _on_event(ev: Dictionary) -> void:
	# 廉政/公司事件：只打指定公司，一次性小幅跳价，绝不扩散到板块与商品
	var tc: String = str(ev.get("target_code", ""))
	if tc != "" and instruments.has(tc) and not tc.begins_with("C."):
		apply_company_move(tc, float(ev.get("stock_impact", -0.03)))
	var impact: Dictionary = ev.get("impact", {})
	var sev: float = float(ev.get("severity", 0.5))
	for sector in impact:
		var codes: Array = _by_sector.get(sector, [])
		var dir: float = float(impact[sector])
		for code in codes:
			if instruments.has(code):
				instruments[code]["shock"] += dir * BUDGET * sev * 0.5
	bump_version()

## 取某标的某周期K线（带版本缓存）
func get_bars(code: String, period: int) -> Array:
	if not instruments.has(code):
		return []
	var key: String = "%s|%d" % [code, period]
	var e: Dictionary = _cache.get(key, {})
	if not e.is_empty() and int(e["ver"]) == _ver:
		return e["bars"]
	var arr: Array = _build_bars(code, period)
	_cache[key] = {"ver": _ver, "bars": arr}
	return arr

func _build_bars(code: String, period: int) -> Array:
	var inst: Dictionary = instruments[code]
	match period:
		Const.Period.M1:    return _aggregate(inst["bars"], 1)
		Const.Period.M5:    return _aggregate(inst["bars"], 5)
		Const.Period.M15:   return _aggregate(inst["bars"], 15)
		Const.Period.M60:   return _aggregate(inst["bars"], 60)
		Const.Period.DAY:   return inst["days"]
		Const.Period.WEEK:  return _aggregate_days(inst["days"], 10080)
		Const.Period.MONTH: return _aggregate_days(inst["days"], 43200)
	return inst["bars"]

## 分钟线按固定跨度聚合
func _aggregate(src: Array, span: int) -> Array:
	if span <= 1:
		return src
	var out: Array = []
	var cur: Dictionary = {}
	var bucket_start := -1
	for b in src:
		var t: int = int(b["t"])
		var bucket: int = floori(float(t) / float(span))
		if bucket != bucket_start:
			if not cur.is_empty():
				out.append(cur)
			cur = {"o": b["o"], "h": b["h"], "l": b["l"], "c": b["c"], "v": b["v"], "t": t}
			bucket_start = bucket
		else:
			cur["h"] = maxf(float(cur["h"]), float(b["h"]))
			cur["l"] = minf(float(cur["l"]), float(b["l"]))
			cur["c"] = b["c"]
			cur["v"] = float(cur["v"]) + float(b["v"])
	if not cur.is_empty():
		out.append(cur)
	return out

## 日线按真实日历聚合：span=10080 周K（周一起），span=43200 月K（自然月）
func _aggregate_days(days: Array, span: int) -> Array:
	var out: Array = []
	var cur: Dictionary = {}
	var bucket: int = -2147483647
	for b in days:
		var t: int = int(b["t"])
		var bk: int
		if span == 10080:
			# 1970-01-01 是周四，上一个周一 unix = -259200；据此对齐到 UTC 周一
			bk = floori(float(Const.game_unix(t) + 259200) / 604800.0)
		elif span == 43200:
			var dt: Dictionary = Time.get_datetime_dict_from_unix_time(Const.game_unix(t))
			bk = int(dt["year"]) * 12 + int(dt["month"])
		else:
			bk = floori(float(t) / float(span))
		if bk != bucket:
			if not cur.is_empty():
				out.append(cur)
			cur = {"o": b["o"], "h": b["h"], "l": b["l"], "c": b["c"], "v": b["v"], "t": t}
			bucket = bk
		else:
			cur["h"] = maxf(float(cur["h"]), float(b["h"]))
			cur["l"] = minf(float(cur["l"]), float(b["l"]))
			cur["c"] = b["c"]
			cur["v"] = float(cur["v"]) + float(b["v"])
	if not cur.is_empty():
		out.append(cur)
	return out

func last_price(code: String) -> float:
	if not instruments.has(code):
		return 0.0
	return float(instruments[code]["bars"][-1]["c"])

func instrument(code: String) -> Dictionary:
	return instruments.get(code, {})
