extends Node
## 自动存档管理器 v2
## 规则：
##   1) 每秒自动覆盖保存一次（只有一个存档槽，永远写同一份）
##   2) 切到后台 / 退出前也立刻存一次，防止被系统杀后台丢进度
##   3) 手动重置：删档 + 清内存，回到启动页重新选初始资金
## 依赖 autoload：ClockSys / Portfolio / Market / EventSys（缺失时降级为只存账户）
## 存档位置：user://savegame.json （安卓上为 App 私有目录，不会被系统清理）

signal saved()
signal reset_done()

const SAVE_PATH := "user://savegame.json"
const AUTOSAVE_INTERVAL := 1.0   # 秒，自动存档间隔

var _acc := 0.0                  # 累加器，凑够 1 秒存一次
var _dirty := false              # 有变化才存，避免空转写盘
var enabled := true

func _ready() -> void:
	# 每秒自动存档：用 _process 累加，不依赖 timer 节点，少一处配置
	set_process(true)

func _process(delta: float) -> void:
	if not enabled:
		return
	_acc += delta
	if _acc >= AUTOSAVE_INTERVAL:
		_acc = 0.0
		if _dirty:
			save_game()
			_dirty = false

## 标记“有变化，下次到点就存”。成交、事件、时间推进后调用。
func mark_dirty() -> void:
	_dirty = true

## 退出兜底保存。
## 注意：Godot 4 没有裸常量 NOTIFICATION_APPLICATION_PAUSE（写错会 Parser Error），
## 这里只用 Node 自带的 NOTIFICATION_EXIT_TREE；切后台靠每秒自动存，最多丢 1 秒进度。
func _notification(what: int) -> void:
	if what == NOTIFICATION_EXIT_TREE and enabled:
		save_game()

## 收集当前全部状态，写成一个 Dictionary
func collect_data() -> Dictionary:
	var d: Dictionary = {
		"version": 2,
		"saved_at": Time.get_unix_time_from_system(),
	}
	# 账户（Portfolio 一定存在）
	if has_node("/root/Portfolio"):
		var pf = get_node("/root/Portfolio")
		d["cash"] = pf.cash
		d["init_cash"] = pf.init_cash
		d["positions"] = pf.positions   # code -> {qty, cost}
	# 时间（ClockSys 可选）
	if has_node("/root/ClockSys"):
		var ck = get_node("/root/ClockSys")
		d["game_minute"] = ck.game_minute
		d["speed"] = ck.speed
		d["paused"] = ck.paused
	# 行情（Market 可选，缺失则不存，读档时重新生成）
	if has_node("/root/Market"):
		var mk = get_node("/root/Market")
		if mk.has_method("serialize"):
			d["market"] = mk.serialize()
	# 事件进度（EventSys 可选）
	if has_node("/root/EventSys"):
		var ev = get_node("/root/EventSys")
		if ev.has_method("serialize"):
			d["events"] = ev.serialize()
	# 新闻时间线（主界面提供快照接口，缺失就跳过）
	if has_node("/root/Main"):
		var mn = get_node("/root/Main")
		if mn.has_method("get_news_snapshot"):
			var snap: Array = mn.get_news_snapshot()
			d["news"] = snap
	return d

## 立刻写盘（覆盖旧档）
func save_game() -> bool:
	var data: Dictionary = collect_data()
	var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("SaveMgr: 无法打开存档文件 " + SAVE_PATH)
		return false
	f.store_string(JSON.stringify(data))
	f.close()
	saved.emit()
	return true

## 读档。无档返回空 Dictionary。
func load_game() -> Dictionary:
	if not FileAccess.file_exists(SAVE_PATH):
		return {}
	var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return {}
	var txt: String = f.get_as_text()
	f.close()
	var parsed = JSON.parse_string(txt)
	if not (parsed is Dictionary):
		push_warning("SaveMgr: 存档损坏，忽略")
		return {}
	return parsed

## 把读到的存档写回各系统。返回是否成功恢复。
func apply_data(d: Dictionary) -> bool:
	if d.is_empty():
		return false
	if has_node("/root/Portfolio") and d.has("cash"):
		var pf = get_node("/root/Portfolio")
		pf.init_cash = float(d.get("init_cash", 0.0))
		pf.cash = float(d.get("cash", 0.0))
		# JSON 读回的 positions 里 qty/cost 可能是字符串，统一转回
		var pos: Dictionary = {}
		var raw: Dictionary = d.get("positions", {})
		for code in raw:
			var p = raw[code]
			pos[String(code)] = {
				"qty": int(p.get("qty", 0)),
				"cost": float(p.get("cost", 0.0)),
			}
		pf.positions = pos
	if has_node("/root/ClockSys") and d.has("game_minute"):
		var ck = get_node("/root/ClockSys")
		ck.game_minute = int(d.get("game_minute", 0))
		ck.speed = int(d.get("speed", 1))
		ck.paused = bool(d.get("paused", false))
	if has_node("/root/Market") and d.has("market"):
		var mk = get_node("/root/Market")
		if mk.has_method("deserialize"):
			mk.deserialize(d["market"])
	if has_node("/root/EventSys") and d.has("events"):
		var ev = get_node("/root/EventSys")
		if ev.has_method("deserialize"):
			ev.deserialize(d["events"])
	if has_node("/root/Main") and d.has("news") and d["news"] is Array:
		var mn = get_node("/root/Main")
		if mn.has_method("apply_news_snapshot"):
			var news_arr: Array = d["news"]
			mn.apply_news_snapshot(news_arr)
	_dirty = false
	return true

## 一键重置：删档 + 清空内存账户，回到启动页
func reset_progress() -> void:
	enabled = false
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
		# user:// 用 remove_absolute 有时失败，兜底用 DirAccess.open(user://)
		var dir: DirAccess = DirAccess.open("user://")
		if dir and dir.file_exists("savegame.json"):
			dir.remove("savegame.json")
	if has_node("/root/Portfolio"):
		var pf = get_node("/root/Portfolio")
		pf.reset(0.0)
	if has_node("/root/ClockSys"):
		var ck = get_node("/root/ClockSys")
		if ck.has_method("reset"):
			ck.reset()
	if has_node("/root/EventDB"):
		var edb = get_node("/root/EventDB")
		if edb.has_method("reset_schedule"):
			edb.reset_schedule()
	if has_node("/root/Market"):
		var mk = get_node("/root/Market")
		if mk.has_method("reset_market"):
			mk.reset_market()
	_acc = 0.0
	_dirty = false
	# 重置后保持停用：否则下一秒自动存会把"资金 0 + 种子新闻"写成一份新档，
	# 启动页会冒出"读档继续"，点进去又是一个 0 资金的空局。
	# 等玩家选完初始资金真正开局时，由 main.gd 调 enable_autosave(true) 恢复。
	enabled = false
	reset_done.emit()

## 开局后恢复每秒自动存档
func enable_autosave(on: bool) -> void:
	enabled = on
	_acc = 0.0
	if on:
		_dirty = true

## 是否有存档（启动页据此决定进“选资金”还是“读档继续”）
func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)