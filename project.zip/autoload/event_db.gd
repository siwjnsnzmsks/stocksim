extends Node
## 事件库：加载 events.json，负责随机调度（同一事件冷却、同类不连、间隔控制）

const SAME_EVENT_COOLDOWN_DAY := 180   # 同一事件最少间隔天数
const SAME_KIND_COOLDOWN_DAY := 60     # 同类事件最少间隔天数
const MIN_GAP_DAY := 2                 # 两次播报最小间隔
const MAX_GAP_DAY := 9                 # 两次播报最大间隔
## 廉政（公司个体）事件独立调度：平均约 3 个月一次，与宏观事件互不挤占
const CORRUPTION_MIN_GAP_DAY := 70
const CORRUPTION_MAX_GAP_DAY := 110     # 均值 90 天 ≈ 3 个月
const CORRUPTION_FIRST_MIN_DAY := 45
const CORRUPTION_FIRST_MAX_DAY := 135

var _events: Array = []
var _corruption_templates: Array = []
var _last_fire_day: Dictionary = {}    # event_id -> 上次触发的游戏天
var _last_kind_day: Dictionary = {}    # kind    -> 上次触发的游戏天
var _last_any_day: int = -99
var _next_gap: int = 3
var _next_corruption_day: int = 90
var _last_corruption_code: String = ""
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()
	_next_corruption_day = _rng.randi_range(CORRUPTION_FIRST_MIN_DAY, CORRUPTION_FIRST_MAX_DAY)
	_last_corruption_code = ""
	_load()

func _load() -> void:
	var f: FileAccess = FileAccess.open("res://data/events.json", FileAccess.READ)
	if f == null:
		push_warning("events.json 读取失败，使用空事件库")
		return
	var txt: String = f.get_as_text()
	f.close()
	var parsed = JSON.parse_string(txt)
	if parsed == null or not parsed.has("events"):
		push_warning("events.json 解析失败")
		return
	_events = parsed["events"]
	_corruption_templates = parsed.get("corruption_templates", [])

func all_events() -> Array:
	return _events

## 重置进度必须一起清冷却记录：时间归零后若保留旧的 _last_fire_day，
## current_day - 旧天数 会是负数，事件系统会被判定全在冷却期内，永远不再触发。
func reset_schedule() -> void:
	_last_fire_day.clear()
	_last_kind_day.clear()
	_last_any_day = -99
	_next_gap = _rng.randi_range(MIN_GAP_DAY, MAX_GAP_DAY)
	_next_corruption_day = _rng.randi_range(CORRUPTION_FIRST_MIN_DAY, CORRUPTION_FIRST_MAX_DAY)
	_last_corruption_code = ""

## 每个游戏天调用：判断是否该播报一个事件，返回事件字典或空
## month 为该游戏日所在月份(1..12)：事件可带 months 白名单，空数组=全年。
## 之前事件完全随机不看季节，于是 1 月会播"极端高温用电负荷创新高"，属于明显穿帮。
func maybe_trigger(current_day: int, month: int) -> Dictionary:
	if current_day - _last_any_day < _next_gap:
		return {}
	var candidates: Array = []
	for ev in _events:
		var eid: String = str(ev.get("id", ""))
		var kind: String = str(ev.get("kind", ""))
		# 季节白名单：JSON 解析出的数字可能是 int 或 float，统一按 int 比较
		var months: Array = ev.get("months", [])
		if not months.is_empty():
			var season_ok: bool = false
			for mm in months:
				if int(mm) == month:
					season_ok = true
					break
			if not season_ok:
				continue
		if current_day - int(_last_fire_day.get(eid, -999)) < SAME_EVENT_COOLDOWN_DAY:
			continue
		if current_day - int(_last_kind_day.get(kind, -999)) < SAME_KIND_COOLDOWN_DAY:
			continue
		candidates.append(ev)
	if candidates.is_empty():
		return {}
	var ev: Dictionary = candidates[_rng.randi_range(0, candidates.size() - 1)]
	_last_fire_day[ev["id"]] = current_day
	_last_kind_day[ev.get("kind", "")] = current_day
	_last_any_day = current_day
	_next_gap = _rng.randi_range(MIN_GAP_DAY, MAX_GAP_DAY)
	return ev

## 廉政事件：与宏观事件完全分离的一条调度线，平均约 90 游戏日（3 个月）一次。
## 只挑 A 股"公司"标的（排除 C.* 商品与美股），标题带上具体公司名，
## 返回 target_code + stock_impact，由 Market 对该公司做一次性小幅跳价，
## 不写 impact 板块映射 —— 因此绝不会波及黄金、原油、同板块其它公司。
func maybe_trigger_corruption(current_day: int) -> Dictionary:
	if current_day < _next_corruption_day or _corruption_templates.is_empty():
		return {}
	var pool: Array = []
	for code in Market.instruments:
		var inst: Dictionary = Market.instruments[code]
		if int(inst["mkt"]) != Const.Mkt.A:
			continue
		if str(code).begins_with("C."):
			continue
		if str(code) == _last_corruption_code:
			continue
		pool.append(str(code))
	if pool.is_empty():
		return {}
	var target: String = str(pool[_rng.randi_range(0, pool.size() - 1)])
	var tpl: Dictionary = _corruption_templates[_rng.randi_range(0, _corruption_templates.size() - 1)]
	var cname: String = str(Market.instrument(target).get("name", target))
	_last_corruption_code = target
	_next_corruption_day = current_day + _rng.randi_range(CORRUPTION_MIN_GAP_DAY, CORRUPTION_MAX_GAP_DAY)
	return {
		"id": "corruption_%s_%d" % [target, current_day],
		"cat": "廉政", "kind": "公司治理", "months": [], "tag": "廉政·公司",
		"title": "%s：%s" % [cname, str(tpl["title"])],
		"severity": float(tpl["severity"]), "half_life_min": 2880,
		"prompt": str(tpl["prompt"]), "hint": str(tpl.get("hint", "")),
		"target_code": target, "stock_impact": float(tpl["stock_impact"]),
		"impact": {},
	}
