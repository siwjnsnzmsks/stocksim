extends Node
## 事件库 v3：产业大事件（低频 · 7 天脉冲） + 公司独立小事件（同行 + 产业链传导）
##
## - 大事件：政策 / 产业方向，25~50 游戏日一次，只控制一个行业的波动。
##   行情侧按"先冲高、后放缓、7 天内归零"的脉冲曲线兑现，不搞隔几天就出新政策。
## - 公司小事件：4~10 游戏日一次，落到具体一家公司；同行与上游材料由 Market 传导。
## - 廉政：独立档期，平均约 3 个月一次，no_spill=true，绝不扩散到板块与商品。

const MACRO_MIN_GAP_DAY := 25
const MACRO_MAX_GAP_DAY := 50
const COMPANY_MIN_GAP_DAY := 4
const COMPANY_MAX_GAP_DAY := 10
const SAME_EVENT_COOLDOWN_DAY := 180
const SAME_COMPANY_COOLDOWN_DAY := 30
const CORRUPTION_MIN_GAP_DAY := 70
const CORRUPTION_MAX_GAP_DAY := 110
const CORRUPTION_FIRST_MIN_DAY := 45
const CORRUPTION_FIRST_MAX_DAY := 135

var _macro: Array = []
var _company: Array = []
var _chain: Dictionary = {}
var _corruption_templates: Array = []
var _last_fire_day: Dictionary = {}      # event_id -> 上次触发的游戏天
var _last_company_day: Dictionary = {}   # code     -> 上次被公司事件点名的游戏天
var _next_macro_day: int = 20
var _next_company_day: int = 3
var _next_corruption_day: int = 90
var _last_corruption_code: String = ""
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()
	_load()
	reset_schedule()

func _load() -> void:
	var f: FileAccess = FileAccess.open("res://data/events.json", FileAccess.READ)
	if f == null:
		push_warning("events.json 读取失败，使用空事件库")
		return
	var txt: String = f.get_as_text()
	f.close()
	var parsed = JSON.parse_string(txt)
	if not (parsed is Dictionary):
		push_warning("events.json 解析失败")
		return
	_macro = parsed.get("macro_events", [])
	_company = parsed.get("company_events", [])
	_chain = parsed.get("chain_rules", {})
	_corruption_templates = parsed.get("corruption_templates", [])

## 固定种子：三条随机流互相独立（Market=seed / Flow=seed+101 / EventDB=seed+202）。
## 只设种子、不重置档期——读档时会由 deserialize 覆盖成存档里的档期。
func set_seed(seed_value: int) -> void:
	_rng.seed = seed_value

func serialize() -> Dictionary:
	return {
		"rng_state": _rng.state,
		"last_fire": _last_fire_day.duplicate(true),
		"last_company": _last_company_day.duplicate(true),
		"next_macro": _next_macro_day,
		"next_company": _next_company_day,
		"next_corruption": _next_corruption_day,
		"last_corruption_code": _last_corruption_code,
	}

func deserialize(d: Dictionary) -> void:
	if d.is_empty():
		return
	_last_fire_day = d.get("last_fire", {})
	_last_company_day = d.get("last_company", {})
	_next_macro_day = int(d.get("next_macro", 20))
	_next_company_day = int(d.get("next_company", 3))
	_next_corruption_day = int(d.get("next_corruption", 90))
	_last_corruption_code = str(d.get("last_corruption_code", ""))
	var rs: int = int(d.get("rng_state", 0))
	if rs != 0:
		_rng.state = rs

func chain_rules() -> Dictionary:
	return _chain

func all_events() -> Array:
	return _macro + _company

## 重置进度必须一起清冷却记录：时间归零后若保留旧的天数，
## current_day - 旧天数 会是负数，事件系统会被判定全在冷却期内，永远不再触发。
func reset_schedule() -> void:
	_last_fire_day.clear()
	_last_company_day.clear()
	_next_macro_day = _rng.randi_range(12, MACRO_MIN_GAP_DAY)
	_next_company_day = _rng.randi_range(1, COMPANY_MIN_GAP_DAY)
	_next_corruption_day = _rng.randi_range(CORRUPTION_FIRST_MIN_DAY, CORRUPTION_FIRST_MAX_DAY)
	_last_corruption_code = ""

func _month_ok(ev: Dictionary, month: int) -> bool:
	var months: Array = ev.get("months", [])
	if months.is_empty():
		return true
	for mm in months:
		if int(mm) == month:
			return true
	return false

## 每个游戏天调用一次。同一天最多返回一条：大事件优先，公司事件顺延到下一天。
func maybe_trigger(current_day: int, month: int) -> Dictionary:
	if current_day >= _next_macro_day:
		var m: Dictionary = _pick_macro(current_day, month)
		_next_macro_day = current_day + _rng.randi_range(MACRO_MIN_GAP_DAY, MACRO_MAX_GAP_DAY)
		if not m.is_empty():
			if current_day >= _next_company_day:
				_next_company_day = current_day + 1
			return m
	if current_day >= _next_company_day:
		var c: Dictionary = _pick_company(current_day, month)
		_next_company_day = current_day + _rng.randi_range(COMPANY_MIN_GAP_DAY, COMPANY_MAX_GAP_DAY)
		return c
	return {}

func _pick_macro(current_day: int, month: int) -> Dictionary:
	var pool: Array = []
	for src in _macro:
		if not _month_ok(src, month):
			continue
		if current_day - int(_last_fire_day.get(str(src["id"]), -999)) < SAME_EVENT_COOLDOWN_DAY:
			continue
		pool.append(src)
	if pool.is_empty():
		return {}
	var src2: Dictionary = pool[_rng.randi_range(0, pool.size() - 1)]
	_last_fire_day[str(src2["id"])] = current_day
	var ev: Dictionary = src2.duplicate(true)
	ev["pulse"] = true
	ev["cat"] = "产业政策"
	ev["kind"] = "产业方向"
	ev["severity"] = 0.6
	ev["half_life_min"] = 10080
	ev["prompt"] = str(ev.get("body", ""))
	ev["impact"] = {}
	return ev

func _pick_company(current_day: int, month: int) -> Dictionary:
	var pool: Array = []
	for src in _company:
		if not _month_ok(src, month):
			continue
		if current_day - int(_last_fire_day.get(str(src["id"]), -999)) < SAME_EVENT_COOLDOWN_DAY:
			continue
		pool.append(src)
	if pool.is_empty():
		return {}
	var codes: Array = []
	for code in Market.instruments:
		if str(code).begins_with("C."):
			continue
		if current_day - int(_last_company_day.get(str(code), -999)) < SAME_COMPANY_COOLDOWN_DAY:
			continue
		codes.append(str(code))
	if codes.is_empty():
		return {}
	var src2: Dictionary = pool[_rng.randi_range(0, pool.size() - 1)]
	var target: String = str(codes[_rng.randi_range(0, codes.size() - 1)])
	_last_fire_day[str(src2["id"])] = current_day
	_last_company_day[target] = current_day
	var ev: Dictionary = src2.duplicate(true)
	var cname: String = str(Market.instrument(target).get("name", target))
	ev["title"] = str(ev["title"]).replace("{company}", cname)
	ev["target_code"] = target
	ev["cat"] = "公司"
	ev["kind"] = "公司经营"
	ev["severity"] = 0.4
	ev["half_life_min"] = 2880
	ev["prompt"] = str(ev.get("body", ""))
	ev["impact"] = {}
	return ev

## 廉政事件：与产业/公司事件完全分离，平均约 90 游戏日一次。
## no_spill=true 让 Market 只打这一家公司，不传导同行、不碰材料与商品。
func maybe_trigger_corruption(current_day: int) -> Dictionary:
	if current_day < _next_corruption_day or _corruption_templates.is_empty():
		return {}
	var pool: Array = []
	for code in Market.instruments:
		var inst: Dictionary = Market.instruments[code]
		if int(inst["mkt"]) != Const.Mkt.A:
			continue
		if str(code).begins_with("C."):
			continue
		if str(code) == _last_corruption_code:
			continue
		pool.append(str(code))
	if pool.is_empty():
		return {}
	var target: String = str(pool[_rng.randi_range(0, pool.size() - 1)])
	var tpl: Dictionary = _corruption_templates[_rng.randi_range(0, _corruption_templates.size() - 1)]
	var cname: String = str(Market.instrument(target).get("name", target))
	_last_corruption_code = target
	_next_corruption_day = current_day + _rng.randi_range(CORRUPTION_MIN_GAP_DAY, CORRUPTION_MAX_GAP_DAY)
	return {
		"id": "corruption_%s_%d" % [target, current_day],
		"cat": "廉政", "kind": "公司治理", "months": [], "tag": "廉政·公司",
		"title": "%s：%s" % [cname, str(tpl["title"])],
		"severity": float(tpl["severity"]), "half_life_min": 2880,
		"prompt": str(tpl.get("body", "")), "hint": str(tpl.get("hint", "")),
		"target_code": target, "stock_impact": float(tpl["stock_impact"]),
		"no_spill": true, "impact": {},
	}
