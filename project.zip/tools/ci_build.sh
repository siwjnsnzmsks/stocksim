#!/usr/bin/env bash
# 云端出 APK 的全部脏活。由极短的 .github/workflows/apk.yml 调用。
# 运行前提：仓库根目录有 project.zip（整个工程），且已解压到本脚本所在工程目录。
set -e

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
echo "工程目录: $ROOT"

# ---------- 1. JDK 17 ----------
JH=""
for d in /usr/lib/jvm/*17* /opt/hostedtoolcache/Java_Temurin-Hotspot_jdk/17*/*/x64; do
    if [ -x "$d/bin/java" ]; then JH="$d"; break; fi
done
if [ -z "$JH" ]; then
    sudo apt-get update -qq
    sudo apt-get install -y -qq openjdk-17-jdk-headless
    JH="/usr/lib/jvm/java-17-openjdk-amd64"
fi
export JAVA_HOME="$JH"
export PATH="$JH/bin:$PATH"
java -version 2>&1 | head -1

# ---------- 2. Android SDK ----------
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/usr/local/lib/android/sdk}}"
SDKM=""
for c in "$SDK/cmdline-tools/latest/bin/sdkmanager" \
         "$SDK/cmdline-tools/bin/sdkmanager" \
         "$SDK/tools/bin/sdkmanager"; do
    if [ -x "$c" ]; then SDKM="$c"; break; fi
done
if [ -z "$SDKM" ]; then
    SDK="$HOME/android-sdk"; SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"
    mkdir -p "$SDK/cmdline-tools"
    curl -fsSL -o /tmp/cmdtools.zip \
      https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    unzip -q -o /tmp/cmdtools.zip -d /tmp/cmdtools
    rm -rf "$SDK/cmdline-tools/latest"
    mv /tmp/cmdtools/cmdline-tools "$SDK/cmdline-tools/latest"
fi
echo "Android SDK: $SDK"
yes | "$SDKM" --sdk_root="$SDK" --licenses >/dev/null 2>&1 || true
"$SDKM" --sdk_root="$SDK" "platform-tools" "build-tools;35.0.1" "platforms;android-35"

# ---------- 3. Godot 4.7.2 编辑器 + 导出模板（云端下载，不占你的网速） ----------
V="4.7.2-stable"
B1="https://github.com/godotengine/godot/releases/download/$V"
B2="https://github.com/godotengine/godot-builds/releases/download/$V"
curl -fL --retry 4 -o /tmp/godot.zip "$B1/Godot_v${V}_linux.x86_64.zip" \
  || curl -fL --retry 4 -o /tmp/godot.zip "$B2/Godot_v${V}_linux.x86_64.zip"
curl -fL --retry 4 -o /tmp/templates.tpz "$B1/Godot_v${V}_export_templates.tpz" \
  || curl -fL --retry 4 -o /tmp/templates.tpz "$B2/Godot_v${V}_export_templates.tpz"
unzip -q -o /tmp/godot.zip -d /tmp/godotbin
sudo install -m 0755 "/tmp/godotbin/Godot_v${V}_linux.x86_64" /usr/local/bin/godot
TPL="$HOME/.local/share/godot/export_templates/4.7.2.stable"
mkdir -p "$TPL"
rm -rf /tmp/tpl && mkdir -p /tmp/tpl
unzip -q -o /tmp/templates.tpz -d /tmp/tpl
cp -r /tmp/tpl/templates/* "$TPL"/
echo "4.7.2.stable" > "$TPL/version.txt"
godot --version

# ---------- 4. 调试签名 + 编辑器设置 ----------
mkdir -p "$HOME/.android" "$HOME/.config/godot"
KS="$HOME/.android/debug.keystore"
keytool -genkeypair -v -keystore "$KS" -alias androiddebugkey \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass android -keypass android \
  -dname "CN=Android Debug,O=Android,C=US" 2>&1 | tail -2
CFG="$HOME/.config/godot/editor_settings-4.7.tres"
printf '%s\n' \
  '[gd_resource type="EditorSettings" format=3]' \
  '' \
  '[resource]' \
  "export/android/java_sdk_path = \"$JH\"" \
  "export/android/android_sdk_path = \"$SDK\"" \
  "export/android/debug_keystore = \"$KS\"" \
  'export/android/debug_keystore_user = "androiddebugkey"' \
  'export/android/debug_keystore_pass = "android"' \
  > "$CFG"

# ---------- 5. 导出单个 APK ----------
godot --headless --import
timeout 120 godot --headless --editor --quit || true
mkdir -p build
godot --headless --export-debug "Android" build/stocksim-debug.apk
test -s build/stocksim-debug.apk
ls -lh build/stocksim-debug.apk
echo "完成：build/stocksim-debug.apk"
