#!/usr/bin/env bash
# 云端出 APK（加固版 v2）
# 由 .github/workflows/apk.yml 调用；工程可在仓库根，也可解压在 g/。
set -Ee

LOG=/tmp/ci.log
: > "$LOG"
exec > >(tee -a "$LOG") 2>&1

on_err() {
    echo ""
    echo "===== 构建失败：第 $1 行，命令 [$2] ====="
    echo "----- 日志尾部 -----"
    sleep 1
    tail -n 70 "$LOG" || true
    # 失败时把日志写回仓库，便于直接读取诊断（[skip ci] 防止重复触发）
    cp "$LOG" ./ci-log.txt 2>/dev/null || true
    if [ -n "${GITHUB_ACTIONS:-}" ] && [ -f ci-log.txt ]; then
        (
            git config user.email "ci@localhost" || true
            git config user.name "ci" || true
            git add -f ci-log.txt || true
            git commit -m "ci log [skip ci]" || true
            git push origin "HEAD:${GITHUB_REF_NAME:-main}" || true
        ) 2>&1 | tail -n 10
    fi
    exit 1
}
trap 'on_err "$LINENO" "$BASH_COMMAND"' ERR

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
echo "工程目录: $ROOT"

# ---------- 1. JDK 17 ----------
JH=""
for d in /usr/lib/jvm/*17* /opt/hostedtoolcache/Java_Temurin-Hotspot_jdk/17*/*/x64; do
    if [ -x "$d/bin/java" ]; then JH="$d"; break; fi
done
if [ -z "$JH" ]; then
    sudo apt-get update -qq
    sudo apt-get install -y -qq openjdk-17-jdk-headless
    JH="$(dirname "$(dirname "$(readlink -f "$(which javac)")")")"
fi
export JAVA_HOME="$JH"
export PATH="$JH/bin:$PATH"
echo "JAVA_HOME=$JH"
java -version 2>&1 | head -n 1

# ---------- 2. Android SDK ----------
ASDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/usr/local/lib/android/sdk}}"
SDKM=""
for base in "$ASDK" /usr/local/lib/android/sdk /usr/lib/android-sdk "$HOME/Android/Sdk"; do
    for sub in "cmdline-tools/latest/bin/sdkmanager" "cmdline-tools/bin/sdkmanager" "tools/bin/sdkmanager"; do
        if [ -x "$base/$sub" ]; then SDKM="$base/$sub"; ASDK="$base"; break 2; fi
    done
done
if [ -z "$SDKM" ]; then
    echo "未找到预装 sdkmanager，下载命令行工具"
    ASDK="$HOME/android-sdk"
    mkdir -p "$ASDK/cmdline-tools" /tmp/cmdtools
    curl -fL --retry 3 --connect-timeout 20 --max-time 600 \
        -o /tmp/cmdtools.zip \
        https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    unzip -q -o /tmp/cmdtools.zip -d /tmp/cmdtools
    rm -rf "$ASDK/cmdline-tools/latest"
    mv /tmp/cmdtools/cmdline-tools "$ASDK/cmdline-tools/latest"
    SDKM="$ASDK/cmdline-tools/latest/bin/sdkmanager"
fi
echo "ANDROID_SDK=$ASDK"
echo "SDKMANAGER=$SDKM"
yes | "$SDKM" --sdk_root="$ASDK" --licenses > /dev/null 2>&1 || true
# 预装 SDK 若不可写，退到完全自管的目录
if ! "$SDKM" --sdk_root="$ASDK" "platform-tools" "build-tools;35.0.1" "platforms;android-35"; then
    echo "预装 SDK 写入失败，改用自管目录重来"
    OLD="$SDKM"
    ASDK="$HOME/android-sdk"
    mkdir -p "$ASDK/cmdline-tools"
    SRC="$(cd "$(dirname "$OLD")/../.." && pwd)"
    rm -rf "$ASDK/cmdline-tools/latest"
    cp -r "$SRC" "$ASDK/cmdline-tools/latest"
    SDKM="$ASDK/cmdline-tools/latest/bin/sdkmanager"
    yes | "$SDKM" --sdk_root="$ASDK" --licenses > /dev/null 2>&1 || true
    "$SDKM" --sdk_root="$ASDK" "platform-tools" "build-tools;35.0.1" "platforms;android-35"
fi
export ANDROID_HOME="$ASDK"
export ANDROID_SDK_ROOT="$ASDK"
ls -la "$ASDK/build-tools" 2>/dev/null | head -n 5 || true

# ---------- 3. Godot 4.7.2 编辑器 + 导出模板 ----------
V="4.7.2-stable"
URLS="https://github.com/godotengine/godot-builds/releases/download/$V https://github.com/godotengine/godot/releases/download/$V"
dl() {
    local out="$1" file="$2" base ok=0
    for base in $URLS; do
        echo "下载 $base/$file"
        if curl -fL --retry 3 --connect-timeout 20 --max-time 900 -o "$out" "$base/$file"; then ok=1; break; fi
    done
    if [ "$ok" != 1 ]; then echo "下载失败: $file"; return 1; fi
    ls -lh "$out"
}
dl /tmp/godot.zip "Godot_v${V}_linux.x86_64.zip"
dl /tmp/templates.tpz "Godot_v${V}_export_templates.tpz"

rm -rf /tmp/godotbin && mkdir -p /tmp/godotbin
unzip -q -o /tmp/godot.zip -d /tmp/godotbin
BIN="$(find /tmp/godotbin -maxdepth 1 -type f -name 'Godot*' | head -n 1)"
if [ -z "$BIN" ]; then echo "编辑器 zip 内没找到二进制"; ls -la /tmp/godotbin; false; fi
echo "二进制: $BIN"
sudo install -m 0755 "$BIN" /usr/local/bin/godot
godot --version

TPL="$HOME/.local/share/godot/export_templates/4.7.2.stable"
rm -rf "$TPL" /tmp/tpl && mkdir -p "$TPL" /tmp/tpl
unzip -q -o /tmp/templates.tpz -d /tmp/tpl
SRC="$(find /tmp/tpl -maxdepth 2 -type d -name templates | head -n 1)"
if [ -z "$SRC" ]; then SRC=/tmp/tpl; fi
cp -r "$SRC"/* "$TPL"/
echo "4.7.2.stable" > "$TPL/version.txt"
if [ ! -f "$TPL/android_debug.apk" ] && [ -f "$TPL/android_debug.perfetto.apk" ]; then
    cp "$TPL/android_debug.perfetto.apk" "$TPL/android_debug.apk"
fi
echo "模板目录："
ls -lh "$TPL" | head -n 20
if [ ! -f "$TPL/android_debug.apk" ]; then echo "缺 android_debug.apk"; false; fi

# ---------- 4. 签名 + 编辑器设置（写到 Godot 实际生成的那个文件） ----------
mkdir -p "$HOME/.android" "$HOME/.config/godot"
KS="$HOME/.android/debug.keystore"
"$JH/bin/keytool" -genkeypair -v -keystore "$KS" -alias androiddebugkey \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass android -keypass android \
    -dname "CN=Android Debug,O=Android,C=US" 2>&1 | tail -n 2
CFG="$(find "$HOME/.config/godot" -maxdepth 1 -name 'editor_settings-4*.tres' | head -n 1)"
if [ -z "$CFG" ]; then
    CFG="$HOME/.config/godot/editor_settings-4.7.tres"
    printf '[gd_resource type="EditorSettings" format=3]\n\n[resource]\n' > "$CFG"
fi
python3 - "$CFG" "$JH" "$ASDK" "$KS" <<'PY'
import sys, re
p, jh, sdk, ks = sys.argv[1:5]
s = open(p, encoding="utf-8").read()
kv = {
    "export/android/java_sdk_path": jh,
    "export/android/android_sdk_path": sdk,
    "export/android/debug_keystore": ks,
    "export/android/debug_keystore_user": "androiddebugkey",
    "export/android/debug_keystore_pass": "android",
}
for k, v in kv.items():
    line = '%s = "%s"' % (k, v)
    pat = r"^" + re.escape(k) + r"\s*=.*$"
    if re.search(pat, s, re.M):
        s = re.sub(pat, line, s, flags=re.M)
    else:
        s = s.rstrip() + "\n" + line + "\n"
open(p, "w", encoding="utf-8").write(s)
print("已写入", p)
PY

# ---------- 5. 导出 ----------
godot --headless --import
timeout 150 godot --headless --editor --quit || true
# 首次运行后才确定编辑器设置文件名，再补写一次
CFG2="$(find "$HOME/.config/godot" -maxdepth 1 -name 'editor_settings-4*.tres' | head -n 1)"
if [ -n "$CFG2" ] && [ "$CFG2" != "$CFG" ]; then
    python3 - "$CFG2" "$JH" "$ASDK" "$KS" <<'PY'
import sys, re
p, jh, sdk, ks = sys.argv[1:5]
s = open(p, encoding="utf-8").read()
kv = {"export/android/java_sdk_path": jh, "export/android/android_sdk_path": sdk,
      "export/android/debug_keystore": ks, "export/android/debug_keystore_user": "androiddebugkey",
      "export/android/debug_keystore_pass": "android"}
for k, v in kv.items():
    line = '%s = "%s"' % (k, v)
    pat = r"^" + re.escape(k) + r"\s*=.*$"
    s = re.sub(pat, line, s, flags=re.M) if re.search(pat, s, re.M) else s.rstrip() + "\n" + line + "\n"
open(p, "w", encoding="utf-8").write(s)
print("已补写", p)
PY
fi
mkdir -p build
if ! godot --headless --export-debug "Android" build/stocksim-debug.apk; then
    echo "=== 导出失败，诊断 ==="
    cat "$CFG2" 2>/dev/null || cat "$CFG"
    ls -la "$TPL" | head -n 30
    false
fi
test -s build/stocksim-debug.apk
ls -lh build/stocksim-debug.apk
echo "完成：build/stocksim-debug.apk"
