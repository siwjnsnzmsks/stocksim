# 只用手机，拿到一个 APK

不用电脑、不用 VPN、不用装任何 App、不用碰 Godot、
不用 JDK / Android SDK / 镜像站。手机能打开 GitHub 就够了。

GitHub 界面没有中文，别找了 [citation:1]。下面每个按钮都给了中英对照。

## 第 1 步：建仓库（就是你截图那一页）

- `Repository name *` → 填 `stocksim`
- `Description` → 留空
- 往下滑 `Choose visibility *` → 选 **Public**
- 最底下绿色 **Create repository** → 点

> 手机网页若看不到某些按钮，浏览器菜单里开一下「桌面版网站 / Desktop site」[citation:4]。

## 第 2 步：传一个文件（先做这个）

仓库页 → **Add file**（添加文件）→ **Upload files**（上传文件）
→ 选 `project.zip` → 最底下绿色 **Commit changes**（提交更改）→ 点。

> 文件名必须正好是 `project.zip`。如果手机下载时改名了，先在文件管理里改回来。

## 第 3 步：再建一个文件（后做这个，顺序别反）

**Add file** → **Create new file**（创建新文件）

- 文件名那一栏**原样填**：`.github/workflows/apk.yml`
  （带斜杠，GitHub 会自动建出这两个文件夹 [citation:5]）
- 正文把下面这段**整段复制粘贴**进去：

```yaml
name: apk
on: [push, workflow_dispatch]
permissions:
  contents: write
jobs:
  b:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: 解压并编译
        run: |
          if [ -f project.zip ]; then unzip -q project.zip -d g; D=g; else D=.; fi
          bash "$D/tools/ci_build.sh"
          mkdir -p out
          cp "$D/build/stocksim-debug.apk" out/stocksim-debug.apk
      - uses: actions/upload-artifact@v4
        with:
          name: stocksim-apk
          path: out/stocksim-debug.apk
      - uses: softprops/action-gh-release@v2
        with:
          files: out/stocksim-debug.apk
          tag_name: v${{ github.run_number }}
          name: 模拟炒股 APK
```

→ 最底下绿色 **Commit changes** → 点。

**这一下就会自动开始编译**，云端那台机器自己装 Godot、模板、JDK、SDK、签名，
不占你手机流量和网速。

## 拿 APK

仓库顶部 **Actions** → 那条变绿（约 3～8 分钟）→ 右侧 **Releases**
→ 附件 `stocksim-debug.apk` → 下载 → 点安装（提示「未知来源」允许一次）。

也可以 Actions → 那次运行 → **Artifacts** → `stocksim-apk`（这个外面套一层 zip，
嫌多一步就用 Releases）。

## 以后改了代码

重新上传新的 `project.zip`（同名覆盖）就自动再出一个 APK。

## 说在前面

- 顺序**必须**先传 zip、后建 yml。反过来第一次跑会因为没有工程文件而失败。
- 这段流水线我做过语法核对，但**没在 GitHub Actions 上真跑过**。
  Actions 页面红了就把那一步日志原文发我，我改脚本——折腾的是云端，不是你手机。
- 我把一个真 bug 顺手修了：`export_presets.cfg` 原来没把 `*.json` 纳入导出，
  就算编出 APK，里面事件库和标的库也是空的。这版已补上。
