﻿param([string]$GodotExe = "")
$ErrorActionPreference = "Continue"
$Project = Split-Path -Parent $PSScriptRoot
Write-Host "工程目录: $Project"

# ---------- 0. Godot 必须先关掉，否则编辑器设置会被它退出时覆盖 ----------
$running = Get-Process | Where-Object { $_.ProcessName -like "Godot*" }
if ($running) {
    Write-Host "[错误] 请先完全关闭 Godot 编辑器，再重新运行本脚本。" -ForegroundColor Red
    exit 1
}

# ---------- 1. 找 Godot 可执行文件 ----------
# Steam 版只有桌面快捷方式，真实 exe 藏在 Steam\steamapps\common 里。
# 这里支持三种输入：① 直接拖 exe  ② 直接拖 .lnk 快捷方式  ③ 什么都不拖（自动搜）。
function Resolve-Shortcut {
    param([string]$path)
    if (-not $path) { return "" }
    if ($path -notlike "*.lnk") {
        if ((Test-Path $path) -and $path -like "*.exe") { return (Resolve-Path $path).Path }
        return ""
    }
    try {
        $sh = New-Object -ComObject WScript.Shell
        $t = $sh.CreateShortcut($path).TargetPath
        # Steam 快捷方式的 TargetPath 常常是 Steam.exe / steam://rungameid/xxx，
        # 绝不能把它当成 Godot 用 —— 只接受文件名里带 godot 的真实 exe，
        # 其余情况返回空，交给下面的 Steam 库扫描去定位真正的安装目录。
        if ($t -and (Test-Path $t) -and $t -like "*.exe" `
                -and ([IO.Path]::GetFileName($t) -match 'godot')) { return $t }
    } catch {}
    return ""
}

function Get-SteamLibraries {
    $libs = New-Object System.Collections.ArrayList
    foreach ($base in @("$env:ProgramFiles\Steam", "C:\Program Files (x86)\Steam",
                       "C:\Program Files\Steam", "D:\Steam", "E:\Steam")) {
        $sa = Join-Path $base "steamapps"
        if (-not (Test-Path $sa)) { continue }
        [void]$libs.Add((Join-Path $sa "common"))
        $vdf = Join-Path $sa "libraryfolders.vdf"
        if (Test-Path $vdf) {
            foreach ($line in (Get-Content $vdf -ErrorAction SilentlyContinue)) {
                if ($line -match '"path"\s+"([^"]+)"') {
                    $lp = $Matches[1].Replace('\\', '\')
                    [void]$libs.Add((Join-Path $lp "steamapps\common"))
                }
            }
        }
    }
    return $libs | Where-Object { $_ } | Sort-Object -Unique
}

function Find-Godot {
    param([string]$given)
    # ① 拖进来的东西：exe 或 .lnk
    if ($given) {
        $r = Resolve-Shortcut $given
        if ($r) { return $r }
    }
    $cands = New-Object System.Collections.ArrayList

    # ② 桌面 / 开始菜单里所有快捷方式，逐个解析找 Godot
    $lnkDirs = @("$env:USERPROFILE\Desktop", "$env:PUBLIC\Desktop",
                 "$env:APPDATA\Microsoft\Windows\Start Menu\Programs",
                 "$env:ProgramData\Microsoft\Windows\Start Menu\Programs")
    foreach ($d in $lnkDirs) {
        if (-not (Test-Path $d)) { continue }
        foreach ($lnk in (Get-ChildItem -Path $d -Filter "*.lnk" -File -Recurse -ErrorAction SilentlyContinue)) {
            $t = Resolve-Shortcut $lnk.FullName
            if ($t -and ($t -match 'godot' -or $lnk.Name -match 'godot')) {
                [void]$cands.Add((Get-Item $t))
            }
        }
    }

    # ③ Steam 库目录（Godot Engine 在 Steam 上的安装目录）
    foreach ($lib in (Get-SteamLibraries)) {
        if (-not (Test-Path $lib)) { continue }
        foreach ($gd in (Get-ChildItem -Path $lib -Directory -Filter "*Godot*" -ErrorAction SilentlyContinue)) {
            foreach ($exe in (Get-ChildItem -Path $gd.FullName -Filter "*.exe" -File -Recurse -Depth 2 -ErrorAction SilentlyContinue)) {
                if ($exe.Name -match 'godot' -and $exe.Name -notmatch 'unins|crash|vc_redist|dxsetup') {
                    [void]$cands.Add($exe)
                }
            }
        }
    }

    # ④ 常见手动安装位置
    $roots = @(
        "$env:ProgramFiles\Godot", "C:\Program Files (x86)\Godot",
        "$env:LOCALAPPDATA\Programs\Godot", "$env:USERPROFILE\Desktop",
        "$env:USERPROFILE\Downloads", "C:\godot", "D:\godot",
        "D:\tools\godot", "D:\tools", "C:\tools\godot"
    )
    foreach ($r in $roots) {
        if (-not (Test-Path $r)) { continue }
        foreach ($f in (Get-ChildItem -Path $r -Filter "*.exe" -File -Recurse -Depth 2 -ErrorAction SilentlyContinue)) {
            if ($f.Name -match '^Godot.*\.exe$' -or $f.Name -match '^godot.*\.exe$') {
                [void]$cands.Add($f)
            }
        }
    }

    $cands = $cands | Where-Object { $_ -and $_.FullName -and (Test-Path $_.FullName) } `
            | Sort-Object FullName -Unique
    # 优先 console 版（能直接拿 stdout），没有就用普通 GUI 版 + 日志重定向
    $console = $cands | Where-Object { $_.Name -like "*console*" } | Select-Object -First 1
    if ($console) { return $console.FullName }
    $any = $cands | Select-Object -First 1
    if ($any) { return $any.FullName }
    return ""
}

$godot = Find-Godot $GodotExe
if (-not $godot) {
    Write-Host "[提示] 自动没搜到 Godot。Steam 版通常在这里：" -ForegroundColor Yellow
    Write-Host "       C:\Program Files (x86)\Steam\steamapps\common\Godot Engine\" -ForegroundColor Yellow
    Write-Host "       也可以右键桌面快捷方式 -> 属性 -> 复制『目标』里的 exe 路径。" -ForegroundColor Yellow
    $manual = Read-Host "把 Godot 的 exe（或 .lnk）完整路径粘进来，直接回车则放弃"
    if ($manual) { $godot = Resolve-Shortcut $manual.Trim('"') }
}
if (-not $godot -or -not (Test-Path $godot)) {
    Write-Host "[错误] 还是没拿到 Godot 程序。把 exe 或桌面快捷方式拖到 ExportAPK.bat 上再试。" -ForegroundColor Red
    exit 1
}
Write-Host "Godot: $godot"

# ---------- 2. 引擎版本 -> 导出模板目录 ----------
$ver = "4.7.2.stable"
try {
    $vout = (& $godot --version 2>&1 | Select-Object -First 1) -join ""
    if ($vout -match '(\d+\.\d+\.\d+)') { $ver = $Matches[1] + ".stable" }
} catch {}
# GUI 版 --version 可能没输出，从 exe 文件名兜底读版本（如 Godot_v4.7.2-stable_win64.exe）
if ($ver -eq "4.7.2.stable" -and $godot -match '(\d+\.\d+\.\d+)-stable') {
    $ver = $Matches[1] + ".stable"
}
Write-Host "模板版本: $ver"
$tplDir = Join-Path $env:APPDATA "Godot\export_templates\$ver"
if (-not (Test-Path (Join-Path $tplDir "android_debug.apk"))) {
    Write-Host "[错误] 缺少 Android 导出模板（$tplDir）。" -ForegroundColor Red
    Write-Host "       打开 Godot -> 编辑器 -> 管理导出模板 -> 下载并安装 $ver（约 1.2GB），装完重跑本脚本。"
    exit 1
}

# ---------- 3. 找 JDK 17 ----------
$jdk = ""
$jdkRoots = @(
    $env:JAVA_HOME,
    "$env:ProgramFiles\Eclipse Adoptium",
    "C:\Program Files (x86)\Eclipse Adoptium",
    "$env:LOCALAPPDATA\Programs\Eclipse Adoptium",
    "$env:ProgramFiles\Java",
    "C:\tools\jdk17", "D:\tools\jdk17", "D:\android-tools\jdk17"
)
foreach ($r in $jdkRoots) {
    if (-not $r -or -not (Test-Path $r)) { continue }
    $dirs = @()
    if (Test-Path (Join-Path $r "bin\java.exe")) { $dirs += $r }
    $dirs += Get-ChildItem -Path $r -Directory -Filter "jdk-17*" -ErrorAction SilentlyContinue
    foreach ($d in $dirs) {
        $p = if ($d -is [string]) { $d } else { $d.FullName }
        $j = Join-Path $p "bin\java.exe"
        if (Test-Path $j) {
            $o = (& $j -version 2>&1) -join ""
            if ($o -match '"17\.') { $jdk = $p; break }
        }
    }
    if ($jdk) { break }
}
if (-not $jdk) {
    Write-Host "[错误] 没找到 JDK 17。请装 Eclipse Temurin 17：https://adoptium.net/temurin/releases/?version=17" -ForegroundColor Red
    Write-Host "       （不要用 JDK 8/11/21，签名阶段会报错）"
    exit 1
}
Write-Host "JDK17: $jdk"

# ---------- 4. 找 / 补 Android SDK ----------
$sdk = ""
foreach ($r in @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, "$env:LOCALAPPDATA\Android\Sdk", "D:\android-sdk", "D:\tools\android-sdk", "C:\Android\Sdk")) {
    if ($r -and (Test-Path (Join-Path $r "platform-tools"))) { $sdk = $r; break }
}
if (-not $sdk) {
    $sdk = "$env:LOCALAPPDATA\Android\Sdk"
    Write-Host "没有现成 SDK，准备下载命令行工具到 $sdk ..."
    New-Item -ItemType Directory -Force $sdk | Out-Null
    $zip = Join-Path $env:TEMP "cmdline-tools-win.zip"
    try {
        Invoke-WebRequest -Uri "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip" -OutFile $zip -UseBasicParsing -ErrorAction Stop
        $tmp = Join-Path $env:TEMP "cmdtools_unpack"
        if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        Expand-Archive -Path $zip -DestinationPath $tmp -Force
        $dst = Join-Path $sdk "cmdline-tools\latest"
        New-Item -ItemType Directory -Force $dst | Out-Null
        Copy-Item -Path (Join-Path $tmp "cmdline-tools\*") -Destination $dst -Recurse -Force
        Remove-Item $zip -Force -ErrorAction SilentlyContinue
    } catch {
        Write-Host "[错误] 下载命令行工具失败：$($_.Exception.Message)" -ForegroundColor Red
        Write-Host "       请直接安装 Android Studio（自带 SDK），装完重跑本脚本。"
        exit 1
    }
}
Write-Host "Android SDK: $sdk"
$sdkmanager = Join-Path $sdk "cmdline-tools\latest\bin\sdkmanager.bat"
if (-not (Test-Path $sdkmanager)) {
    $alt = Get-ChildItem -Path (Join-Path $sdk "cmdline-tools") -Filter "sdkmanager.bat" -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($alt) { $sdkmanager = $alt.FullName }
}
if (-not (Test-Path $sdkmanager)) {
    Write-Host "[错误] 找不到 sdkmanager.bat。请在 Android Studio 的 SDK Manager 里勾选 Command-line Tools (latest)。" -ForegroundColor Red
    exit 1
}

# 接受许可（不接受会静默跳过安装、命令还返回成功）
$yesLines = @("y") * 30
$yesLines | & $sdkmanager "--sdk_root=$sdk" --licenses 2>&1 | Out-Null
Write-Host "安装 SDK 组件：platform-tools / build-tools;35.0.1 / platforms;android-35 ..."
& $sdkmanager "--sdk_root=$sdk" "platform-tools" "build-tools;35.0.1" "platforms;android-35" 2>&1 | Out-Host
$okSdk = (Test-Path (Join-Path $sdk "platform-tools\adb.exe")) -and (Test-Path (Join-Path $sdk "build-tools\35.0.1")) -and (Test-Path (Join-Path $sdk "platforms\android-35"))
if (-not $okSdk) {
    Write-Host "[警告] SDK 组件校验没全过，导出时若仍报红字，把上面输出发我。" -ForegroundColor Yellow
} else {
    Write-Host "SDK 组件就绪。"
}

# ---------- 5. 生成调试签名 keystore ----------
$ksDir = Join-Path $env:USERPROFILE ".android"
$ks = Join-Path $ksDir "debug.keystore"
if (-not (Test-Path $ks)) {
    New-Item -ItemType Directory -Force $ksDir | Out-Null
    Write-Host "生成 debug.keystore ..."
    & (Join-Path $jdk "bin\keytool.exe") -genkey -v -keystore $ks -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 -storepass android -keypass android -dname "CN=Android Debug,O=Android,C=US" 2>&1 | Out-Host
}
if (-not (Test-Path $ks)) {
    Write-Host "[错误] keystore 生成失败。" -ForegroundColor Red
    exit 1
}
Write-Host "Keystore: $ks"

# ---------- 6. 写 Godot 全局编辑器设置（本机一次配好，所有项目通用） ----------
$cfgDir = Join-Path $env:APPDATA "Godot"
New-Item -ItemType Directory -Force $cfgDir | Out-Null
$cfgFile = Get-ChildItem -Path $cfgDir -Filter "editor_settings-*.tres" -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
if ($cfgFile) { $cfg = $cfgFile.FullName } else { $cfg = Join-Path $cfgDir "editor_settings-4.7.tres" }
if (-not (Test-Path $cfg)) {
    [IO.File]::WriteAllText($cfg, "[gd_resource type=`"EditorSettings`" format=3]`r`n`r`n[resource]`r`n", (New-Object System.Text.UTF8Encoding($false)))
}
$settings = [ordered]@{
    "export/android/java_sdk_path"      = $jdk
    "export/android/android_sdk_path"   = $sdk
    "export/android/debug_keystore"     = $ks
    "export/android/debug_keystore_user"= "androiddebugkey"
    "export/android/debug_keystore_pass"= "android"
}
$raw = [IO.File]::ReadAllText($cfg)
$lines = $raw -split "`r?`n"
$seen = @{}
$outLines = New-Object System.Collections.ArrayList
foreach ($l in $lines) {
    $hit = $false
    foreach ($k in $settings.Keys) {
        if ($l -match "^\s*$([regex]::Escape($k))\s*=") {
            $v = ([string]$settings[$k]).Replace('\', '/')
            [void]$outLines.Add("$k = `"$v`"")
            $seen[$k] = $true
            $hit = $true
            break
        }
    }
    if (-not $hit) { [void]$outLines.Add($l) }
}
# 缺的字段插到 [resource] 后面
$final = New-Object System.Collections.ArrayList
foreach ($l in $outLines) {
    [void]$final.Add($l)
    if ($l -match '^\[resource\]') {
        foreach ($k in $settings.Keys) {
            if (-not $seen.ContainsKey($k)) {
                $v = ([string]$settings[$k]).Replace('\', '/')
                [void]$final.Add("$k = `"$v`"")
                $seen[$k] = $true
            }
        }
    }
}
# 极端情况：文件里没有 [resource] 段，直接追加到末尾
foreach ($k in $settings.Keys) {
    if (-not $seen.ContainsKey($k)) {
        $v = ([string]$settings[$k]).Replace('\', '/')
        [void]$final.Add("$k = `"$v`"")
    }
}
[IO.File]::WriteAllText($cfg, ($final -join "`r`n"), (New-Object System.Text.UTF8Encoding($false)))
Write-Host "编辑器设置已写入: $cfg"

# ---------- 7. 导出 APK ----------
$outDir = Join-Path $Project "build"
New-Item -ItemType Directory -Force $outDir | Out-Null
$out = Join-Path $outDir "stocksim-debug.apk"
if (Test-Path $out) { Remove-Item $out -Force }
Write-Host "开始导出 APK（首次可能要一两分钟）..."
$log = Join-Path $outDir "export_log.txt"
$errLog = Join-Path $outDir "export_err.txt"
if ($godot -like "*console*") {
    & $godot --headless "--path=$Project" --export-debug "Android" $out 2>&1 | Tee-Object -FilePath $log | Out-Host
} else {
    # Steam / 普通 GUI 版没有 console 窗口，stdout 直接抓不到：
    # 用 Start-Process 重定向到日志文件，导出完再打印出来。
    $args = @("--headless", "--path=`"$Project`"", "--export-debug", "Android", "`"$out`"")
    try {
        $proc = Start-Process -FilePath $godot -ArgumentList $args -Wait -PassThru `
                    -RedirectStandardOutput $log -RedirectStandardError $errLog -NoNewWindow
        Write-Host "Godot 退出码: $($proc.ExitCode)"
    } catch {
        Write-Host "[警告] Start-Process 调用失败：$($_.Exception.Message)" -ForegroundColor Yellow
    }
    if (Test-Path $log)  { Write-Host "--- 导出日志 ---"; Get-Content $log | Out-Host }
    if (Test-Path $errLog) { $e = Get-Content $errLog -Raw; if ($e.Trim()) { Write-Host "--- 错误输出 ---"; Write-Host $e } }
}
if (Test-Path $out) {
    $fi = Get-Item $out
    Write-Host ""
    Write-Host "[成功] APK 已生成: $out  ($([math]::Round($fi.Length/1MB,1)) MB)" -ForegroundColor Green
    Write-Host "       手机开 USB 调试后：adb install -r `"$out`""
} else {
    Write-Host ""
    Write-Host "[失败] 没生成 APK。把上面 Godot 的输出原文截图发我，我照着修。" -ForegroundColor Red
}
