@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo  StockSim - one-click Android APK export
echo  Close Godot completely before running this script.
echo  Steam version: just drag the DESKTOP SHORTCUT (.lnk) here,
echo  or simply double-click this bat to auto-search Steam library.
echo ============================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0ExportAPK.ps1" -GodotExe "%~1"
echo.
pause
