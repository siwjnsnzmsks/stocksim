@echo off
chcp 65001 >nul
echo ============================================================
echo  StockSim Web - local / LAN server
echo  Copy this .bat + StartWeb.ps1 into the exported Web folder,
echo  or DRAG the exported folder onto this .bat, then it starts.
echo  Phone: connect to the SAME WiFi, open the printed address.
echo ============================================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0StartWeb.ps1" -WebDir "%~1"
echo.
pause
