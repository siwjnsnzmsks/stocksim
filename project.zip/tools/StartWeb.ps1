﻿param([string]$WebDir = "", [int]$Port = 8000)
$ErrorActionPreference = "Stop"

# 用法 A：把本 bat/ps1 复制到导出那堆文件所在文件夹，双击 bat
# 用法 B：把导出文件夹整个拖到 bat 上（%~1 就是那个目录）
# 用法 C：bat 放在桌面，脚本会扫一层子目录找 .html
$startDir = $PSScriptRoot
if ($WebDir -and (Test-Path $WebDir)) {
    $startDir = $WebDir
}
$WebDir = (Resolve-Path $startDir).Path
# 拖进来的是某个文件而不是文件夹时，取它所在的目录
if (Test-Path -LiteralPath $WebDir -PathType Leaf) {
    $WebDir = (Resolve-Path (Split-Path -Parent $WebDir)).Path
}

$htmls = @(Get-ChildItem -LiteralPath $WebDir -Filter "*.html" -File -ErrorAction SilentlyContinue)
if ($htmls.Count -eq 0) {
    foreach ($d in @(Get-ChildItem -LiteralPath $WebDir -Directory -ErrorAction SilentlyContinue)) {
        $found = @(Get-ChildItem -LiteralPath $d.FullName -Filter "*.html" -File -ErrorAction SilentlyContinue)
        if ($found.Count -gt 0) { $WebDir = $d.FullName; $htmls = $found; break }
    }
}
# 还是没有：扫桌面 / 公共桌面 / 下载目录，找"同时有 .html 和 .wasm"的文件夹
# （Godot Web 导出必带这两个）。这样 bat 留在 tools 里直接双击也能自动找到导出目录。
if ($htmls.Count -eq 0) {
    $scanRoots = @("$env:USERPROFILE\Desktop", "$env:PUBLIC\Desktop", "$env:USERPROFILE\Downloads")
    foreach ($sr in $scanRoots) {
        if (-not (Test-Path $sr)) { continue }
        $dirs = @($sr) + @(Get-ChildItem -LiteralPath $sr -Directory -ErrorAction SilentlyContinue |
                            Select-Object -ExpandProperty FullName)
        foreach ($d in $dirs) {
            $h = @(Get-ChildItem -LiteralPath $d -Filter "*.html" -File -ErrorAction SilentlyContinue)
            $w = @(Get-ChildItem -LiteralPath $d -Filter "*.wasm" -File -ErrorAction SilentlyContinue)
            if ($h.Count -gt 0 -and $w.Count -gt 0) {
                $WebDir = $d; $htmls = $h; break
            }
        }
        if ($htmls.Count -gt 0) { break }
    }
}
if ($htmls.Count -eq 0) {
    Write-Host ""
    Write-Host "[错误] 这个目录和它的子目录里都没有 .html。" -ForegroundColor Red
    Write-Host "       把 StartWeb.bat + StartWeb.ps1 一起复制到你导出那堆文件所在文件夹，" -ForegroundColor Yellow
    Write-Host "       或者把那个文件夹直接拖到 StartWeb.bat 上。" -ForegroundColor Yellow
    exit 1
}
Write-Host "Web 目录: $WebDir"

# 自动补一个 index.html：Godot 导出的 html 里引用的是固定的 js/pck/wasm 文件名，
# 复制改名不影响加载。好处是手机输网址不用带中文文件名。
$index = Join-Path $WebDir "index.html"
if (-not (Test-Path $index)) {
    $src = $htmls | Where-Object { $_.Name -ne "index.html" } | Select-Object -First 1
    if ($src) {
        Copy-Item -LiteralPath $src.FullName -Destination $index -Force
        Write-Host "已生成 index.html（来自 $($src.Name)）"
    }
}

function Get-Mime([string]$name) {
    $l = $name.ToLower()
    switch -Regex ($l) {
        "\.html?$" { return "text/html; charset=utf-8" }
        "\.js$"    { return "text/javascript; charset=utf-8" }
        "\.wasm$"  { return "application/wasm" }
        "\.pck$"   { return "application/octet-stream" }
        "\.png$"   { return "image/png" }
        "\.svg$"   { return "image/svg+xml" }
        "\.ico$"   { return "image/x-icon" }
        "\.json$"  { return "application/json; charset=utf-8" }
        "\.css$"   { return "text/css; charset=utf-8" }
        default    { return "application/octet-stream" }
    }
}

# 用 TcpListener 而不是 HttpListener：后者绑定 0.0.0.0 需要管理员/urlacl，
# 前者普通权限就能监听所有网卡，手机才连得上。
try {
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Any, $Port)
    $listener.Start()
} catch {
    Write-Host "[错误] 端口 $Port 起不来：$($_.Exception.Message)" -ForegroundColor Red
    Write-Host "       换个端口：powershell -File StartWeb.ps1 -Port 8080" -ForegroundColor Yellow
    exit 1
}

$ips = @()
try {
    $ips = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
             Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
             Select-Object -ExpandProperty IPAddress)
} catch {
    foreach ($l in (ipconfig 2>$null)) {
        if ($l -match 'IPv4.*?:\s*([\d\.]+)') { $ips += $Matches[1] }
    }
}

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "  服务器已启动，别关这个窗口" -ForegroundColor Green
Write-Host "  电脑本机: http://127.0.0.1:$Port/" -ForegroundColor Green
foreach ($ip in $ips) {
    Write-Host "  手机访问: http://$($ip):$Port/   <- 手机连同一个 WiFi" -ForegroundColor Green
}
Write-Host "  首次运行若弹出 Windows 防火墙提示，请点【允许访问】" -ForegroundColor Yellow
Write-Host "  停止：按 Ctrl+C 或直接关窗口" -ForegroundColor Yellow
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
try { Start-Process "http://127.0.0.1:$Port/" } catch {}

$root = [IO.Path]::GetFullPath($WebDir)
while ($true) {
    $client = $null
    try {
        $client = $listener.AcceptTcpClient()
        $stream = $client.GetStream()
        $stream.ReadTimeout = 3000
        $buf = New-Object byte[] 8192
        $n = $stream.Read($buf, 0, $buf.Length)
        if ($n -le 0) { $client.Close(); continue }
        $req = [Text.Encoding]::ASCII.GetString($buf, 0, $n)
        $first = ($req -split "`r?`n")[0]
        $parts = $first -split "\s+"
        $urlPath = "/"
        if ($parts.Count -ge 2) { $urlPath = $parts[1] }
        $urlPath = ($urlPath -split "\?")[0]
        $rel = [Uri]::UnescapeDataString($urlPath).TrimStart('/')
        if ([string]::IsNullOrEmpty($rel)) { $rel = "index.html" }
        $rel = $rel.Replace('/', '\')
        $full = [IO.Path]::GetFullPath((Join-Path $WebDir $rel))
        $status = "200 OK"
        $mime = "application/octet-stream"
        $bytes = @()
        if (-not $full.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) {
            $status = "403 Forbidden"
            $mime = "text/plain; charset=utf-8"
            $bytes = [Text.Encoding]::UTF8.GetBytes("forbidden")
        } elseif (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
            $status = "404 Not Found"
            $mime = "text/plain; charset=utf-8"
            $bytes = [Text.Encoding]::UTF8.GetBytes("404: $rel")
        } else {
            $mime = Get-Mime $full
            $bytes = [IO.File]::ReadAllBytes($full)
        }
        # 单线程导出（Godot 4.3+ 默认）本不需要这两个头，但加上无害；
        # 若你勾了 Use Threads，没有它们项目就跑不起来。
        $head = "HTTP/1.1 $status`r`n" +
                "Content-Type: $mime`r`n" +
                "Content-Length: $($bytes.Length)`r`n" +
                "Cross-Origin-Opener-Policy: same-origin`r`n" +
                "Cross-Origin-Embedder-Policy: require-corp`r`n" +
                "Cache-Control: no-cache`r`n" +
                "Connection: close`r`n`r`n"
        $hb = [Text.Encoding]::ASCII.GetBytes($head)
        $stream.Write($hb, 0, $hb.Length)
        if ($bytes.Length -gt 0) { $stream.Write($bytes, 0, $bytes.Length) }
        $stream.Flush()
        Write-Host ("  {0}  {1}  {2}" -f $status, $rel, $bytes.Length)
    } catch {
        # 单个连接出错（比如浏览器提前断开）不影响服务器继续
    } finally {
        if ($client) { try { $client.Close() } catch {} }
    }
}
