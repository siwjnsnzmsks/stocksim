# 不装任何东西，拿到一个 APK

本机装 JDK / Android SDK / 1.2GB 模板太烦，就交给 GitHub 的机器编。
你的电脑**什么都不用装**，也不用开 Godot。

## 三步

1. 打开 https://github.com/new ，建一个仓库（名字随便，比如 `stocksim`，**选 Public**，
   私有仓库也行但免费额度少一点）。
2. 把**整个工程文件夹**拖进仓库网页上传（包含 `.github` 这个隐藏文件夹，别漏）。
   不会 git 就直接用网页的 "Add file → Upload files"。
   > `.github/workflows/build-android.yml` 就是流水线，上传后会自动跑。
3. 进仓库的 **Actions** 页，等那条「出安卓APK」变绿（约 3～8 分钟，云端下载
   Godot + 模板 + SDK，不占你家网速）。

## 拿 APK（一个文件）

跑完后到仓库右侧 **Releases**，点最新那条，附件里只有一个：

```
stocksim-debug.apk
```

下载 → 发到手机（微信/QQ/USB 都行）→ 点安装。
手机若提示"未知来源"，允许一次即可。这是单个安装包，不是网页那堆散文件。

> 也可以去 Actions → 那次运行 → Artifacts → `stocksim-apk` 下载（这个外面套了一层 zip，
> 嫌多一层就用 Releases 那条）。

## 以后改了代码

重新把文件推上去（或网页重新上传），Actions 自动再编一次，Releases 里多一条新 APK。

## 说明

- 签名是 **Android 系统**的硬性要求，不是 Godot 故意为难；换 Unity/Flutter 也要签名。
  云端那台机器替你把 JDK 17 + SDK + keystore 全装好了，所以你本机不用碰。
- 这个 workflow 我按 Godot 官方 CLI 导出流程写的，**沙盒里没跑过 GitHub Actions**，
  没实际验证。如果 Actions 页面红了，把那一步的日志原文发我，我照着改 yml。
- 需要 GitHub 账号。连账号都不想弄的话，就只剩"找一台装好环境的机器代编"或
  "Web 版 + 浏览器添加到主屏幕"这两条了。
